//
//  FAQView.swift
//  PointCUSDK
//
//  FAQ (type: "F")
//  - GET /api/v2/member/notice/pagingList
//  - size: 20, 스크롤 바닥 도달 시 page++ 추가 로드
//  - 아코디언 형태 (탭 시 답변 펼침/접힘)
//

import SwiftUI

struct FAQView: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var items: [NoticeItem] = []
    @State private var currentPage: Int = 1
    @State private var totalCount: Int = Int.max  // 첫 로드 전까지 최대값
    @State private var isLoading: Bool = false
    @State private var isFirstLoad: Bool = true
    @State private var expandedItemId: Int? = nil

    private let pageSize = 20

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: Constants.Text.faq,
                backAction: { presentationMode.wrappedValue.dismiss() }
            ) {
                Button(action: {
                    EmailManager.sendContactEmail(userId: AppDataManager.shared.resolvedUserId ?? "")
                }) {
                    HStack(spacing: 4) {
                        Image(Constants.ImageName.mail, bundle: .pointCU)
                            .resizable().scaledToFit()
                            .frame(width: 20, height: 20)
                        Text(Constants.Text.inquiry)
                            .typography(.h5R)
                            .frame(width: 32, height: 28)
                    }
                    .padding(.trailing, 10)
                }
            }

            if isFirstLoad && isLoading {
                Spacer()
                ProgressView()
                Spacer()
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(Constants.Text.faqDesc)
                            .typography(.h2B, color: .black, alignment: .leading)
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                            .padding(.bottom, 8)

                        Divider().background(Color(white: 0.9))

                        LazyVStack(spacing: 0) {
                            ForEach(items) { item in
                                FAQRowView(
                                    item: item,
                                    isExpanded: expandedItemId == item.id,
                                    onToggle: {
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            expandedItemId = expandedItemId == item.id ? nil : item.id
                                        }
                                    }
                                )
                                Divider().background(Color(white: 0.9))
                            }

                            // 바닥 감지 → 다음 페이지 로드
                            if items.count < totalCount {
                                ProgressView()
                                    .padding(.vertical, 16)
                                    .onAppear { Task { await loadNextPage() } }
                            }
                        }
                    }
                }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .task { await loadNextPage() }
    }

    private func loadNextPage() async {
        guard !isLoading else { return }
        if !items.isEmpty && items.count >= totalCount { return }
        isLoading = true
        do {
            let res: NoticePagingResponse = try await NetworkManager.shared.get(
                endpoint: "/api/v2/member/notice/pagingList",
                parameters: ["type": "F", "page": "\(currentPage)", "size": "\(pageSize)"]
            )
            totalCount = res.totalCount
            items.append(contentsOf: res.noticeList)
            currentPage += 1
            isFirstLoad = false
        } catch {
            CULog("FAQ 로드 실패: \(error.localizedDescription)")
            isFirstLoad = false
        }
        isLoading = false
    }
}

// MARK: - 아코디언 행 뷰

private struct FAQRowView: View {
    let item: NoticeItem
    let isExpanded: Bool
    let onToggle: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Button(action: onToggle) {
                HStack {
                    Text(item.title)
                        .typography(.body1B, color: .black, alignment: .leading)
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .foregroundColor(Color(white: 0.4))
                        .font(.system(size: 14, weight: .bold))
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 24)
                .contentShape(Rectangle())
            }
            .buttonStyle(PlainButtonStyle())

            // 타이틀 하단에서 아래로 펼쳐지는 효과
            // clipShape + alignment: .top 으로 위에서 아래로 드러남
            VStack(alignment: .leading) {
                Text(item.content)
                    .typography(.body1R, color: Color(white: 0.2), alignment: .leading)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, isExpanded ? 24 : 0)
            .background(Color(white: 0.97))
            .frame(maxWidth: .infinity)
            .frame(height: isExpanded ? nil : 0, alignment: .top)
            .clipped()
            .opacity(isExpanded ? 1 : 0)
        }
    }
}
