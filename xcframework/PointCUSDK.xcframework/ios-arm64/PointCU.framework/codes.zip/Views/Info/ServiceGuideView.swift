//
//  ServiceGuideView.swift
//  PointCUSDK
//
//  서비스 가이드 (type: "N")
//  - GET /api/v2/member/notice/pagingList
//  - size: 20, 스크롤 바닥 도달 시 page++ 추가 로드
//

import SwiftUI

struct ServiceGuideView: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var items: [NoticeItem] = []
    @State private var currentPage: Int = 1
    @State private var totalCount: Int = Int.max
    @State private var isLoading: Bool = false
    @State private var isFirstLoad: Bool = true
    @State private var selectedItem: NoticeItem? = nil
    @State private var isNavigating: Bool = false
    private let pageSize = 20

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: Constants.Text.serviceInfo,
                backAction: { presentationMode.wrappedValue.dismiss() }
            ) {
                Button(action: {
                    EmailManager.sendContactEmail(userId: AppDataManager.shared.resolvedUserId ?? "")
                }) {
                    HStack(spacing: 4) {
                        Image(Constants.ImageName.mail, bundle: .pointCU)
                            .resizable().scaledToFit()
                            .frame(width: 20, height: 20)
                        Text(Constants.Text.inquiry)
                            .typography(.h5R)
                            .frame(width: 32, height: 28)
                    }
                    .padding(.trailing, 10)
                }
            }

            Divider()
                .background(Color(white: 0.9))
                .padding(.top, 20)

            if isFirstLoad && isLoading {
                Spacer()
                ProgressView()
                Spacer()
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        ForEach(items) { item in
                            Button {
                                selectedItem = item
                                isNavigating = true
                            } label: {
                                NoticeRowView(item: item)
                            }
                            .buttonStyle(PlainButtonStyle())
                            Divider().background(Color(white: 0.9))
                        }

                        if items.count < totalCount {
                            ProgressView()
                                .padding(.vertical, 16)
                                .onAppear { Task { await loadNextPage() } }
                        }
                    }
                }
            }

            // NavigationLink: 버튼 클릭 후 selectedItem이 확정된 뒤 이동 — destination 미리 초기화 방지
            NavigationLink(
                destination: Group {
                    if let item = selectedItem {
                        NoticeContentView(item: item, title: Constants.Text.serviceInfo)
                    }
                },
                isActive: $isNavigating
            ) {
                EmptyView()
            }
            .hidden()
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .task { await loadNextPage() }
    }

    private func loadNextPage() async {
        guard !isLoading else { return }
        if !items.isEmpty && items.count >= totalCount { return }
        isLoading = true
        do {
            let res: NoticePagingResponse = try await NetworkManager.shared.get(
                endpoint: "/api/v2/member/notice/pagingList",
                parameters: ["type": "N", "page": "\(currentPage)", "size": "\(pageSize)"]
            )
            totalCount = res.totalCount
            items.append(contentsOf: res.noticeList)
            currentPage += 1
            isFirstLoad = false
        } catch {
            CULog("ServiceGuide 로드 실패: \(error.localizedDescription)")
            isFirstLoad = false
        }
        isLoading = false
    }
}

// MARK: - 공통 행 뷰

private struct NoticeRowView: View {
    let item: NoticeItem
    var body: some View {
        HStack(spacing: 16) {
            Text(item.title)
                .typography(.body1B, color: .black, alignment: .leading)
                .lineLimit(1)
                .truncationMode(.tail)
                .frame(maxWidth: .infinity, alignment: .leading)
            Image(systemName: "chevron.right")
                .foregroundColor(Color(white: 0.7))
                .font(.system(size: 14, weight: .semibold))
        }
        .frame(height: 64)
        .padding(.horizontal, 20)
        .contentShape(Rectangle())
        .background(Color.white)
    }
}

// MARK: - 상세 화면 (서비스 가이드 / FAQ 공용)

struct NoticeContentView: View {
    @Environment(\.presentationMode) var presentationMode
    let item: NoticeItem
    let title: String

    // content는 onAppear에서 지연 로딩 — 긴 텍스트 즉시 렌더링 시 UI 블로킹 방지
    @State private var displayedContent: String = ""
    @State private var isContentLoaded: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: title,
                backAction: { presentationMode.wrappedValue.dismiss() }
            ) {
                Button(action: {
                    EmailManager.sendContactEmail(userId: AppDataManager.shared.resolvedUserId ?? "")
                }) {
                    HStack(spacing: 4) {
                        Image(Constants.ImageName.mail, bundle: .pointCU)
                            .resizable().scaledToFit()
                            .frame(width: 20, height: 20)
                        Text(Constants.Text.inquiry)
                            .typography(.h5R)
                            .frame(width: 32, height: 32)
                    }
                    .padding(.trailing, 10)
                }
            }

            if !isContentLoaded {
                Spacer()
                ProgressView()
                Spacer()
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(item.title)
                                .typography(.h2B, color: .black, alignment: .leading)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Text(item.regDate)
                                .typography(.robotoBody2R, color: Color(white: 0.5), alignment: .leading)
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                        .padding(.bottom, 8)

                        Divider().background(Color(white: 0.9))

                        NoticeTextView(text: displayedContent)
                        .fixedSize(horizontal: false, vertical: true)
                            .frame(maxWidth: .infinity, alignment: .topLeading)
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                            .padding(.bottom, 24)
                    }
                }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .onAppear {
            // NavigationLink 전환 완료 후 content 렌더링 — 인디케이터 표시 보장
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                displayedContent = item.content
                isContentLoaded = true
            }
        }
    }
}

// MARK: - 긴 텍스트 고속 렌더링 (UITextView 기반)

private struct NoticeTextView: UIViewRepresentable {
    let text: String

    func makeUIView(context: Context) -> UITextView {
        let tv = UITextView()
        tv.isEditable         = false
        tv.isScrollEnabled    = false
        tv.backgroundColor    = .clear
        tv.textContainerInset = .zero
        tv.textContainer.lineFragmentPadding = 0
        tv.font               = UIFont.systemFont(ofSize: 15)
        tv.textColor          = .black
        tv.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        tv.setContentHuggingPriority(.defaultHigh, for: .vertical)
        return tv
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        guard uiView.text != text else { return }
        uiView.text = text
        uiView.invalidateIntrinsicContentSize()
    }
}
