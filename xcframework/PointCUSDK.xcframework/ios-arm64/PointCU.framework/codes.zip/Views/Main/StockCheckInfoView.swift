import SwiftUI

struct StockCheckInfoView: View {
    var body: some View {
        HStack(spacing: 0) {
            Button(action: {
                PointCUSDK.notifyMoveInventory()
            }) {
                HStack(spacing: 4) {
                    Text(Constants.Text.stockDesc)
                        .typography(.body1R, color: .black.opacity(0.95), alignment: .leading)
                    Text("👣")
                        .font(.system(size: 14))
                        .colorMultiply(.black)
                }
                .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)

                Spacer()

                Image(Constants.ImageName.icnInventory, bundle: .pointCU)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 44, height: 44)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 76)
        .padding(.horizontal, 20)
        .background(AppColor.grayButton244)
        .cornerRadius(16)
        .padding(.horizontal, Constants.Margin.horizontal)
        .padding(.vertical, Constants.Margin.vertical)
    }

//    private func showMoveStockConfirm() {
//        OverlayManager.shared.extraShowDual(
//            message: Constants.Text.moveToStcokDesc,
//            confirmAction: {
//                PointCUSDK.notifyMoveInventory()
//            }
//        )
//    }
}
