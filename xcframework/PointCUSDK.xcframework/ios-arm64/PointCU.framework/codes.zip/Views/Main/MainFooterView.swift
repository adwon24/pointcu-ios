//
//  DashboardFooterView.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/5/26.
//

import SwiftUI
import CoreMotion
import Combine

struct MainFooterView: View {
    @EnvironmentObject private var stepManager: StepManager
    
    @State private var isRequestingPermission = false
    
    var body: some View {
        VStack(spacing: 0) {
            AppColor.grayBgDivider248
                .frame(height: 8.0)
            
            HStack {
                Text(Constants.Text.trackingToggleTitle)
                    .typography(.body1B)
                    .frame(height: 28)
                
                Spacer()
                
                Toggle("", isOn: Binding(
                    get: { stepManager.isTrackingEnabled },
                    set: { newValue in
                        if newValue {
                            handleToggleOn()
                        } else {
                            showDisableConfirmPopup()
                        }
                    }
                ))
                .toggleStyle(CustomToggleStyle(width: 56, height: 28))
            }
            .padding(.horizontal, 30.0)
            .padding(.vertical, 26)
            
            // 하단 링크
            HStack(spacing: 0) {
                ZStack {
                    Button(action: {
                        SDKRouter.shared.presentFullScreen(.guide)
                    }) {
                        Text(Constants.Text.serviceInfo)
                            .typography(.body2R, color: AppColor.grayTextField148)
                    }
                }
                .frame(maxWidth: .infinity)
                
                Text("|")
                    .font(.system(size: 14))
                    .foregroundColor(AppColor.grayBorder204)
                
                ZStack {
                    Button(action: {
                        SDKRouter.shared.presentFullScreen(.faq)
                    }) {
                        Text(Constants.Text.faq)
                            .typography(.body2R, color: AppColor.grayTextField148)
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 72)
            .background(AppColor.grayBgDivider248)
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            if isRequestingPermission {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    processPermissionResult()
                }
            }
        }
    }
    
    private func handleToggleOn() {
        stepManager.checkMotionAuthorization { status in
            DispatchQueue.main.async {
                switch status {
                case .notDetermined:
                    // 권한 팝업 트리거: CMPedometer 더미 쿼리로 시스템 팝업을 띄움
                    // 결과는 didBecomeActive → processPermissionResult()에서 처리
                    isRequestingPermission = true
                    let pedometer = CMPedometer()
                    let now = Date()
                    pedometer.queryPedometerData(from: now.addingTimeInterval(-1), to: now) { _, _ in }
                case .authorized:
                    stepManager.isTrackingEnabled = true
                    showEnableInfoPopup()
                case .denied, .restricted:
                    showPermissionDeniedPopup()
                @unknown default:
                    break
                }
            }
        }
    }
    
    private func showEnableInfoPopup() {
        OverlayManager.shared.showSingle(
            title: nil,
            message: Constants.Text.trackingEnabledDesc,
            confirmTitle: Constants.Text.textConfirm,
            confirmAction: {
                stepManager.scrollToTopPublisher.send()
            }
        )
    }

    private func showDisableConfirmPopup() {
        OverlayManager.shared.showDual(
            title: nil,
            message: Constants.Text.trackingDisableDesc,
            confirmAction: {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation {
                        stepManager.isTrackingEnabled = false
                    }
                }
            }
        )
    }
    
    private func showPermissionDeniedPopup() {
        OverlayManager.shared.showDual(
            title: Constants.Text.motionPermissionDeniedTitle,
            message: Constants.Text.motionPermissionDeniedMessage,
            cancelTitle: Constants.Text.textLater,
            confirmTitle: Constants.Text.actionGoToSettings,
            confirmAction: {
//                PointCUSDK.notifyMoveOpenSetting()
                stepManager.openAppSettings()
            }
        )
    }
    
    private func processPermissionResult() {
        isRequestingPermission = false
        
        stepManager.checkMotionAuthorization { status in
            DispatchQueue.main.async {
                if status == .authorized {
                    stepManager.isTrackingEnabled = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        showEnableInfoPopup()
                    }
                } else {
                    stepManager.isTrackingEnabled = false
                }
            }
        }
    }
}
