//
//  MainBenefitListView.swift
//  PointCUSDK
//
//  ui/list의 display_order 순서대로 각 영역을 렌더링합니다.
//  - D0000244: 애드원 배너 버튼 (343×78)
//  - D0000265: 애드팝콘 배너 (303×80)
//  - D0000239: 룰렛 리스트
//  - D0000249: 복권 리스트
//  - D0000258: 가위바위보 버튼 (343×78)
//  - D0000259: 동전뒤집기 버튼 (343×78)
//  - D0000256: GreenP 오퍼월 버튼 (343×78)
//  - D0000257: NStation 오퍼월 버튼 (343×78)
//

import SwiftUI
import UIKit

struct MainBenefitListView: View {
    @EnvironmentObject private var appDataManager: AppDataManager
    private var sortedBannerList: [UiBannerItem] {
        CULog("[BannerList] attAuthorized=\(appDataManager.attAuthorized) items=\(appDataManager.uiListData?.bannerList.map { $0.detailId } ?? [])")
        return (appDataManager.uiListData?.bannerList ?? [])
            .filter { item in
                // ATT 권한 OFF 시 그린피(Adforus) 오퍼월 아이템 숨김
                // banner_info.offerwall_detail_id 로 그린피 여부 판단
                if !appDataManager.attAuthorized,
                   let offerwallId = item.bannerInfo?.offerwallDetailId,
                   UiOrderCode(rawValue: offerwallId) == .offerwallAdForusSDK {
                    CULog("[BannerList] 그린피 아이템 필터링: \(item.detailId) offerwallId=\(item.bannerInfo?.offerwallDetailId ?? "")")
                    return false
                }
                return true
            }
            .sorted { (Int($0.displayOrder) ?? 0) < (Int($1.displayOrder) ?? 0) }
    }

    var body: some View {
        // uiListData 없거나 bannerList 비어있으면 전체 숨김
        if !sortedBannerList.isEmpty {
            VStack(spacing: 0) {
                ForEach(sortedBannerList) { item in
                    bannerSection(for: item)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 8)
            .padding(.bottom, 8)
            .background(Color(red: 244/255, green: 244/255, blue: 244/255))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .padding(.horizontal, Constants.Margin.horizontal)
        }
    }

    @ViewBuilder
    private func bannerSection(for item: UiBannerItem) -> some View {
        if let orderCode = UiOrderCode(rawValue: item.detailId) {
            switch orderCode {

            // ── 애드원 배너 / 게임 / 오퍼월 버튼 — 높이 78pt, 직사각형 ────
            case .bannerAdwon, .serviceGameRPS, .serviceGameCoin,
                .offerwallAdForusSDK, .offerwallNStationSDK:
                BenefitBannerButtonView(item: item)
                    .frame(height: 78)
                    .background(Color(red: 0.957, green: 0.957, blue: 0.957))

            // ── NAM 네이티브 배너 — 높이 96pt, 배너 303×80 가운데 정렬 ────────
            case .bannerHomeSmall:
                NativeAdBannerContainerView()

            // ── 룰렛 영역 ────────────────────────────────────────────────────
            case .rouletteArea:
                BenefitSectionView(
                    benefits: appDataManager.rouletteBenefits,
                    type: .roulette
                )

            // ── 복권 영역 ────────────────────────────────────────────────────
            case .lotteryArea:
                BenefitSectionView(
                    benefits: appDataManager.lotteryBenefits,
                    type: .lottery
                )

            default:
                EmptyView()
            }
        } // if let orderCode
    }
}

// MARK: - 혜택 섹션 (룰렛 / 복권)

enum BenefitSectionType {
    case roulette
    case lottery

    var title: String {
        switch self {
        case .roulette: return Constants.Text.rouletteSection
        case .lottery:  return Constants.Text.lotterySection
        }
    }
}

struct BenefitSectionView: View {
    let benefits: [BenefitItem]
    let type: BenefitSectionType

    var body: some View {
        VStack(spacing: 0) {
            ForEach(benefits) { benefit in
                BenefitItemView(benefit: benefit, type: type)
            }
        }
    }
}

// MARK: - 룰렛 / 복권 아이템

struct BenefitItemView: View {
    let benefit: BenefitItem
    let type: BenefitSectionType

    /// display_time_yn == "Y"일 때 현재 시각이 범위 내인지 확인
    private var isWithinDisplayTime: Bool {
        guard benefit.displayTimeYn == "Y",
              !benefit.startTime.isEmpty,
              !benefit.endTime.isEmpty else { return true }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        formatter.timeZone = TimeZone.current
        let now = formatter.string(from: Date())
        return now >= benefit.startTime && now <= benefit.endTime
    }

    private var shouldHide: Bool {
        benefit.displayTimeYn == "Y" && !isWithinDisplayTime
    }

    var body: some View {
        if shouldHide {
            EmptyView()
        } else {
            Button(action: { handleTap() }) {
                HStack(spacing: 12) {
                    VStack(alignment: .center) {
                        Image(type == .roulette ? Constants.ImageName.rouletteThumb : Constants.ImageName.lotteryThumb, bundle: .pointCU)
                            .renderingMode(.original)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                    }
                    .frame(width: 50, height: 50)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(benefit.titleUpper)
                            .typography(.body1B)
                            .lineLimit(1)
                        Text(benefit.titleLower)
                            .typography(.body2R, color: AppColor.graySummaryText102)
                            .lineLimit(1)
                    }

                    Spacer()

                    Image(systemName: Constants.ImageName.listArrow)
                        .foregroundColor(AppColor.graySummaryText102)
                }
                .padding(.horizontal, Constants.Margin.horizontal)
                .frame(height: 78)
            }
        }
    }

    private func handleTap() {
        switch benefit.benefitType {
        case "R":
            SDKRouter.shared.presentFullScreen(.rouletteGame(benefit: benefit))
        case "L":
            SDKRouter.shared.presentFullScreen(.lotteryGame(benefit: benefit))
        default:
            CULog("[BenefitItemView] 알 수 없는 benefitType: \(benefit.benefitType)")
        }
    }
}

// MARK: - 혜택 버튼 (78pt) — 이미지 플레이스홀더 + 텍스트

struct BenefitBannerButtonView: View {
    let item: UiBannerItem

    var body: some View {
        Button(action: {
            BannerRouter.handle(item)
        }) {
            HStack(spacing: 12) {
                let imageURL: URL? = {
                    guard let urlString = item.bannerInfo?.url, !urlString.isEmpty else { return nil }
                    if urlString.hasPrefix("http") {
                        return URL(string: urlString)
                    } else {
                        let base = sdkBaseURL
                        return URL(string: base + urlString)
                    }
                }()

                AsyncImage(url: imageURL) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                    default:
                        RoundedRectangle(cornerRadius: 12)
                            .fill(AppColor.grayBgDivider248)
                            .frame(width: 50, height: 50)
                    }
                }
                .frame(width: 50, height: 50)
                .cornerRadius(12)

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.bannerInfo?.descriptionUpper ?? item.title ?? "")
                        .typography(.body1B)
                        .lineLimit(1)
                    Text(item.bannerInfo?.descriptionLower ?? "")
                        .typography(.body2R, color: AppColor.graySummaryText102)
                        .lineLimit(1)
                }

                Spacer()

                Image(systemName: Constants.ImageName.listArrow)
                    .foregroundColor(AppColor.graySummaryText102)
            }
            .padding(.horizontal, Constants.Margin.horizontal)
            .frame(maxWidth: .infinity)
            .frame(height: 78)
        }
    }
}

// MARK: - 특정 코너 radius 익스텐션

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}


// MARK: - NAM 네이티브 배너 컨테이너 (홈 배너)
// 전체 높이 96pt, 내부 배너 영역 303×80, 가운데 정렬

struct NativeAdBannerContainerView: View {
    @EnvironmentObject private var appDataManager: AppDataManager
    @State private var adLoaded: Bool? = nil
    @State private var namHeight: CGFloat = 0
    @State private var readyToLoad: Bool = false  // isIndicating 완료 후 배너 로드 허용
    private let listPad:          CGFloat = 16
    private let horizontalMargin: CGFloat = 20
    private let verticalPad:      CGFloat = 8
    private let minHeight:        CGFloat = 80

    private var bannerWidth: CGFloat {
        UIScreen.main.bounds.width - listPad * 2 - horizontalMargin * 2
    }

    private var defaultBannerHeight: CGFloat {
        ceil(bannerWidth * 68 / 320)
    }

    private var bannerHeight: CGFloat {
        namHeight > 0 ? max(namHeight, minHeight) : minHeight
    }

    var body: some View {
        Group {
            if readyToLoad && adLoaded != false {
                NativeAdBannerView(
                    placement:       .bannerHomeSmall,
                    externalLoaded:  $adLoaded,
                    externalHeight:  $namHeight,
                    containerWidth:  bannerWidth,
                    containerHeight: bannerHeight
                )
                .frame(height: adLoaded == true ? bannerHeight : 0)
                .padding(.horizontal, horizontalMargin)
                .frame(maxWidth: .infinity)
                .frame(height: adLoaded == true ? bannerHeight + verticalPad * 2 : 0)
                .clipped()
                .opacity(adLoaded == true ? 1 : 0)
            }
        }
        .onChange(of: appDataManager.isIndicating) { isIndicating in
            if !isIndicating && !readyToLoad {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    readyToLoad = true
                }
            }
        }
        .onAppear {
            if !appDataManager.isIndicating {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    readyToLoad = true
                }
            }
            // 미디에이션 데이터 없으면 타임아웃 후 숨김
            DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
                if adLoaded == nil && !MediationManager.shared.isReady {
                    adLoaded = false
                }
            }
        }
    }
}

// MARK: - NAM 네이티브 배너 컨테이너 (룰렛/복권 하단 배너)
// 전체 높이 80pt, 가로 Full (375pt 기준)

struct NativeAdGameBannerView: View {
    let placement: AdsPlacementType
    var onHeightChanged: ((CGFloat) -> Void)? = nil
    @State private var adLoaded: Bool? = nil
    @State private var namHeight: CGFloat = 0
    private let minHeight: CGFloat = 80

    // 배너 가로 폭 = 화면 전체 폭
    private var bannerWidth: CGFloat {
        UIScreen.main.bounds.width
    }

    private var containerHeight: CGFloat {
        namHeight > 0 ? max(namHeight, minHeight) : minHeight
    }

    var body: some View {
        if adLoaded != false {
            NativeAdBannerView(
                placement:       placement,
                externalLoaded:  $adLoaded,
                externalHeight:  $namHeight,
                containerWidth:  bannerWidth,
                containerHeight: containerHeight
            )
            .frame(width: bannerWidth, height: adLoaded == true ? containerHeight : 0)
            .frame(maxWidth: .infinity)
            .opacity(adLoaded == true ? 1 : 0)
            .onChange(of: adLoaded) { loaded in
                if loaded == true {
                    onHeightChanged?(containerHeight)
                }
            }
        }
    }
}

// MARK: - NAM 네이티브 배너 컨테이너 (걸음 복권/미션 화면 하단)
// 전체 너비 - 좌우 마진 16, 하단 마진 12, 바닥에 고정

struct NativeAdMissionBannerView: View {
    @State private var adLoaded: Bool? = nil
    @State private var namHeight: CGFloat = 0
    private let horizontalMargin: CGFloat = 16
    private let bottomMargin:     CGFloat = 12
    private let minHeight:        CGFloat = 80

    // 실제 배너 가로 폭 = 화면 폭 - 좌우 마진(16×2)
    private var bannerWidth: CGFloat {
        UIScreen.main.bounds.width - horizontalMargin * 2
    }

    private var defaultBannerHeight: CGFloat {
        ceil(bannerWidth * 68 / 320)
    }

    private var bannerHeight: CGFloat {
                namHeight > 0 ? max(namHeight, minHeight) : minHeight
    }

    var body: some View {
        if adLoaded != false {
            NativeAdBannerView(
                placement:       .bannerMissionTicket,
                externalLoaded:  $adLoaded,
                externalHeight:  $namHeight,
                containerWidth:  bannerWidth,
                containerHeight: bannerHeight
            )
            .frame(width: bannerWidth, height: adLoaded == true ? bannerHeight : 0)
            .frame(maxWidth: .infinity)
            .opacity(adLoaded == true ? 1 : 0)
            .padding(.bottom, bottomMargin)  // 배너 영역 아래 12pt 여백 (overlay 바닥 기준)
        }
    }
}
