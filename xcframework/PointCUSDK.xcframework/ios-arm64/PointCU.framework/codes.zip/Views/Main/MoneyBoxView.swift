//
//  MoneyBoxView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/29/26.
//
//  클릭 흐름:
//  1. D0000274(저금통) 광고 순환 (MobiWith → AdPopcornRewardBanner 등)
//  2. 광고 완료 → confirmMoneyBox(moneyboxId:moneyboxScheduleId:)
//  3. 결과 팝업
//

import SwiftUI
import AdPopcornSSP

struct MoneyBoxView: View {
    let moneyBox: MoneyBoxResponse

    @State private var isAdLoading: Bool = false

    private var imageFullUrl: String {
        let base = sdkBaseURL
        return base + moneyBox.imageUrl
    }

    var body: some View {
        Button(action: {
            if moneyBox.moneyBoxId != nil, moneyBox.moneyBoxScheduleId != nil {
                Task { await loadAndShowAd() }
            } else {
                OverlayManager.shared.showToast(Constants.Text.noAvailableAdTime)
            }
        }) {
            VStack(spacing: 0) {
                // URL 이미지 — 로드 성공 시에만 하단 텍스트 표시
                AsyncImage(url: URL(string: imageFullUrl)) { phase in
                    switch phase {
                    case .success(let image):
                        VStack(spacing: 0) {
                            image
                                .resizable()
                                .scaledToFit()
                                .frame(width: 70, height: 50)
                                .padding(.top, 4)
 
                            Text(moneyBox.displayDescription)
                                .typography(.caption1R, color: AppColor.grayButtonText68)
                                .lineLimit(1)
                                .fixedSize()
                                .padding(.horizontal, 10)  // 텍스트 기준 좌우 10pt 패딩
                                .frame(height: 22)
                                .background(
                                    RoundedRectangle(cornerRadius: 11)
                                        .fill(.white)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 11)
                                                .stroke(AppColor.grayDisalbeBg221, lineWidth: 1.0)
                                        )
                                )
                                .padding(.bottom, 2)
                        }
                    case .failure, .empty:
                        EmptyView()
                    @unknown default:
                        EmptyView()
                    }
                }
            }
            .frame(width: 80, height: 80)
        }
        .disabled(isAdLoading)
    }

    // MARK: - 광고 순환

    private func loadAndShowAd() async {
        guard !isAdLoading else { return }
        isAdLoading = true
        OverlayManager.shared.showIndicator()
        let totalCount = MediationManager.shared.ads(for: AdsPlacementType.moneyBox.rawValue).count
        guard totalCount > 0 else {
            // 광고 없음 → 바로 confirm
            await confirmMoneyBox()
            return
        }
        tryShowAd(remainingCount: totalCount)
    }

    private func tryShowAd(remainingCount: Int) {
        guard remainingCount > 0 else {
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.noAvailableAdDesc, confirmAction: {})
            isAdLoading = false
            return
        }

        guard let ad = MediationManager.shared.nextAd(for: .moneyBox) else {
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.noAvailableAdDesc, confirmAction: {})
            isAdLoading = false
            return
        }

        // nextAd 후 인덱스 전진 (다음 실패 시 다음 광고로 순환)
        MediationManager.shared.advanceIndex(for: .moneyBox)

        CULog("[MoneyBox] moneyBoxId=\(moneyBox.moneyBoxId, default: "0"), moneyBoxScheduleId=\(moneyBox.moneyBoxScheduleId, default: "0")")

        let onFailRetry: () -> Void = {
            Task { @MainActor in tryShowAd(remainingCount: remainingCount - 1) }
        }

        switch AdsType.parse(ad.priorityCode) {
        case .adPopcornReward:
            showAdPopcornReward(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .adPopcornRewardBanner:
            showAdPopcornRewardBanner(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .mobiWithPopup:
            showMobiWithAd(zone: ad.adKey, onFailRetry: onFailRetry)
        default:
            onFailRetry()
        }
    }

    // MARK: - 광고 타입별 처리

    private func showAdPopcornReward(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await confirmMoneyBox() }; return
        }
        let ad = AdPopcornSSPRewardVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.rewardAd   = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in await self.confirmMoneyBox() } }
        AdPopcornAdDelegate.shared.onFail     = { Task { @MainActor in onFailRetry() } }
        ad?.delegate = AdPopcornAdDelegate.shared
        ad?.loadRequest()
    }

    private func showAdPopcornRewardBanner(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await confirmMoneyBox() }; return
        }
        // adKey: "adpopcorn_key,mobiwith_key" 형태
        let keyParts     = adKey.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
        let adPopcornKey = keyParts.count >= 1 ? keyParts[0] : adKey
        let mobiWithKey  = keyParts.count >= 2 ? keyParts[1] : ""

        let vc = AdPopcornWebAdViewController(
            placementId: adPopcornKey,
            zoneId:      mobiWithKey,
            title:       Constants.Text.showAdForReward,
            subTitle:    Constants.Text.mustOverFiveSeconds,
            onComplete:  { Task { @MainActor in await self.confirmMoneyBox() } },
            onFail:      { Task { @MainActor in onFailRetry() } },
            onClose:     { isAdLoading = false }
        )
        topVC.present(vc, animated: true)
    }

    private func showMobiWithAd(zone: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await confirmMoneyBox() }; return
        }
        let vc = MobiWithAdViewController(
            zoneId:     zone,
            onComplete: { Task { @MainActor in await self.confirmMoneyBox() } },
            onFail:     { Task { @MainActor in onFailRetry() } },
            onClose:    { isAdLoading = false }
        )
        topVC.present(vc, animated: true)
    }

    // MARK: - 광고 완료 → confirm

    private func confirmMoneyBox() async {
        OverlayManager.shared.hideIndicator()
        do {
            let result = try await AppDataManager.shared.confirmMoneyBox(
                moneyboxId:         moneyBox.moneyBoxId ?? 0,
                moneyboxScheduleId: moneyBox.moneyBoxScheduleId ?? 0
            )
            OverlayManager.shared.showReward(
                imageName: Constants.ImageName.fireCracker,
                message: "\(result.winPoint)\(Constants.Text._getWinPointMessage)"
            )
            await AppDataManager.shared.refreshMoneyBox()
        } catch {
            OverlayManager.shared.showSingle(
                message: Constants.Text.getWinPointFailureMessage,
                confirmAction: {}
            )
        }
        isAdLoading = false
    }
}
