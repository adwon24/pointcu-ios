//
//  StepProgressView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/16/26.
//

import SwiftUI

struct StepProgressView: View {
    @EnvironmentObject private var appDataManager: AppDataManager

    @Binding var showToast: Bool
    @Binding var toastMessage: String

    let currentSteps: Int

    // [수정 1] usedTicketCount를 하드코딩 0에서 missionData 기반으로 변경
    // 스크롤 위치 및 onChange 트리거에 실제 사용된 티켓 수가 반영됨
    private var usedTicketCount: Int {
        appDataManager.missionData?.ticketUseCount ?? 0
    }

    @State private var animatedTrackWidth: CGFloat = 10

    private let spacing: CGFloat = 12
    private let leftMargin: CGFloat = 16
    private let buttonWidth: CGFloat = 75
    private let buttonHeight: CGFloat = 40
    private let trackHeight: CGFloat = 10
    private let checkStatusSize: CGFloat = 36

    var body: some View {
        if appDataManager.rewardMilestones.isEmpty {
            // mission/detail 실패 등으로 milestones 없으면 전체 숨김
            EmptyView()
        } else {
            GeometryReader { geo in
                // milestones를 로컬 변수로 캡처 — nodePositions와 항상 동일한 count 보장
                let milestones = appDataManager.rewardMilestones
                let count = milestones.count
                
                let totalContentWidth = leftMargin
                + CGFloat(count) * buttonWidth
                + CGFloat(max(0, count - 1)) * spacing
                + leftMargin
                
                let trackLeftEdge: CGFloat = leftMargin
                let trackRightEdge: CGFloat = totalContentWidth - leftMargin
                let grayTrackWidth = trackRightEdge - trackLeftEdge
                
                let nodePositions: [CGFloat] = (0..<count).map { i in
                    let buttonLeftEdge = leftMargin + CGFloat(i) * (buttonWidth + spacing)
                    let buttonRightEdge = buttonLeftEdge + buttonWidth
                    
                    if i == 0 { return buttonLeftEdge + 5 }
                    else if i == count - 1 { return buttonRightEdge - 5 }
                    else { return buttonLeftEdge + (buttonWidth / 2) }
                }
                
                let purpleRightEdgeX = calculateRightEdgeX(currentSteps: currentSteps, nodePositions: nodePositions, milestones: milestones)
                let targetPurpleTrackWidth = max(10, purpleRightEdgeX - trackLeftEdge)
                
                let halfButtonWidth = buttonWidth / 2
                
                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(alignment: .top, spacing: -4) {
                            ForEach(Array(milestones.enumerated()), id: \.element.id) { index, milestone in
                                HStack(spacing: 0) {
                                    Color.clear
                                        .frame(width: leftMargin, height: 1)
                                    
                                    VStack(spacing: 0) {
                                        let nodeOffsetX: CGFloat = {
                                            if index == 0 { return 5 - halfButtonWidth }
                                            else if index == count - 1 { return halfButtonWidth - 5 }
                                            else { return 0 }
                                        }()
                                        
                                        Circle()
                                            .fill(nodePositions.indices.contains(index) && (trackLeftEdge + animatedTrackWidth) >= nodePositions[index] ? AppColor.stepProgressMarked : AppColor.grayDisalbeBg221)
                                            .frame(width: 6, height: 6)
                                            .offset(x: nodeOffsetX)
                                            .frame(height: trackHeight)
                                            .zIndex(1)
                                        
                                        Spacer().frame(height: 11)
                                        
                                        // [수정 2] formatStepLabel(milestone.step) 대신
                                        // buildMilestones에서 이미 가공된 milestone.displayText 사용
                                        // customDisplayTextYn == "Y"인 경우 서버 텍스트가 그대로 표시됨
                                        Text(milestone.displayText)
                                            .typography(.summary1R)
                                            .frame(width: buttonWidth)
                                            .frame(height: 15)
                                        
                                        Spacer().frame(height: 10)
                                        
                                        rewardButton(for: milestone)
                                            .frame(height: buttonHeight)
                                    }
                                    .frame(width: buttonWidth)
                                }
                                .id(milestone.id)
                            }
                        }
                        .padding(.trailing, leftMargin)
                        .frame(height: 87, alignment: .top)
                        .background(
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: trackHeight / 2)
                                    .fill(AppColor.grayBorderNBg238)
                                    .frame(width: grayTrackWidth, height: trackHeight)
                                RoundedRectangle(cornerRadius: trackHeight / 2)
                                    .fill(AppColor.primaryPurple)
                                    .frame(width: animatedTrackWidth, height: trackHeight)
                            }
                                .offset(x: leftMargin, y: 0),
                            alignment: .topLeading
                        )
                    }
                    .onAppear {
                        animatedTrackWidth = targetPurpleTrackWidth
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                            // status == .completed 인 마지막 milestone으로 스크롤
                            let lastIssuedMilestone = milestones.last(where: { $0.status == .completed })
                            let scrollId = lastIssuedMilestone?.id ?? milestones.first?.id
                            withAnimation(.easeInOut) {
                                proxy.scrollTo(scrollId, anchor: .leading)
                            }
                        }
                    }
                    .onChange(of: appDataManager.missionRefreshTrigger) { _ in
                        // refreshMainData 완료 후 스크롤 위치 갱신
                        let milestones = appDataManager.rewardMilestones
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                            let lastCompleted = milestones.last(where: { $0.status == .completed })
                            let scrollId = lastCompleted?.id ?? milestones.first?.id
                            withAnimation(.easeInOut) {
                                proxy.scrollTo(scrollId, anchor: .leading)
                            }
                        }
                    }
                    .onChange(of: targetPurpleTrackWidth) { newValue in
                        withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                            animatedTrackWidth = newValue
                        }
                    }
                }
            }
        }
    }

    // MARK: - 트랙 계산

    private func calculateRightEdgeX(currentSteps: Int, nodePositions: [CGFloat], milestones: [RewardMilestone]) -> CGFloat {
        // nodePositions와 milestones 개수가 불일치하면 안전하게 종료
        guard milestones.count > 1,
              nodePositions.count == milestones.count,
              let firstStep = milestones.first?.step,
              let lastStep  = milestones.last?.step,
              let lastPos   = nodePositions.last else {
            return nodePositions.first ?? 16
        }

        let trackRadius = trackHeight / 2

        if currentSteps <= firstStep { return nodePositions[0] + trackRadius }
        if currentSteps >= lastStep  { return lastPos + trackRadius }

        for i in 0..<(milestones.count - 1) {
            let startStep = milestones[i].step
            let endStep   = milestones[i + 1].step
            guard nodePositions.indices.contains(i + 1) else { break }

            if currentSteps >= startStep && currentSteps <= endStep {
                let startX = nodePositions[i] + trackRadius
                let endX   = nodePositions[i + 1] + trackRadius
                let ratio  = CGFloat(currentSteps - startStep) / CGFloat(max(endStep - startStep, 1))
                return startX + ratio * (endX - startX)
            }
        }
        return lastPos + trackRadius
    }

    // MARK: - 보상 버튼

    @ViewBuilder
    private func rewardButton(for milestone: RewardMilestone) -> some View {
        switch milestone.status {
        case .completed:
            Image(Constants.ImageName.missionCheckMark, bundle: .pointCU)
                .resizable()
                .scaledToFit()
                .frame(width: checkStatusSize, height: checkStatusSize)
                .frame(width: buttonWidth, height: buttonHeight)

        case .available:
            Button(action: {
                handleAvailableReward(for: milestone)
            }) {
                rewardButtonLabel(for: milestone, isLocked: false)
            }

        case .locked:
            // [수정 3] locked 상태는 토스트 없이 무반응 처리
            // 탭 자체를 막으려면 .disabled(true) 사용 가능하나
            // 시각적 피드백(버튼 외형)은 그대로 유지하기 위해 빈 액션으로 처리
            Button(action: {}) {
                rewardButtonLabel(for: milestone, isLocked: true)
            }
            .disabled(true)
        }
    }

    /// available 상태 버튼 탭 처리
    private func handleAvailableReward(for milestone: RewardMilestone) {
        // 순차 수령 체크: 앞 순서 available 버튼이 있으면 토스트
        let firstAvailableId = appDataManager.rewardMilestones.first { $0.status == .available }?.id
        guard firstAvailableId == milestone.id else {
            toastMessage = Constants.Text.getPrevStepMissonReward
            showToast = true
            return
        }

        switch milestone.rewardType {
        case .ticket:
            // advertisement_yn 분기:
            // "Y" → 게임 화면 진입 → 광고 시청 → 서버 포인트 지급 → 스크래치
            // "N" → 게임 화면 없이 포인트 수령 API 직접 호출
            // ticketIssue 응답이 UI 결정 기준
            let needsAd = appDataManager.ticketIssueMission?.scheduleList
                .first { $0.stepCountDuration == milestone.step }
                .map { $0.advertisementYn == "Y" } ?? true

            if needsAd {
                SDKRouter.shared.presentFullScreen(.stepMissionGame)
            } else {
                confirmAndShowReward()
            }

        case .point:
            confirmAndShowReward()
            break
        }
    }
    
    /// ticketConfirm 호출 → 전역 로딩 → 결과 팝업
    private func confirmAndShowReward() {
        guard let missionId = appDataManager.missionData?.missionId else { return }
        guard !OverlayManager.shared.isIndicating else { return }
 
        Task { @MainActor in
            OverlayManager.shared.showIndicator()
            defer { OverlayManager.shared.hideIndicator() }
            do {
                let winPoint = try await AppDataManager.shared.confirmTicket(missionId: missionId)
                OverlayManager.shared.showReward(
                    imageName: Constants.ImageName.fireCracker,
                    message: "\(winPoint)P 를 받았어요",
                    confirmAction: {
                        // 팝업이 메인 위에 뜨므로 dismiss 없이 바로 갱신
                        Task { await AppDataManager.shared.refreshMainData() }
                    }
                )
            } catch {
                OverlayManager.shared.showSingle(
                    message: Constants.Text.getWinPointFailureMessage
                )
            }
        }
    }

    /// 버튼 라벨 공통 뷰
    @ViewBuilder
    private func rewardButtonLabel(for milestone: RewardMilestone, isLocked: Bool) -> some View {
        HStack(spacing: 2) {
            if let imageName = badgeImageName(for: milestone.rewardType, status: milestone.status) {
                Image(imageName, bundle: .pointCU)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
            }
            Text(buttonLabelText(for: milestone.rewardType))
                .typography(.body2B, color: isLocked ? AppColor.grayTextField170 : .black)
                .fixedSize()
        }
        .frame(width: buttonWidth, height: buttonHeight)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(AppColor.grayBgDivider248)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(AppColor.grayBorderEEEDF5, lineWidth: 1)
                )
        )
    }

    // MARK: - 유틸리티

    private func badgeImageName(for type: RewardMilestone.RewardType, status: RewardMilestone.RewardStatus) -> String? {
        let isOn = status == .available
        switch type {
        case .point:  return isOn ? Constants.ImageName.pointBadgeOn  : Constants.ImageName.pointBadgeOff
        case .ticket: return isOn ? Constants.ImageName.ticketBadgeOn : Constants.ImageName.ticketBadgeOff
//        case .check:  return isOn ? Constants.ImageName.missionCheckMark : nil
        }
    }

    private func buttonLabelText(for type: RewardMilestone.RewardType) -> String {
        switch type {
        case .point:  return Constants.Text.point
        case .ticket: return Constants.Text.ticket
//        case .check:  return ""
        }
    }
}
