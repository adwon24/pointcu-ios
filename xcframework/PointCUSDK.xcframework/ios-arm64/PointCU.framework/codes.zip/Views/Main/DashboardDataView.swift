//
//  DashboardDataView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/20/26.
//

import SwiftUI

struct DashboardDataView: View {
    let steps: String
    let distance: String
    let calories: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(Constants.Text.dashboardDataTitle)
                .typography(.body1B, color: .black, alignment: .leading)
                .frame(height: 24)
            
            Spacer()
                .frame(height: 8)
            
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(steps)
                    .typography(.robotoH1B, color: .black)
                Text(Constants.Text.steps)
                    .typography(.body1R, color: AppColor.graySummaryText102)
            }
            .padding(.top, 0)
            
            HStack(alignment: .center, spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 2) {
                    Text(distance)
                        .typography(.robotoBody2R)
                    Text(Constants.Text.km)
                        .typography(.robotoCaption1R, color: AppColor.graySummaryText102)
                }
                
                Text("|")
                    .typography(.robotoCaption1R, color: AppColor.grayBorder204)
                
                HStack(alignment: .firstTextBaseline, spacing: 2) {
                    Text(calories)
                        .typography(.robotoBody2R)
                    Text(Constants.Text.kcal)
                        .typography(.robotoCaption1R, color: AppColor.graySummaryText102)
                }
            }
            .padding(.bottom, 0)
            .frame(height: 20)
        }
        .frame(width: 180, height: 96, alignment: .topLeading)
    }
}
