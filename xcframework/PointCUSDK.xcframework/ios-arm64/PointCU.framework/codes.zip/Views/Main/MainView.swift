//
//  MainView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/16/26.
//

import SwiftUI
import Combine

struct MainView: View {
    @Environment(\.dismiss) private var dismiss
    
    @EnvironmentObject private var appDataManager: AppDataManager
    @EnvironmentObject private var stepManager: StepManager
    @ObservedObject private var router = SDKRouter.shared
    
    @State private var showToast = false
    @State private var showMissionToast = false
    @State private var toastMessage = ""
    
    private let dashboardViewHeight: CGFloat = 330
    
    init() {}
    
    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(title: Constants.Text.mainTitle, backAction: {
                dismiss()
            })

            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 0) {
                        Color.clear
                            .frame(height: 0)
                            .id(Constants.Id.mainScrollTopId)
                        
                        ZStack {
                            DashboardBackgroundview(isTrackingOn: $stepManager.isTrackingEnabled)
                            
                            // tracking OFF 시 frozen 값 표시, ON 시 실시간 값 표시
                            DashboardDataView(
                                steps: formatNumber(stepManager.isTrackingEnabled
                                    ? stepManager.todaySteps
                                    : stepManager.frozenSteps),
                                distance: formatFloat(stepManager.isTrackingEnabled
                                    ? stepManager.todayDistance
                                    : stepManager.frozenDistance),
                                calories: formatDecimal(stepManager.isTrackingEnabled
                                    ? stepManager.todayCalories
                                    : stepManager.frozenCalories)
                            )
                            .padding(.top, 36)
                            .padding(.leading, 24)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                            
                            if appDataManager.moneyBoxEnabled, let moneyBox = appDataManager.moneyBoxData, moneyBox.isVisible {
                                MoneyBoxView(moneyBox: moneyBox)
                                    .padding(.top, 60)
                                    .padding(.trailing, 20)
                                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                            }
                        }
                        .frame(height: 330)
                        
                        if stepManager.isTrackingEnabled {
                            if appDataManager.isIndicating || !appDataManager.isInitialized {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .gray))
                                    .frame(height: 90)
                            } else {
                                StepProgressView(
                                    showToast: $showMissionToast, toastMessage: $toastMessage,
                                    currentSteps: stepManager.todaySteps
                                )
                                .frame(height: 87)
                                .padding(.bottom, 3)
                                .transition(.opacity)
                                .targetRelativeToast(
                                    isPresented: $showMissionToast,
                                    message: toastMessage,
                                    spacing: 22)
                            }
                        } else {
                            TrackingDisabledView(onScrollToBottom: {
                                withAnimation(.easeInOut) {
                                    proxy.scrollTo(Constants.Id.mainScrollBottomId, anchor: .bottom)
                                }
                            })
                            .transition(.opacity)
                        }
                        
                        // 재고 확인 뷰
                        StockCheckInfoView()
                        
                        MainBenefitListView()
                        
                        // 통계보기 뷰
                        HStack {
                            Button(action: {
                                router.presentFullScreen(.statistics)
                            }) {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(Constants.Text.statsDesc).typography(.body1R, color: .black.opacity(0.8))
                                    Text(Constants.Text.showStats).typography(.h5B)
                                }
                                Spacer()
                                Image(systemName: Constants.ImageName.listArrow)
                                    .foregroundColor(Color.gray)
                            }
                        }
                        .frame(height: 92)
                        .padding(.horizontal, 20)
                        .background(AppColor.grayButton244)
                        .cornerRadius(16)
                        .padding(.horizontal, Constants.Margin.horizontal)
                        .padding(.vertical, Constants.Margin.vertical)
                        
                        // Main Footer
                        MainFooterView()
                            .id(Constants.Id.mainScrollBottomId)
                    }
                }
                .preferredColorScheme(.light)
                .edgesIgnoringSafeArea(.top)
                .onReceive(stepManager.scrollToTopPublisher) { _ in
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                        proxy.scrollTo(Constants.Id.mainScrollTopId, anchor: .top)
                    }
                }
                .sheet(item: $router.activeSheet) { route in
                    route.destination
                }
                .fullScreenCover(item: $router.activeFullScreen, onDismiss: {
                    // fullScreenCover 닫힐 때 데이터 갱신
                    CULog("[MainView] fullScreenCover onDismiss → refreshMainData")
                    Task { await appDataManager.checkAndRefresh() }
                }) { route in
                    route.destination
                }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .animation(.default, value: appDataManager.isIndicating)
        .customToast(isPresented: $showToast, message: toastMessage)
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in
            // 매 정시에 데이터 갱신
            let calendar = Calendar.current
            let now = Date()
            let minute = calendar.component(.minute, from: now)
            let second = calendar.component(.second, from: now)
            if minute == 0 && second == 0 {
                Task {
                    OverlayManager.shared.showIndicator()
                    await appDataManager.checkAndRefresh()
                    OverlayManager.shared.hideIndicator()
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            Task {
                await appDataManager.checkAndRefresh()
                await MediationManager.shared.fetchIfNeeded()
            }
        }
    }
}
