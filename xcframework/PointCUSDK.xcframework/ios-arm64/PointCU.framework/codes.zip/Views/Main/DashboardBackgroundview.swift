//
//  WalkBackgroundView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/8/26.
//

import SwiftUI
import ImageIO
import Combine

struct DashboardBackgroundview: View {
    @Binding var isTrackingOn: Bool
    
    init(isTrackingOn: Binding<Bool>) {
        self._isTrackingOn = isTrackingOn
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            GeometryReader { _ in
                let contentWidth: CGFloat = 750
                InfiniteScroller(// 35 -> 10
                    speed: isTrackingOn ? 10.0 : 0.0,
                    contentWidth: contentWidth,
                    direction: .rightToLeft
                ) {
                    if let path = Bundle.pointCU.path(forResource: Constants.ImageName.bearWalkBackground, ofType: "webp"),
                       let image = UIImage(contentsOfFile: path) {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(width: contentWidth, height: 330)
                    } else {
                        Color.white
                            .frame(width: contentWidth, height: 330)
                    }
                }
                .id("bg_\(isTrackingOn)")
            }
            .frame(height: 330)
            .clipped()
            
            AnimatedBearView(isTrackingOn: $isTrackingOn)
                .padding(.bottom, 0)
        }
        .frame(height: 330)
        .ignoresSafeArea(edges: .top)
    }
}

struct AnimatedBearView: View {
    @StateObject private var player = AnimationPlayer()
    @Binding var isTrackingOn: Bool
    
    init(isTrackingOn: Binding<Bool>) {
        self._isTrackingOn = isTrackingOn
    }
    
    var body: some View {
        ZStack {
            if let currentFrame = player.currentFrame {
                Image(uiImage: currentFrame)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 162, height: 165)
                    .padding(.bottom, 23)
            } else {
                Color.clear
                    .frame(width: 162, height: 165)
                    .padding(.bottom, 23)
            }
        }
        .frame(width: 216, height: 216, alignment: .bottomLeading)
        .onAppear {
            player.loadWebP(named: Constants.ImageName.bear, bundle: .pointCU)
            if isTrackingOn {
                player.startAnimation()
            } else {
                player.stopAtFrame(index: 0)
            }
        }
        .onChange(of: isTrackingOn) { isOn in
            if isOn {
                player.startAnimation()
            } else {
                player.stopAtFrame(index: 0) // 정지 시 0번 프레임 고정
            }
        }
        .onDisappear {
            player.stopAnimation()
        }
        .drawingGroup()
    }
}

class AnimationPlayer: ObservableObject {
    @Published var currentFrame: UIImage?
    
    struct FrameData {
        let image: UIImage
        let duration: TimeInterval
    }
    
    private var animatedFrames: [FrameData] = []
    private var currentFrameIndex: Int = 0
    private var timer: Timer?
    
    init() {}
    
    // MARK: - 1. 15프레임 최적화 로드 함수
    func loadWebP(named fileName: String, bundle: Bundle = .main) {
        guard let url = bundle.url(forResource: fileName, withExtension: "webp"),
              let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil) else {
            return
        }
        
        let frameCount = CGImageSourceGetCount(imageSource)
        var extractedFrames: [FrameData] = []
        
//        let durations: [TimeInterval] = [
//            0.04, 0.09, 0.06, 0.09, 0.06,
//            0.09, 0.06, 0.09, 0.06, 0.09,
//            0.06, 0.09, 0.06, 0.09, 0.06
//        ]
        let durations: [TimeInterval] = [
            0.04, 0.06, 0.06, 0.06, 0.06,
            0.06, 0.06, 0.06, 0.06, 0.06,
            0.06, 0.06, 0.06, 0.06, 0.06
        ]
        
        // 파일에 있는 프레임 수와 durations 배열 중 더 작은 값을 기준으로 안전하게 루프
        let loopCount = min(frameCount, durations.count)
        
        for i in 0..<loopCount {
            if let cgImage = CGImageSourceCreateImageAtIndex(imageSource, i, nil) {
                let frameData = FrameData(image: UIImage(cgImage: cgImage), duration: durations[i])
                extractedFrames.append(frameData)
            }
        }
        
        self.animatedFrames = extractedFrames
        
        if !animatedFrames.isEmpty {
            self.currentFrame = animatedFrames[0].image
        }
    }
    
    func stopAtFrame(index: Int) {
        self.stopAnimation()
        if animatedFrames.indices.contains(index) {
            self.currentFrame = animatedFrames[index].image
        }
    }
    
    func startAnimation() {
        stopAnimation()
        guard !animatedFrames.isEmpty else { return }

        scheduleNextFrame()
    }
    
    // MARK: - 2. 가변 딜레이를 처리하는 핵심 재귀 타이머
    private func scheduleNextFrame() {
        guard !animatedFrames.isEmpty else { return }
        
        let frameData = animatedFrames[currentFrameIndex]
        self.currentFrame = frameData.image
        
        // repeats: false로 단발성 타이머를 생성하되, 해당 프레임의 고유 duration을 사용
        let nextTimer = Timer(timeInterval: frameData.duration, repeats: false) { [weak self] _ in
            guard let self = self else { return }
            
            // 다음 인덱스로 이동
            self.currentFrameIndex = (self.currentFrameIndex + 1) % self.animatedFrames.count
            // 다음 프레임을 위한 타이머 다시 예약 (재귀 호출)
            self.scheduleNextFrame()
        }
        
        // 스크롤 중에도 멈추지 않도록 .common 모드 유지
        RunLoop.current.add(nextTimer, forMode: .common)
        self.timer = nextTimer
    }
    
    func stopAnimation() {
        timer?.invalidate()
        timer = nil
    }
}
