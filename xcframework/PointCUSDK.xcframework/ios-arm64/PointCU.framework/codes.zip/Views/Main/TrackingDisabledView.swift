//
//  TrackingDisabledView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/18/26.
//

import SwiftUI

struct TrackingDisabledView: View {
    var onScrollToBottom: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
                .frame(height: 10)
            
            Text(Constants.Text.trackingDisabledTitle)
                .typography(.body1B)
                .frame(height: 24)
            
            Spacer()
                .frame(height: 2)
            
            Text(Constants.Text.trackingDisabledDesc)
                .typography(.summary1R, color: AppColor.graySummaryText102)
                .frame(height: 18)
            
            Spacer()
            
            Button(action: {
                onScrollToBottom()
            }) {
                Image(Constants.ImageName.moveBottomArrow, bundle: .pointCU)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 90)
    }
}
