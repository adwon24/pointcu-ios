//
//  StepStatisticsView.swift
//  PointCUSDK
//

import SwiftUI

enum StatTab: Int, CaseIterable {
    case twoWeeksAgo = 0
    case oneWeekAgo = 1
    case yesterday = 2
    
    var title: String {
        switch self {
        case .twoWeeksAgo: return Constants.Text.twoWeekAgo
        case .oneWeekAgo: return Constants.Text.oneWeekAgo
        case .yesterday: return Constants.Text.yesterday
        }
    }
    
    var headerPrefix: String {
        switch self {
        case .twoWeeksAgo: return Constants.Text.twoWeekAgo
        case .oneWeekAgo: return Constants.Text.oneWeekAgo
        case .yesterday: return Constants.Text.latest
        }
    }
}

// MARK: - 데이터 모델
struct DailyStat: Identifiable {
    let id = UUID()
    let date: String
    let steps: Int
}

struct StepStatisticsView: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var navigateToFAQ: Bool = false
    @State private var selectedTab: StatTab = .yesterday
    @State private var isLoading: Bool = true

    // 21일치 전체 데이터
    // 인덱스 0~6: 2주 전, 7~13: 1주 전, 14~20: 어제(최근 7일)
    @State private var allData: [DailyStat] = []

    // 현재 선택된 탭에 맞는 7일치 데이터 슬라이싱
    var currentWeekData: [DailyStat] {
        let startIndex = selectedTab.rawValue * 7
        let endIndex = startIndex + 7
        guard allData.count >= 21 else { return [] }
        return Array(allData[startIndex..<endIndex])
    }

    // 현재 탭의 평균 걸음수
    var currentAverageSteps: Int {
        let total = currentWeekData.reduce(0) { $0 + $1.steps }
        return currentWeekData.isEmpty ? 0 : total / 7
    }

    // 동적 최댓값: 기본 10,000. 해당 주에 1만을 넘는 날이 있으면 그 값을 사용
    var dynamicMaxSteps: Int {
        let maxInWeek = currentWeekData.map { $0.steps }.max() ?? 0
        return max(maxInWeek, 10000)
    }

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: Constants.Text.statistics,
                backAction: {
                    presentationMode.wrappedValue.dismiss()
                }
            )

            if isLoading {
                Spacer()
                ProgressView()
                Spacer()
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 0) {
                        VStack(alignment: .leading, spacing: -2) {
                            Text("\(selectedTab.headerPrefix) \(Constants.Text.oneWeekPerDayAvg)")
                                .typography(.robotoH2B)

                            (
                                Text("\(currentAverageSteps.formattedWithSeparator)\(Constants.Text.steps)")
                                    .foregroundColor(AppColor.primaryPurple)
                                +
                                Text(Constants.Text.didWalk)
                                    .foregroundColor(.black)
                            )
                            .typography(.robotoH2B)
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 20)
                        .padding(.bottom, 16)

                        selectPeriodTabView
                            .padding(.horizontal, 16)
                            .padding(.bottom, 26)

                        StepBarChartView(
                            stats: currentWeekData,
                            maxSteps: dynamicMaxSteps,
                            isYesterdayTab: selectedTab == .yesterday
                        )
                        .padding(.horizontal, 24)
                        .padding(.bottom, 26)

                        // 정보 텍스트 영역
                        VStack(alignment: .leading, spacing: 4) {
                            Text(Constants.Text.statisticsDesc01)
                                .font(.system(size: 12))
                                .foregroundColor(AppColor.graySummaryText102)
                            Text(Constants.Text.statisticsDesc02)
                                .font(.system(size: 12))
                                .foregroundColor(AppColor.graySummaryText102)
                        }
                        .padding(.leading, 42)
                        .padding(.bottom, 26)

                        AppColor.grayBgDivider248
                            .frame(height: 8)

                        // 하단 배너
                        HStack {
                            Button(action: {
                                navigateToFAQ = true
                            }) {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(Constants.Text.stepDiffDesc).typography(.body1R)
                                    Text(Constants.Text.actionConfirm).typography(.h5B)
                                }
                                Spacer()
                                Image(systemName: Constants.ImageName.listArrow)
                                    .foregroundColor(Color.gray)
                            }
                            .padding(.horizontal, 20)
                        }
                        .frame(height: 92)
                        .background(AppColor.grayButton244)
                        .cornerRadius(16)
                        .padding(.horizontal, Constants.Margin.horizontal)
                        .padding(.vertical, Constants.Margin.vertical)
                    }
                }

                NavigationLink(destination: FAQView().useGlobalPopup(),
                               isActive: $navigateToFAQ) {
                    EmptyView()
                }
                .hidden()

                Spacer()
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .task { await loadStatistics() }
    }

    private var selectPeriodTabView: some View {
        HStack(spacing: 0) {
            ForEach(Array(StatTab.allCases.enumerated()), id: \.element) { index, tab in
                TabBarButton(
                    tab: tab,
                    isSelected: selectedTab == tab,
                    action: { select(tab) }
                )

            }
        }
        .padding(2)
        .frame(maxWidth: .infinity)
        .frame(height: 40)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(AppColor.grayBorderNBg238)
        )
    }

    private func select(_ tab: StatTab) {
                    selectedTab = tab
            }

    private struct TabBarButton: View {
        let tab: StatTab
        let isSelected: Bool
        let action: () -> Void

        var body: some View {
            ZStack {
                    // Bold 기준으로 공간 고정 (레이아웃 깜빡임 방지)
                Text(tab.title)
                    .font(.system(size: 14, weight: .bold))
                    .opacity(0)
                Text(tab.title)
                    .font(.system(size: 14, weight: isSelected ? .bold : .regular))
                        .foregroundColor(.black)
                    .animation(nil, value: isSelected)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 36)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .fill(isSelected ? Color.white : Color.clear)
                    .animation(nil, value: isSelected)
            )
            .contentShape(Rectangle())
            .onTapGesture { action() }
        }
    }
}

// MARK: - 막대 차트

struct StepBarChartView: View {
    let stats: [DailyStat]
    let maxSteps: Int
    let isYesterdayTab: Bool

    var body: some View {
        HStack(alignment: .bottom, spacing: 14) {
            ForEach(Array(stats.enumerated()), id: \.element.id) { index, stat in

                let isHighlighted = isYesterdayTab && (index == stats.count - 1)

                let stepTextColor  = isHighlighted ? AppColor.primaryPurple    : AppColor.graySubText34
                let dateTextColor  = isHighlighted ? AppColor.primaryPurple    : AppColor.grayTextField148
                let startBarColor  = isHighlighted ? AppColor.startBarChart    : AppColor.grayDisalbeBg221
                let endBarColor    = isHighlighted ? AppColor.endBarChart      : AppColor.grayBorderBg219

                VStack(spacing: 8) {
                    GeometryReader { geometry in
                        let safeMax    = max(maxSteps, 1)
                        let progress   = min(CGFloat(stat.steps) / CGFloat(safeMax), 1.0)
                        let textSpace: CGFloat = 20
                        let maxBarHeight = geometry.size.height - textSpace
                        let barHeight  = progress * maxBarHeight

                        ZStack(alignment: .bottom) {
                            Text(stat.steps == 0 ? "0" : "\(stat.steps.formattedWithSeparator)")
                                .font(.system(size: 8, weight: .regular))
                                .foregroundColor(stepTextColor)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                                .offset(y: -(barHeight + 4))

                            Capsule()
                                .fill(
                                    LinearGradient(
                                        colors: [startBarColor, endBarColor],
                                        startPoint: .top,
                                        endPoint: .bottom
                                    )
                                )
                                .frame(width: 11, height: barHeight)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    }
                    .frame(height: 156)

                    Text(stat.date)
                        .typography(.caption1R, color: dateTextColor)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .frame(height: 185)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - API 연동

extension StepStatisticsView {
    private func loadStatistics() async {
        isLoading = true
        do {
            let res = try await AppDataManager.shared.fetchStatistics()
            allData = mapToDailyStats(res.items)
        } catch {
            CULog("통계 로드 실패: \(error.localizedDescription)")
            allData = emptyDailyStats()
        }
        isLoading = false
    }

/// API items → 21일치 DailyStat 배열 변환
    /// 인덱스 0~6: 2주 전, 7~13: 1주 전, 14~20: 어제(최근 7일) — 오래된 순
    private func mapToDailyStats(_ items: [StatisticItem]) -> [DailyStat] {
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(identifier: "Asia/Seoul")!
        let today = Date()

        let fmt = DateFormatter()
        fmt.dateFormat = "MM.dd"
        fmt.timeZone   = TimeZone(identifier: "Asia/Seoul")

        // Unix timestamp(ms) → "MM.dd" 키로 딕셔너리 구성 (KST 기준)
        var stepByDate: [String: Int] = [:]
        for item in items {
            let date = Date(timeIntervalSince1970: TimeInterval(item.date) / 1000)
            let key  = fmt.string(from: date)
            stepByDate[key] = (stepByDate[key] ?? 0) + item.step
CULog("통계 날짜 변환: \(item.date)ms → \(key) (\(item.step)걸음)")
        }

        // 21일 전(dayOffset: -21)부터 어제(dayOffset: -1)까지 오래된 순으로 생성 (KST 기준)
        var result: [DailyStat] = []
        for dayOffset in stride(from: -21, through: -1, by: 1) {
            let date  = calendar.date(byAdding: .day, value: dayOffset, to: today)!
            let label = fmt.string(from: date)
            result.append(DailyStat(date: label, steps: stepByDate[label] ?? 0))
        }
CULog("통계 매핑 완료: \(result.count)일치, stepByDate=\(stepByDate)")
        return result  // 21개
    }

    private func emptyDailyStats() -> [DailyStat] {
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(identifier: "Asia/Seoul")!
        let today = Date()
        let fmt = DateFormatter()
        fmt.dateFormat = "MM.dd"
        fmt.timeZone = TimeZone(identifier: "Asia/Seoul")
        return stride(from: -21, through: -1, by: 1).map { dayOffset in
            let date = calendar.date(byAdding: .day, value: dayOffset, to: today)!
            return DailyStat(date: fmt.string(from: date), steps: 0)
        }
    }
}
