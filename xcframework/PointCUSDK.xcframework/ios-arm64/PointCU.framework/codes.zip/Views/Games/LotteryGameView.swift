//
//  LotteryGameView.swift
//  PointCUSDK
//
//  복권(L) 게임 화면
//
//  티켓 규칙:
//  - 모두 0 (첫 진입): 스크래치 "광고보고 복권받기 >"
//  - ticket_count > ticket_use_count: 스크래치 "여기를 긁어보세요"
//  - ticket_count < ticket_limit: 스크래치 탭 시 광고 표시
//  - ticket_count == ticket_limit: 스크래치 "다음 시간에 도전해주세요"
//
//  하단 버튼 없음 — 배너만, 스크래치 영역 텍스트로만 상태 제어
//
//  흐름:
//  스크래치 탭("광고보고 복권받기 >") → 광고 → benefit/ticketIssue → "여기를 긁어보세요"
//  스크래치 탭("여기를 긁어보세요") → benefit/confirm → win_point 팝업
//

import SwiftUI
import AdPopcornSSP

internal struct LotteryGameView: View {
    let benefit: BenefitItem
    var isExternalCall: Bool = false  // 메인앱 직접 호출 여부

    @Environment(\.presentationMode) var presentationMode
    @State private var detail: BenefitDetailResponse? = nil
    @State private var isLoading: Bool = true
    @State private var isProcessing: Bool = false
    @State private var showInfoPopup: Bool = false

    // 티켓 상태 변수
    @State private var ticketUnLimited: Bool = false
    @State private var ticketCount: Int = 0
    @State private var ticketUseCount: Int = 0
    @State private var ticketLimit: Int = 0


    @State private var scratchPoints: [CGPoint] = []
    @State private var isScratched: Bool = false

    private var scratchEnabled: Bool { ticketCount > ticketUseCount }

    private var canWatchAd: Bool {
        if ticketUnLimited { return true }
        if ticketCount == 0 && ticketUseCount == 0 && ticketLimit == 0 { return true }
        return ticketCount < ticketLimit
    }

    private var scratchText: String {
        if scratchEnabled { return Constants.Text.scratchHere }
        if canWatchAd     { return Constants.Text.showAndScratch }
        return Constants.Text.tryNextTime
    }

    @State private var namBannerHeight: CGFloat = 80
    @State private var availableHeight: CGFloat = 0

    // NAM 기본 비율(320×68) 기준 전체 화면 폭 스케일 높이
    private var defaultBannerHeight: CGFloat {
        ceil(UIScreen.main.bounds.width * 68 / 320)
    }

    // NavBar 아래 사용 가능 영역 - 배너
    private var contentHeight: CGFloat {
        availableHeight - namBannerHeight
    }

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: Constants.Text.lotterySection,
                backAction: { presentationMode.wrappedValue.dismiss() }
            )

            GeometryReader { geo in
                VStack(spacing: 0) {
                    if isLoading {
                        Spacer()
                        ProgressView()
                        Spacer()
                    } else if let detail {
                        lotteryContent(detail: detail)
                    }
                }
                .onAppear { availableHeight = geo.size.height }
                .onChange(of: namBannerHeight) { _ in availableHeight = geo.size.height }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .overlay(
            NativeAdGameBannerView(
                placement: .bannerLottery,
                onHeightChanged: { h in namBannerHeight = h }
            ),
            alignment: .bottom
        )
        .task {
            namBannerHeight = defaultBannerHeight
            await loadDetail()
        }
    }

    // MARK: - 복권 콘텐츠

    @ViewBuilder
    private func lotteryContent(detail: BenefitDetailResponse) -> some View {
        ZStack(alignment: .topLeading) {
            // 배경 이미지
            SDKAsyncImage(path: detail.backgroundImageUrl)
                .frame(width: UIScreen.main.bounds.width, height: contentHeight)
                .clipped()

            VStack(spacing: 0) {
                // 타이틀 텍스트 이미지 (top 26pt)
                if let textUrl = detail.lotteryTextImageUrl,
                   !textUrl.isEmpty, !textUrl.hasSuffix("/0") {
                    SDKAsyncImage(path: textUrl)
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .frame(height: 123)
                        .padding(.top, 26)
                }

                // 스크래치 영역 (ticket_bg 342×224, top 57pt, 가로 센터)
                ZStack(alignment: .top) {
                    Image("ticket_bg", bundle: .pointCU)
                        .resizable()
                        .frame(width: 342, height: 224)

                    LotteryResultView()
                        .padding(.top, 20)

                    LotteryScratchCoverView(text: scratchText)
                        .padding(.top, 20)
                        .opacity(scratchEnabled ? 0 : 1)
                        .allowsHitTesting(!scratchEnabled && canWatchAd && !isProcessing)
                        .onTapGesture {
                            guard canWatchAd && !isProcessing else { return }
                            Task { await loadAndShowAd() }
                        }

                    if scratchEnabled && !isScratched {
                        LotteryScratchMaskView(points: $scratchPoints, isScratched: $isScratched)
                            .padding(.top, 20)
                    }
                }
                .frame(width: 342, height: 224)
                .padding(.top, 57)
                .frame(maxWidth: .infinity, alignment: .center)
                .onChange(of: isScratched) { scratched in
                    if scratched { Task { await confirmBenefit() } }
                }

                Spacer()
            }

            // 우측 하단 info 버튼
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: { showInfoPopup = !showInfoPopup }) {
                        Image("icn_info", bundle: .pointCU)
                            .resizable()
                            .frame(width: 24, height: 24)
                    }
                    .padding(.bottom, 16)
                    .padding(.trailing, 16)
                }
            }
        }
        .frame(width: UIScreen.main.bounds.width, height: contentHeight)
        .contentShape(Rectangle())
        .onTapGesture { if showInfoPopup { showInfoPopup = false } }
        .overlay(
            Group { if showInfoPopup { infoPopupView } },
            alignment: .bottomTrailing
        )
    }
    
    

    // MARK: - 광고 표시
 
    private func loadAndShowAd() async {
        isProcessing = true
        OverlayManager.shared.showIndicator()
 
        // 미디에이션 데이터 없으면 fetch 후 재시도
        var adList = MediationManager.shared.ads(for: AdsPlacementType.lottery.rawValue)
        if adList.isEmpty {
            await MediationManager.shared.fetchIfNeeded(force: true)
            adList = MediationManager.shared.ads(for: AdsPlacementType.lottery.rawValue)
        }
        guard !adList.isEmpty else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isProcessing = false
            return
        }
 
        let startIndex = MediationManager.shared.currentIndex(for: .lottery)
        tryShowAd(adList: adList, startIndex: startIndex, triedCount: 0)
    }
 
    private func tryShowAd(adList: [MediationAd], startIndex: Int, triedCount: Int) {
        guard triedCount < adList.count else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isProcessing = false
            return
        }
 
        let index = (startIndex + triedCount) % adList.count
        let ad = adList[index]
        MediationManager.shared.advanceIndex(for: .lottery)
        print("[LotteryGame] 광고 시도 \(triedCount + 1)/\(adList.count) | code=\(ad.priorityCode) key=\(ad.adKey)")
 
        let onFailRetry: () -> Void = {
            Task { @MainActor in
                self.tryShowAd(adList: adList, startIndex: startIndex, triedCount: triedCount + 1)
            }
        }
 
        switch AdsType.parse(ad.priorityCode) {
        case .adPopcornFull:
            showAdPopcornInterstitial(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .adPopcornReward:
            showAdPopcornReward(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .mobiWithPopup:
            showMobiWithAd(zone: ad.adKey, onFailRetry: onFailRetry)
        default:
            tryShowAd(adList: adList, startIndex: startIndex, triedCount: triedCount + 1)
        }
    }
 
    private func showAdPopcornInterstitial(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isProcessing = false }; return
        }
        let ad = AdPopcornSSPInterstitialVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.interstitialVideoAd = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in OverlayManager.shared.hideCenterMessage(); await self.issueTicket(); self.isProcessing = false } }
        AdPopcornAdDelegate.shared.onFail     = { Task { @MainActor in OverlayManager.shared.hideCenterMessage(); onFailRetry() } }
        ad?.delegate = AdPopcornAdDelegate.shared
        // 전면비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }
 
    private func showAdPopcornReward(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isProcessing = false }; return
        }
        let ad = AdPopcornSSPRewardVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.rewardAd   = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in OverlayManager.shared.hideCenterMessage(); await self.issueTicket(); self.isProcessing = false } }
        AdPopcornAdDelegate.shared.onFail     = { Task { @MainActor in OverlayManager.shared.hideCenterMessage(); onFailRetry() } }
        ad?.delegate = AdPopcornAdDelegate.shared
        // 리워드비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }
 
    private func showMobiWithAd(zone: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isProcessing = false }; return
        }
        let vc = MobiWithAdViewController(
            zoneId: zone,
            onComplete: { Task { @MainActor in await self.issueTicket(); self.isProcessing = false } },
            onFail:     { Task { @MainActor in onFailRetry() } },
            onClose:    { Task { @MainActor in OverlayManager.shared.hideIndicator(); self.isProcessing = false } }
        )
        topVC.present(vc, animated: true)
    }

    // MARK: - 광고 로드 실패 팝업

    private func showAdFailPopup() {
        OverlayManager.shared.hideIndicator()
        OverlayManager.shared.showSingle(
            message: Constants.Text.noAvailableAdDesc,
            confirmAction: { }
        )
    }

    // MARK: - benefit/ticketIssue

    private func issueTicket() async {
        do {
            let bid = detail?.benefitId ?? benefit.id
            let res = try await AppDataManager.shared.issueBenefitTicket(benefitId: bid)
            ticketCount    = res.ticketCount
            ticketUseCount = res.ticketUseCount
            ticketLimit    = res.ticketLimit
            CULog("ticketIssue | count=\(ticketCount) use=\(ticketUseCount) limit=\(ticketLimit)")
            scratchPoints = []
            isScratched   = false
        } catch {
            CULog("ticketIssue 실패: \(error.localizedDescription)")
        }
        OverlayManager.shared.hideIndicator()
    }

    // MARK: - benefit/confirm

    private func confirmBenefit() async {
        isProcessing = true
        OverlayManager.shared.showIndicator()
        do {
            let result = try await AppDataManager.shared.confirmBenefit(
                benefitId: detail?.benefitId ?? benefit.id, benefitType: "L"
            )
            ticketCount    = result.ticketCount
            ticketUseCount = result.ticketUseCount
            ticketLimit    = result.ticketLimit

            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showReward(
                imageName: Constants.ImageName.fireCracker,
                message: "\(result.winPoint)\(Constants.Text._getWinPointMessage)",
                confirmAction: { }
            )
            isProcessing = false
        } catch {
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.getWinPointFailureMessage)
            isProcessing = false
        }
    }

    // MARK: - Info 팝업

    private var infoPopupView: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Constants.Text.benefitInfoText, id: \.self) { text in
                HStack(alignment: .top, spacing: 4) {
                    Text("•").typography(.caption1R, color: .white)
                    Text(text).typography(.caption1R, color: .white, alignment: .leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 170/255, green: 170/255, blue: 170/255, opacity: 0.9)))
        .padding(.horizontal, 16)
        .padding(.bottom, 48)
        .transition(.opacity)
        .animation(.easeInOut(duration: 0.2), value: showInfoPopup)
    }

    // MARK: - 유틸

    private func loadDetail() async {
        isLoading = true
        do {
            let d = try await isExternalCall
                ? AppDataManager.shared.fetchBenefitDetailByLocation(benefitType: "L")
                : AppDataManager.shared.fetchBenefitDetail(benefitId: benefit.id)
            ticketUnLimited  = d.ticketLimitYn == "Y" ? true : false
            ticketCount      = d.ticketCount
            ticketUseCount   = d.ticketUseCount
            ticketLimit      = d.ticketLimit
            detail           = d
            isLoading = false
        } catch {
            isLoading = false
            // 서버 에러 — 팝업 안내 후 dismiss
            OverlayManager.shared.showSingle(
                message: Constants.Text.serverError,
                confirmAction: { SDKRouter.shared.dismissAndRefresh() }
            )
        }
    }

}

// MARK: - LotteryGameView 전용 서브뷰 (ticket_bg 342×224, 내부 300×136)

private struct LotteryResultView: View {
    var body: some View {
        ZStack {
            Image(Constants.ImageName.scratchResultBg, bundle: .pointCU)
                .resizable()
                .scaledToFill()
                .frame(width: 300, height: 136)
                .cornerRadius(16)
            Text(Constants.Text.youHaveWon)
                .typography(.h4B, color: .white)
        }
        .frame(width: 300, height: 136)
    }
}

private struct LotteryScratchCoverView: View {
    let text: String
    var body: some View {
        ZStack {
            if text == Constants.Text.tryNextTime {
                RoundedRectangle(cornerRadius: 16)
                    .fill(AppColor.grayBorderNBg238)
                    .frame(width: 300, height: 136)
            } else {
                Image(Constants.ImageName.scratchCover, bundle: .pointCU)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 300, height: 136)
                    .cornerRadius(16)
            }
            
            Text(text)
                .typography(.h4B, color: text == Constants.Text.tryNextTime ? AppColor.graySummaryText102 : AppColor.grayTextField170)
        }
        .frame(width: 300, height: 136)
    }
}

private struct LotteryScratchMaskView: View {
    @Binding var points: [CGPoint]
    @Binding var isScratched: Bool

    var body: some View {
        Canvas { context, size in
            if let resolved = context.resolveSymbol(id: "lotteryCover") {
                context.draw(resolved, at: CGPoint(x: size.width / 2, y: size.height / 2))
            }
            context.blendMode = .destinationOut
            var path = Path()
            if let first = points.first {
                path.move(to: first)
                for point in points.dropFirst() { path.addLine(to: point) }
            }
            context.stroke(path, with: .color(.white),
                           style: StrokeStyle(lineWidth: 30, lineCap: .round, lineJoin: .round))
        } symbols: {
            LotteryScratchCoverView(text: Constants.Text.scratchHere).tag("lotteryCover")
        }
        .frame(width: 300, height: 136)
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    points.append(value.location)
                    if points.count > 40 && !isScratched {
                        withAnimation(.easeOut(duration: 0.8)) { isScratched = true }
                    }
                }
        )
    }
}
