//
//  RouletteGameView.swift
//  PointCUSDK
//
//  룰렛(R) 게임 화면
//
//  티켓 규칙:
//  - 모두 0 (첫 진입): GO 버튼 숨김, 하단 광고보기 활성
//  - ticket_count > ticket_use_count: GO 버튼 표시
//  - ticket_count < ticket_limit: 하단 광고보기 활성
//  - ticket_count == ticket_limit: 하단 "다음 시간에 도전해주세요"
//
//  흐름:
//  광고보기 → (애드팝콘 전면/리워드/모비위드 순환) → benefit/ticketIssue
//  → ticket 상태 업데이트 → GO 버튼 표시
//  → GO 탭 → benefit/confirm → 룰렛 회전 → win_point 팝업
//

import SwiftUI
import AdPopcornSSP

internal struct RouletteGameView: View {
    let benefit: BenefitItem
    var isExternalCall: Bool = false  // 메인앱 직접 호출 여부

    @Environment(\.presentationMode) var presentationMode
    @State private var detail: BenefitDetailResponse? = nil
    @State private var isLoading: Bool = true
    @State private var isAdLoading: Bool = false
    @State private var showInfoPopup: Bool = false

    // 티켓 상태 변수
    @State private var ticketUnLimited: Bool = false
    @State private var ticketCount: Int = 0
    @State private var ticketUseCount: Int = 0
    @State private var ticketLimit: Int = 0

    // 룰렛 애니메이션
    @State private var rotationDegrees: Double = 0
    @State private var currentSlices: [RouletteSlice] = []  // 회전 후 갱신되는 슬라이스 각도
    @State private var confirmResult: BenefitConfirmResponse? = nil
    @State private var isSpinning: Bool = false

    private let baseRotation: Double = 1800  // 5바퀴

    // GO 버튼 표시 여부
    private var showGoButton: Bool {
        ticketCount > ticketUseCount
    }

    // 하단 버튼 상태
    private var canWatchAd: Bool {
        // ticket_limit_yn == "Y": 무제한 → 항상 활성
        if ticketUnLimited { return true }
        // 모두 0이면 첫 진입 → 활성
        if ticketCount == 0 && ticketUseCount == 0 && ticketLimit == 0 { return true }
        return ticketCount < ticketLimit
    }

    // 미소진 티켓 보유 중 또는 스피닝 중 — 버튼 비활성화
    private var hasUnusedTicket: Bool {
        ticketCount > ticketUseCount || isSpinning
    }

    @State private var namBannerHeight: CGFloat = 80
    @State private var availableHeight: CGFloat = 0  // GeometryReader로 측정

    // NAM 기본 비율(320×68) 기준 전체 화면 폭 스케일 높이
    private var defaultBannerHeight: CGFloat {
        ceil(UIScreen.main.bounds.width * 68 / 320)
    }

    // 콘텐츠 영역 높이 = NavBar 아래 사용 가능 영역 - 버튼 - 배너
    private var contentHeight: CGFloat {
        let button = 48.0  // actionButton 높이
        return availableHeight - button - namBannerHeight
    }

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(
                title: Constants.Text.rouletteSection,
                backAction: { presentationMode.wrappedValue.dismiss() }
            )

            GeometryReader { geo in
                VStack(spacing: 0) {
                    if isLoading {
                        Spacer()
                        ProgressView()
                        Spacer()
                    } else if let detail {
                        VStack(spacing: 0) {
                            rouletteContent(detail: detail)
                            actionButton(detail: detail)
                        }
                    }
                }
                .onAppear { availableHeight = geo.size.height }
                .onChange(of: namBannerHeight) { _ in availableHeight = geo.size.height }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .overlay(
            NativeAdGameBannerView(
                placement: .bannerRoulette,
                onHeightChanged: { h in namBannerHeight = h }
            ),
            alignment: .bottom
        )
        .task {
            namBannerHeight = defaultBannerHeight
            await loadDetail()
        }
    }

    // MARK: - 룰렛 컨텐츠

    @ViewBuilder
    private func rouletteContent(detail: BenefitDetailResponse) -> some View {
        ZStack(alignment: .top) {
            SDKAsyncImage(path: detail.backgroundImageUrl)
                .frame(width: UIScreen.main.bounds.width, height: contentHeight)
                .clipped()

            VStack(spacing: 0) {
                if let textUrl = detail.rouletteTextImageUrl {
                    SDKAsyncImage(path: textUrl)
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .padding(.top, 13)
                }
                
                Spacer()

                ZStack(alignment: .top) {
                    if let wheelUrl = detail.rouletteImageUrl {
                        SDKAsyncImage(path: wheelUrl)
                            .frame(width: 342, height: 342)
                            .rotationEffect(.degrees(rotationDegrees))
                    }
                    
                    if let arrowUrl = detail.rouletteArrowImageUrl {
                        SDKAsyncImage(path: arrowUrl)
                            .scaledToFit()
                            .frame(width: 32)
                            .offset(y: -14)
                    }
                    
                    // GO 버튼 — ticket_count > ticket_use_count 일 때만 표시
                    if showGoButton, !isSpinning {
                        Button(action: {
                            Task { await spinRoulette(detail: detail) }
                        }) {
                            Image("go_button", bundle: .pointCU)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .padding(.top, 121)
                        }
                    }
                }
                .frame(width: 342, height: 342)
                .padding(.bottom, 16)
            }
            
            // 우측 하단 info 버튼
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: { showInfoPopup = !showInfoPopup }) {
                        Image("icn_info", bundle: .pointCU)
                            .resizable()
                            .frame(width: 24, height: 24)
                    }
                    .padding(.bottom, 16)
                    .padding(.trailing, 16)
                }
            }
        }
        .frame(width: UIScreen.main.bounds.width, height: contentHeight)
        .onTapGesture { if showInfoPopup { showInfoPopup = false } }
        .overlay(
            Group { if showInfoPopup { infoPopupView } },
            alignment: .bottomTrailing
        )
    }
    
    // MARK: - 하단 버튼 (48pt)

    @ViewBuilder
    private func actionButton(detail: BenefitDetailResponse) -> some View {
        Group {
            if canWatchAd {
                Button(action: {
                    if !isSpinning {
                        Task { await loadAndShowAd() }
                    }
                }) {
                    Text(Constants.Text.getRouleteTicket)
                        .typography(.body2B, color: hasUnusedTicket ? AppColor.graySummaryText102 : .white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(hasUnusedTicket ? AppColor.grayButton244 : AppColor.secondaryGreen)
                }
                .disabled(isAdLoading || hasUnusedTicket)
            } else {
                Text(Constants.Text.tryNextTime)
                    .typography(.body2R, color: AppColor.graySummaryText102)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
                    .background(AppColor.grayButton244)
            }
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - 광고 표시
     
    private func loadAndShowAd() async {
        guard !isAdLoading else { return }
        isAdLoading = true
        OverlayManager.shared.showIndicator()
 
        // 미디에이션 데이터 없으면 fetch 후 재시도
        var adList = MediationManager.shared.ads(for: AdsPlacementType.roulette.rawValue)
        if adList.isEmpty {
            await MediationManager.shared.fetchIfNeeded(force: true)
            adList = MediationManager.shared.ads(for: AdsPlacementType.roulette.rawValue)
        }
        guard !adList.isEmpty else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isAdLoading = false
            return
        }
 
        let startIndex = MediationManager.shared.currentIndex(for: .roulette)
        tryShowAd(adList: adList, startIndex: startIndex, triedCount: 0)
    }
 
    private func tryShowAd(adList: [MediationAd], startIndex: Int, triedCount: Int) {
        guard triedCount < adList.count else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isAdLoading = false
            return
        }
 
        let index = (startIndex + triedCount) % adList.count
        let ad = adList[index]
        MediationManager.shared.advanceIndex(for: .roulette)
        print("[RouletteGame] 광고 시도 \(triedCount + 1)/\(adList.count) | code=\(ad.priorityCode) key=\(ad.adKey)")
 
        let onFailRetry: () -> Void = {
            Task { @MainActor in
                self.tryShowAd(adList: adList, startIndex: startIndex, triedCount: triedCount + 1)
            }
        }
 
        switch AdsType.parse(ad.priorityCode) {
        case .adPopcornFull:
            showAdPopcornInterstitial(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .adPopcornReward:
            showAdPopcornReward(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .mobiWithPopup:
            showMobiWithAd(zone: ad.adKey, onFailRetry: onFailRetry)
        default:
            tryShowAd(adList: adList, startIndex: startIndex, triedCount: triedCount + 1)
        }
    }
 
    private func showAdPopcornInterstitial(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isAdLoading = false }; return
        }
        let ad = AdPopcornSSPInterstitialVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.interstitialVideoAd = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            OverlayManager.shared.hideIndicator()
            await self.issueTicket()
            self.isAdLoading = false
        }}
        AdPopcornAdDelegate.shared.onFail = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            onFailRetry()
        }}
        ad?.delegate = AdPopcornAdDelegate.shared
        // 전면비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }
 
    private func showAdPopcornReward(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isAdLoading = false }; return
        }
        let ad = AdPopcornSSPRewardVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.rewardAd   = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            OverlayManager.shared.hideIndicator()
            await self.issueTicket()
            self.isAdLoading = false
        }}
        AdPopcornAdDelegate.shared.onFail     = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            onFailRetry()
        }}
        ad?.delegate = AdPopcornAdDelegate.shared
        // 리워드비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }
 
    private func showMobiWithAd(zone: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            Task { await issueTicket(); isAdLoading = false }; return
        }
        let vc = MobiWithAdViewController(
            zoneId: zone,
            onComplete: { Task { @MainActor in
                OverlayManager.shared.hideIndicator()
                await self.issueTicket()
                self.isAdLoading = false
            }},
            onFail:     { Task { @MainActor in onFailRetry() } },
            onClose:    { Task { @MainActor in
                OverlayManager.shared.hideIndicator()
                self.isAdLoading = false
            }}
        )
        topVC.present(vc, animated: true)
    }

    // MARK: - 광고 로드 실패 팝업

    private func showAdFailPopup() {
        // 광고 없음 — canWatchAd = false 처리하여 tryNextTime 문구 표시
        isAdLoading    = false
        ticketCount    = ticketLimit  // canWatchAd = false 유도
    }

    // MARK: - benefit/ticketIssue

    private func issueTicket() async {
        do {
            let bid = detail?.benefitId ?? benefit.id
            let res = try await AppDataManager.shared.issueBenefitTicket(benefitId: bid)
            ticketCount    = res.ticketCount
            ticketUseCount = res.ticketUseCount
            ticketLimit    = res.ticketLimit
            if ticketCount > ticketUseCount {
                OverlayManager.shared.showDual(
                    title: Constants.Text.congratulation,
                    message: Constants.Text.getRouletteTicketSuccess,
                    cancelTitle: Constants.Text.textConfirm,
                    confirmTitle: Constants.Text.doRoulette,
                    confirmAction: {
                        self.isSpinning = true  // Task 실행 전 즉시 비활성화
                        Task { await spinRoulette(detail: self.detail!) }
                    }
                )
            }
            CULog("[RouletteGame] ticketIssue | count=\(ticketCount) use=\(ticketUseCount) limit=\(ticketLimit)")
        } catch {
            CULog("[RouletteGame] ticketIssue 실패: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Info 팝업

    private var infoPopupView: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Constants.Text.benefitInfoText, id: \.self) { text in
                HStack(alignment: .top, spacing: 4) {
                    Text("•").typography(.caption1R, color: .white)
                    Text(text).typography(.caption1R, color: .white, alignment: .leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 170/255, green: 170/255, blue: 170/255, opacity: 0.9)))
        .padding(.horizontal, 16)
        .padding(.bottom, 48)
        .transition(.opacity)
        .animation(.easeInOut(duration: 0.2), value: showInfoPopup)
    }

    // MARK: - benefit/confirm + 룰렛 회전

    private func spinRoulette(detail: BenefitDetailResponse) async {
        isSpinning = true
        OverlayManager.shared.showIndicator()
        do {
            let result = try await AppDataManager.shared.confirmBenefit(
                benefitId: detail.benefitId, benefitType: "R"
            )
            // ticket 상태 업데이트
            OverlayManager.shared.hideIndicator()
            
            ticketCount    = result.ticketCount
            ticketUseCount = result.ticketUseCount
            ticketLimit    = result.ticketLimit

            let currentOffset = rotationDegrees.truncatingRemainder(dividingBy: 360)
            let targetAngle: Double
            if let winId = result.winRouletteId,
               let slice = currentSlices.first(where: { $0.rouletteId == winId }) {
                let currentPos = (slice.centerAngle + currentOffset).truncatingRemainder(dividingBy: 360)
                targetAngle = currentPos == 0 ? 0 : 360 - currentPos
            } else {
                // winRouletteId가 없거나 매칭되는 슬라이스가 없는 경우
                // 1P 슬라이스(30~90도) 중앙인 60도에 멈춤
                let fallbackAngle = 60.0
                let currentPos = (fallbackAngle + currentOffset).truncatingRemainder(dividingBy: 360)
                targetAngle = currentPos == 0 ? 0 : 360 - currentPos
                CULog("[RouletteGameView] winRouletteId 없음 — 1P(60도) 슬라이스로 대체")
            }

            let totalRotation = baseRotation + targetAngle
            withAnimation(.easeOut(duration: 4.0)) {
                rotationDegrees += totalRotation
            }
            try await Task.sleep(nanoseconds: 4_200_000_000)

            // 회전 완료 후 rotationDegrees 정규화 (누적 방지)
            rotationDegrees = rotationDegrees.truncatingRemainder(dividingBy: 360)

            // 결과 팝업
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showReward(
                imageName: Constants.ImageName.fireCracker,
                message: "\(result.winPoint)\(Constants.Text._getWinPointMessage)",
                confirmAction: { }
            )
            isSpinning = false

        } catch {
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.getWinPointFailureMessage)
            isSpinning = false
        }
    }

    // MARK: - 유틸

    private func loadDetail() async {
        isLoading = true
        do {
            let d = try await isExternalCall
                ? AppDataManager.shared.fetchBenefitDetailByLocation(benefitType: "R")
                : AppDataManager.shared.fetchBenefitDetail(benefitId: benefit.id)
            ticketUnLimited  = d.ticketLimitYn == "Y" ? true : false
            ticketCount      = d.ticketCount
            ticketUseCount   = d.ticketUseCount
            ticketLimit      = d.ticketLimit
            currentSlices    = d.dataList ?? []
            detail           = d
            isLoading        = false
        } catch {
            isLoading = false
            // 서버 에러 — 팝업 안내 후 dismiss
            OverlayManager.shared.showSingle(
                message: Constants.Text.serverError,
                confirmAction: { SDKRouter.shared.dismissAndRefresh() }
            )
        }
    }

}
