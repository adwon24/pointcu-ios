//
//  StepMissionGameView.swift
//  PointCUSDK
//
//  걸음 미션 복권 화면
//  - D0000195 (미션 티켓) 위치의 광고 순환 사용
//  - 광고 완료 → afterAd 상태 (스크래치 가능)
//  - 스크래치 완료 → confirmTicket → win_point 팝업
//
//  LotteryGameView 흐름 기반:
//  광고보고 긁기 탭 → 광고 → afterAd 상태
//  스크래치 완료 → confirmTicket(missionId) → reward 팝업
//

import SwiftUI
import AdPopcornSSP

enum StepMissionGameState {
    case beforeAd   // 광고 보기 전
    case afterAd    // 광고 완료 → 긁기 가능
}

internal struct StepMissionGameView: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var currentState: StepMissionGameState = .beforeAd
    @State private var points: [CGPoint] = []
    @State private var isScratched: Bool = false
    @State private var isAdLoading: Bool = false
    @State private var isConfirming: Bool = false

    private var titleText: String {
        currentState == .beforeAd
            ? Constants.Text.scratchBeforeAdTitle
            : Constants.Text.scratchAfterAdTitle
    }
    private var subTitleText: String {
        currentState == .beforeAd
            ? Constants.Text.scratchBeforeAdDesc
            : Constants.Text.scratchAfterAdDesc
    }

    var body: some View {
        VStack(spacing: 0) {
            CustomNavigationBar(title: "", backAction: {
                if currentState == .afterAd {
                    OverlayManager.shared.showSingle(message: Constants.Text.missionExitWarning)
                } else {
                    presentationMode.wrappedValue.dismiss()
                }
            })

            // 타이틀 영역: subTitleText 기준 아래 고정, titleText는 위로 늘어남
            VStack(spacing: 0) {
                Spacer(minLength: 0)
                Text(titleText)
                    .typography(.h2B)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.bottom, 8)
                Text(subTitleText)
                    .typography(.body1R, color: AppColor.graySummaryText102)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(height: 92)
            .padding(.top, 21)
            .padding(.bottom, 46)

            // 복권 카드 (LotteryGameView와 동일한 레이어 구조)
            ZStack {
                // 1. 결과 레이어 (항상 표시)
                ResultView()

                // 2. 커버 레이어 — beforeAd 상태에서만 표시
                ScratchCoverView(text: Constants.Text.showAndScratch)
                    .frame(width: 300, height: 180)
                    .opacity(currentState == .beforeAd ? 1 : 0)
                    .allowsHitTesting(currentState == .beforeAd && !isAdLoading)
                    .onTapGesture {
                        guard currentState == .beforeAd && !isAdLoading else { return }
                        Task { await loadAndShowAd() }
                    }

                // 3. 스크래치 마스크 — afterAd 상태이고 아직 긁지 않았을 때
                if currentState == .afterAd && !isScratched {
                    ScratchMaskView(points: $points, isScratched: $isScratched)
                        .frame(width: 300, height: 180)
                }
            }
            .frame(width: 300, height: 180)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 4)
            .onChange(of: isScratched) { scratched in
                if scratched { Task { await handleScratchComplete() } }
            }

            Spacer()

            // 배너 높이만큼 하단 여백 확보
            Color.clear
                .frame(height: ceil(
                    (UIScreen.main.bounds.width - 32) * 68 / 320
                ) + 12)
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .overlay(
            NativeAdMissionBannerView(),
            alignment: .bottom
        )
    }

    // MARK: - 광고 순환

    private func loadAndShowAd() async {
        guard !isAdLoading else { return }
        isAdLoading = true
        OverlayManager.shared.showIndicator()
        let totalCount = MediationManager.shared.ads(for: AdsPlacementType.missionTicket.rawValue).count
        guard totalCount > 0 else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isAdLoading = false
            return
        }
        tryShowAd(remainingCount: totalCount)
    }

    private func tryShowAd(remainingCount: Int) {
        guard remainingCount > 0 else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isAdLoading = false
            return
        }

        guard let ad = MediationManager.shared.nextAd(for: .missionTicket) else {
            OverlayManager.shared.hideIndicator()
            showAdFailPopup()
            isAdLoading = false
            return
        }

        CULog("[StepMissionGame] 광고 시도 | code=\(ad.priorityCode) key=\(ad.adKey) 남은=\(remainingCount)")

        let onFailRetry: () -> Void = {
            Task { @MainActor in self.tryShowAd(remainingCount: remainingCount - 1) }
        }

        switch AdsType.parse(ad.priorityCode) {
        case .adPopcornFull:
            showAdPopcornInterstitial(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .adPopcornReward:
            showAdPopcornReward(adKey: ad.adKey, onFailRetry: onFailRetry)
        case .mobiWithPopup:
            showMobiWithAd(zone: ad.adKey, onFailRetry: onFailRetry)
        default:
            onFailRetry()
        }
    }

    // MARK: - 광고 타입별 처리

    private func showAdPopcornInterstitial(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            onAdComplete(); return
        }
        let ad = AdPopcornSSPInterstitialVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.interstitialVideoAd = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            OverlayManager.shared.hideIndicator()
            self.onAdComplete()
        }}
        AdPopcornAdDelegate.shared.onFail = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            onFailRetry()
        }}
        ad?.delegate = AdPopcornAdDelegate.shared
        // 전면비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }
    
    private func showAdPopcornReward(adKey: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            onAdComplete(); return
        }
        let ad = AdPopcornSSPRewardVideoAd(key: Constants.AdPopcorn.appKey, placementId: adKey, viewController: topVC)
        AdPopcornAdDelegate.shared.rewardAd   = ad
        AdPopcornAdDelegate.shared.onComplete = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            OverlayManager.shared.hideIndicator()
            self.onAdComplete()
        }}
        AdPopcornAdDelegate.shared.onFail = { Task { @MainActor in
            OverlayManager.shared.hideCenterMessage()
            onFailRetry()
        }}
        ad?.delegate = AdPopcornAdDelegate.shared
        // 리워드비디오 로딩 대기 메시지 표시
        OverlayManager.shared.showCenterMessage(Constants.Text.waitingAdAvailable)
        ad?.loadRequest()
    }

    private func showMobiWithAd(zone: String, onFailRetry: @escaping () -> Void) {
        guard let topVC = UIApplication.shared.topViewController() else {
            onAdComplete(); return
        }
        let vc = MobiWithAdViewController(
            zoneId:     zone,
            onComplete: { Task { @MainActor in
                OverlayManager.shared.hideIndicator()
                self.onAdComplete()
            }},
            onFail:     { Task { @MainActor in
                OverlayManager.shared.hideIndicator()
                onFailRetry()
            }},
            onClose:    { Task { @MainActor in
                OverlayManager.shared.hideIndicator()
                self.isAdLoading = false
            }}
        )
        topVC.present(vc, animated: true)
    }

    // MARK: - 광고 완료 → afterAd 상태 (LotteryGameView: issueTicket 완료 후 스크래치 가능)

    private func onAdComplete() {
        CULog("onAdComplete")
        OverlayManager.shared.hideIndicator()
        isAdLoading  = false
        currentState = .afterAd
        points       = []
        isScratched  = false
    }

    // MARK: - 스크래치 완료 → confirmTicket → reward 팝업
    // LotteryGameView의 confirmBenefit과 동일한 흐름

    private func handleScratchComplete() async {
        guard !isConfirming else { return }
        isConfirming = true
        OverlayManager.shared.showIndicator()

        guard let missionData = AppDataManager.shared.ticketIssueMission else {
            CULog("[StepMissionGame] ticketIssueMission 없음 — confirmTicket 스킵")
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.processErrorOccurred)
            isConfirming = false
            return
        }

        CULog("[StepMissionGame] confirmTicket | missionId=\(missionData.missionId)")
        do {
            let winPoint = try await AppDataManager.shared.confirmTicket(missionId: missionData.missionId)
            CULog("[StepMissionGame] confirmTicket 완료 | winPoint=\(winPoint)")
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showReward(
                imageName: Constants.ImageName.fireCracker,
                message: "\(winPoint)\(Constants.Text._getWinPointMessage)",
                confirmAction: {
                    UIApplication.shared.topViewController()?.dismiss(animated: true) {
                        Task { await AppDataManager.shared.refreshMainData() }
                    }
                }
            )
        } catch {
            CULog("[StepMissionGame] confirmTicket 실패: \(error.localizedDescription)")
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.showSingle(message: Constants.Text.getWinPointFailureMessage)
        }
        isConfirming = false
    }

    // MARK: - 광고 실패 팝업

    private func showAdFailPopup() {
        OverlayManager.shared.showSingle(
            message: Constants.Text.noAvailableAdDesc,
            confirmAction: { }
        )
    }
}

// MARK: - 하위 컴포넌트

struct ResultView: View {
    var body: some View {
        ZStack {
            Image(Constants.ImageName.scratchResultBg, bundle: .pointCU)
                .resizable()
                .scaledToFill()
                .cornerRadius(16)
            Text(Constants.Text.youHaveWon)
                .typography(.h4B, color: .white)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        }
        .frame(width: 300, height: 180)
    }
}

struct ScratchCoverView: View {
    let text: String
    var body: some View {
        ZStack {
            Image(Constants.ImageName.scratchCover, bundle: .pointCU)
                .resizable()
                .scaledToFill()
                .cornerRadius(16)
            Text(text)
                .typography(.h4B, color: AppColor.grayTextField170)
        }
        .frame(width: 300, height: 180)
    }
}

struct ScratchMaskView: View {
    @Binding var points: [CGPoint]
    @Binding var isScratched: Bool

    var body: some View {
        Canvas { context, size in
            if let resolved = context.resolveSymbol(id: "coverPattern") {
                context.draw(resolved, at: CGPoint(x: size.width / 2, y: size.height / 2))
            }
            context.blendMode = .destinationOut
            var path = Path()
            if let first = points.first {
                path.move(to: first)
                for point in points.dropFirst() {
                    path.addLine(to: point)
                }
            }
            context.stroke(path, with: .color(.white),
                           style: StrokeStyle(lineWidth: 30, lineCap: .round, lineJoin: .round))
        } symbols: {
            ScratchCoverView(text: Constants.Text.scratchHere)
                .frame(width: 300, height: 180)
                .tag("coverPattern")
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    points.append(value.location)
                    if points.count > 40 && !isScratched {
                        DispatchQueue.main.async {
                            withAnimation(.easeOut(duration: 0.8)) { isScratched = true }
                        }
                    }
                }
        )
    }
}
