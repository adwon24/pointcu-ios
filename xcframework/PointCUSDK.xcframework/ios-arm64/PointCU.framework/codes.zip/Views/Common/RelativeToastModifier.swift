//
//  RelativeToastModifier.swift
//  PointCU
//
//  Created by Juno Yoon on 4/21/26.
//

import SwiftUI

struct RelativeToastModifier: ViewModifier {
    @Binding var isPresented: Bool
    let message: String
    let duration: TimeInterval
    let spacing: CGFloat

    func body(content: Content) -> some View {
        content
            .overlay(
                GeometryReader { geo in
                    VStack(spacing: 0) {

                        Spacer()
                        
                        if isPresented {
                            Text(message)
                                .typography(.summary1R, color: .white)
                                .padding(.horizontal, 24)
                                .padding(.vertical, 12)
                                .background(AppColor.toastBgColor)
                                .clipShape(Capsule())
                                .padding(.bottom, geo.size.height + spacing)
                                .transition(.opacity)
//                                .transition(.opacity.combined(with: .move(edge: .bottom)))// 바닥에서 튀어 오르는 출현
                        }
                    }
                    .frame(width: geo.size.width, height: geo.size.height, alignment: .bottom)
                }
                .allowsHitTesting(false)
            )
            .zIndex(999)
//            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isPresented)// 스프잉 애니메이션
            .animation(.easeInOut(duration: 0.3), value: isPresented)
            .task(id: isPresented) {
                guard isPresented else { return }
                let nanoseconds = UInt64(duration * 1_000_000_000)
                do {
                    try await Task.sleep(nanoseconds: nanoseconds)
                    withAnimation {
                        isPresented = false
                    }
                } catch { }
            }
    }
}
