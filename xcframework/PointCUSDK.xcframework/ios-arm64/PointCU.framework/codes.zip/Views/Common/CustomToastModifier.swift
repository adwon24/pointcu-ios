//
//  CustomToastModifier.swift
//  PointCU
//
//  Created by Juno Yoon on 4/21/26.
//

import SwiftUI

struct CustomToastModifier: ViewModifier {
    @Binding var isPresented: Bool
    let message: String
    let duration: TimeInterval
    let bottomPadding: CGFloat // 화면 하단에서 얼마나 띄울지 조정

    func body(content: Content) -> some View {
        ZStack {
            content
            if isPresented {
                VStack {
                    Text(message)
                        .typography(.summary1R, color: .white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(AppColor.toastBgColor)
                        .clipShape(Capsule())
                        .padding(.bottom, bottomPadding)
                }
//                .transition(.opacity.combined(with: .move(edge: .bottom)))
                .transition(.opacity)
                .animation(.easeInOut(duration: 0.3), value: isPresented)
                .zIndex(2)
                .task(id: isPresented) {
                    guard isPresented else { return }
                    let nanoseconds = UInt64(duration * 1_000_000_000)
                    do {
                        try await Task.sleep(nanoseconds: nanoseconds)
                        withAnimation {
                            isPresented = false
                        }
                    } catch {
                        // CancellationError 무시
                    }
                }
            }
        }
    }
}
