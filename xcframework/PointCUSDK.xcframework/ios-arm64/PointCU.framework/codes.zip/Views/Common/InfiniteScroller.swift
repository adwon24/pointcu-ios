//
//  InfiniteScroller.swift
//  PointCU
//
//  Created by Juno Yoon on 4/8/26.
//

import SwiftUI

enum ScrollDirection {
    case leftToRight // 오른쪽으로 흐름 (좌 -> 우)
    case rightToLeft // 왼쪽으로 흐름 (우 -> 좌)
}

internal struct InfiniteScroller<Content: View>: View {
    let content: Content
    let speed: Double
    let contentWidth: CGFloat
    let direction: ScrollDirection
    
    @State private var animationId = UUID()
    @State private var xOffset: CGFloat = 0
    @Environment(\.scenePhase) private var scenePhase
    
    init(speed: Double, contentWidth: CGFloat, direction: ScrollDirection, @ViewBuilder content: () -> Content) {
        self.speed = speed
        self.contentWidth = contentWidth
        self.content = content()
        self.direction = direction
    }
    
    var body: some View {
        HStack(spacing: 0) {
            content.frame(width: contentWidth)
            content.frame(width: contentWidth)
            content.frame(width: contentWidth)
        }
        .offset(x: -contentWidth)
        .offset(x: xOffset)
        .id(animationId)
        .onAppear {
            startAnimation()
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase == .active {
                resetAndRestart()
            }
        }
    }
    
    private func resetAndRestart() {
        xOffset = 0
        animationId = UUID()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            startAnimation()
        }
    }
    
    private func startAnimation() {
        xOffset = 0
        if (speed > 0) {
            withAnimation(.linear(duration: speed).repeatForever(autoreverses: false)) {
                xOffset = (direction == .leftToRight) ? contentWidth : -contentWidth
            }
        }
    }
}
