import UIKit
import WebKit
import AdPopcornSSP

// MARK: - AdContentProvider Protocol

/// 광고 컨텐츠 제공자 프로토콜
/// 각 광고 타입(AdPopcornSSP, AdPopcornWebSDK, MobiWith)이 채택
protocol AdContentProvider: AnyObject {
    /// 광고 영역 크기 — 외부에서 주입 가능 (기본값 300×250)
    var adSize: CGSize { get set }
    /// 컨텐츠 뷰 (300×250 영역에 표시)
    var contentView: UIView { get }
    /// 광고 로드 시작 (targetView: 광고를 붙일 뷰, nil이면 contentView 사용)
    func loadAd(into targetView: UIView?)
    /// 광고 로드 시작 (기존 호환성 유지)
    func loadAd()
    /// 광고 중단 (팝업 닫기 시)
    func stopAd()
    /// 앱 포그라운드 복귀 알림 (Safari 체류 시간 계산용)
    func handleForeground()
    /// 로드 성공 콜백
    /// MobiWith: waitForRenderComplete + activateAd 완료 후 호출 (렌더링 완료 시점)
    /// AdPopcornSSP/WebSDK: 로드 즉시 호출
    var onLoaded:    (() -> Void)? { get set }
    /// 로드 실패 콜백 (순환)
    var onFailed:    (() -> Void)? { get set }
    /// 순환 없이 팝업만 닫기 (5초 미만 복귀 등)
    var onDismiss:   (() -> Void)? { get set }
    /// 클릭 콜백
    var onClicked:   (() -> Void)? { get set }
    /// 완료 콜백 (Safari 5초 체류 후)
    var onCompleted: (() -> Void)? { get set }
}

// MARK: - CommonAdPopupViewController

/// 통합 광고 팝업 VC
/// - showHeader: true  → 타이틀 + 서브타이틀 + X 버튼
/// - showHeader: false → X 버튼만 (CU 메인앱 광고)
final class CommonAdPopupViewController: UIViewController {

    // MARK: - Properties

    private let showHeader:      Bool
    private let titleText:       String
    private let subTitleText:    String
    var onComplete:  () -> Void         = {}
    var onFail:      () -> Void         = {}
    var onClose:     (() -> Void)?
    var onShown:     (() -> Void)?      // 광고 노출 시
    var onDismiss:   (() -> Void)?      // X버튼/5초미만 닫힘 시
    var onClicked:   (() -> Void)?      // 광고 클릭 시
    private let showToastOnFail: Bool

    private var isCompleted = false

    // UI
    private var contentContainer: UIView!
    private var loadingIndicator: UIActivityIndicatorView!

    // 현재 광고 provider
    private var currentProvider: (any AdContentProvider)?
    // 인디케이터 시작 시각 (최소 2초 보장)
    private var indicatorShownAt: Date?
    private let minIndicatorDuration: TimeInterval = 2.0

    // 배너 크기
    static let contentWidth:  CGFloat = 300
    static let contentHeight: CGFloat = 250

    // MARK: - Init

    init(
        showHeader:      Bool   = false,
        titleText:       String = Constants.Text.showAdForReward,
        subTitleText:    String = Constants.Text.mustOverFiveSeconds,
        showToastOnFail: Bool   = true,
        onComplete:      @escaping () -> Void = {},
        onFail:          @escaping () -> Void = {},
        onClose:         (() -> Void)?        = nil
    ) {
        self.showHeader      = showHeader
        self.titleText       = titleText
        self.subTitleText    = subTitleText
        self.showToastOnFail = showToastOnFail
        self.onComplete      = onComplete
        self.onFail          = onFail
        self.onClose         = onClose
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        modalTransitionStyle   = .crossDissolve
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleForeground),
            name: UIApplication.willEnterForegroundNotification,
            object: nil
        )
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func handleForeground() {
        currentProvider?.handleForeground()
    }

    // MARK: - Setup UI

    private func setupUI() {
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        let padding: CGFloat = 16
        let W = Self.contentWidth
        let H = Self.contentHeight
        let containerWidth  = W + padding * 2  // 332
        // showHeader=true:  타이틀+서브+마진 = 72pt
        // showHeader=false: 상단 마진 16pt만 (X 버튼은 광고 위에 오버레이)
        let headerHeight: CGFloat = showHeader ? (16 + 22 + 4 + 18 + 12) : 16
        let containerHeight = headerHeight + H + padding

        let container = UIView()
        container.backgroundColor    = .white
        container.layer.cornerRadius = 16
        container.clipsToBounds      = false
        container.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(container)

        NSLayoutConstraint.activate([
            container.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            container.widthAnchor.constraint(equalToConstant: containerWidth),
            container.heightAnchor.constraint(equalToConstant: containerHeight),
        ])

        // 닫기 버튼
        let closeButton = UIButton(type: .system)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .black
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        container.addSubview(closeButton)

        // 헤더 분기
        var contentTopAnchor: NSLayoutYAxisAnchor
        var contentTopOffset: CGFloat

        if showHeader {
            let titleLabel = UILabel()
            titleLabel.text          = titleText
            titleLabel.font          = .systemFont(ofSize: 16, weight: .bold)
            titleLabel.textColor     = .black
            titleLabel.textAlignment = .left
            titleLabel.numberOfLines = 1
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(titleLabel)

            let subLabel = UILabel()
            subLabel.text          = subTitleText
            subLabel.font          = .systemFont(ofSize: 13, weight: .regular)
            subLabel.textColor     = UIColor(red: 102/255, green: 102/255, blue: 102/255, alpha: 1)
            subLabel.textAlignment = .left
            subLabel.numberOfLines = 1
            subLabel.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(subLabel)

            NSLayoutConstraint.activate([
                closeButton.topAnchor.constraint(equalTo: container.topAnchor, constant: 12),
                closeButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -12),
                closeButton.widthAnchor.constraint(equalToConstant: 28),
                closeButton.heightAnchor.constraint(equalToConstant: 28),

                titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 16),
                titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                titleLabel.trailingAnchor.constraint(equalTo: closeButton.leadingAnchor, constant: -8),
                titleLabel.heightAnchor.constraint(equalToConstant: 22),

                subLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
                subLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                subLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
                subLabel.heightAnchor.constraint(equalToConstant: 18),
            ])
            contentTopAnchor = subLabel.bottomAnchor
            contentTopOffset = 12
        } else {
            // X 버튼을 광고 배너 우측 상단에 오버레이
            // → contentContainer 기준으로 나중에 배치 (contentContainer 생성 후 addSubview)
            contentTopAnchor = container.topAnchor
            contentTopOffset = 16
        }

        // 컨텐츠 영역 (300×250 고정)
        contentContainer = UIView()
        contentContainer.backgroundColor    = .white  // 항상 흰색 유지 — provider 교체 시 검은 깜빡임 방지
        contentContainer.layer.cornerRadius = 12
        contentContainer.layer.borderWidth  = 1
        contentContainer.layer.borderColor  = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1).cgColor
        contentContainer.clipsToBounds      = true
        contentContainer.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(contentContainer)

        NSLayoutConstraint.activate([
            contentContainer.topAnchor.constraint(equalTo: contentTopAnchor, constant: contentTopOffset),
            contentContainer.centerXAnchor.constraint(equalTo: container.centerXAnchor),
            contentContainer.widthAnchor.constraint(equalToConstant: W),
            contentContainer.heightAnchor.constraint(equalToConstant: H),
        ])

        // showHeader=false: X 버튼을 contentContainer 우측 상단에 오버레이
        if !showHeader {
            container.addSubview(closeButton)
            container.bringSubviewToFront(closeButton)
            NSLayoutConstraint.activate([
                closeButton.topAnchor.constraint(equalTo: contentContainer.topAnchor, constant: 4),
                closeButton.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor, constant: -4),
                closeButton.widthAnchor.constraint(equalToConstant: 30),
                closeButton.heightAnchor.constraint(equalToConstant: 30),
            ])
        }

        // 로딩 인디케이터
        loadingIndicator = UIActivityIndicatorView(style: .medium)
        loadingIndicator.color = .gray
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.translatesAutoresizingMaskIntoConstraints = false
        contentContainer.addSubview(loadingIndicator)

        NSLayoutConstraint.activate([
            loadingIndicator.centerXAnchor.constraint(equalTo: contentContainer.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: contentContainer.centerYAnchor),
        ])

        loadingIndicator.startAnimating()
    }

    // MARK: - 외부 콜백 설정

    /// 실패 시 호출할 클로저 교체 (팝업 유지 + provider 순환용)
    func setOnFail(_ closure: @escaping () -> Void) {
        onFail = closure
    }

    // MARK: - 광고 로드

    /// 광고 provider를 교체하고 로드 시작
    /// dismiss 없이 contentContainer 내부만 교체
    func loadProvider(_ provider: any AdContentProvider) {
        // 기존 provider 중단 및 뷰 제거
        currentProvider?.stopAd()
        currentProvider?.contentView.removeFromSuperview()
        currentProvider = provider

        // 인디케이터 표시 (시작 시각 기록 — 최소 2초 보장)
        contentContainer.backgroundColor = .white
        indicatorShownAt = Date()
        loadingIndicator.startAnimating()

        // 새 컨텐츠 뷰 추가 — 처음엔 숨김, adLoaded 후 표시
        let cv = provider.contentView
        cv.frame = CGRect(x: 0, y: 0,
                         width: Self.contentWidth,
                         height: Self.contentHeight)
        cv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        cv.alpha = 0  // 로드 완료 전 투명
        contentContainer.insertSubview(cv, belowSubview: loadingIndicator)

        // 레이아웃 확정 후 contentView 크기 맞춤
        contentContainer.layoutIfNeeded()
        cv.frame = contentContainer.bounds


        provider.onClicked = { [weak self] in
            self?.onClicked?()
        }
        provider.onLoaded = { [weak self] in
            DispatchQueue.main.async {
                guard let self else { return }
                // 로드 성공 후 onFailed 해제 — 이후 실패 이벤트로 순환하지 않음
                provider.onFailed = nil
                // 최소 2초 인디케이터 보장 후 contentView 페이드인
                let elapsed = self.indicatorShownAt.map { Date().timeIntervalSince($0) } ?? self.minIndicatorDuration
                let remaining = max(self.minIndicatorDuration - elapsed, 0)
                DispatchQueue.main.asyncAfter(deadline: .now() + remaining) { [weak self] in
                    guard let self else { return }
                    UIView.animate(withDuration: 0.2) { cv.alpha = 1 }
                    self.onShown?()
                    self.loadingIndicator.stopAnimating()
                }
            }
        }
        provider.onFailed = { [weak self] in
            DispatchQueue.main.async {
                self?.handleFail()
            }
        }
        provider.onClicked = { [weak self] in
            self?.onClicked?()
        }

        // onDismiss: 5초 미만 복귀 등 — 순환 없이 팝업만 닫기
        provider.onDismiss = { [weak self] in
            DispatchQueue.main.async {
                self?.dismissOnly()
            }
        }

        // onCompleted: Safari 5초 체류 또는 클릭 완료 시 handleComplete 호출
        provider.onCompleted = { [weak self] in
            DispatchQueue.main.async {
                self?.handleComplete()
            }
        }

        provider.loadAd()
    }

    // MARK: - Actions

    @objc private func closeTapped() {
        guard !isCompleted else { return }
        isCompleted = true
        currentProvider?.stopAd()
        dismiss(animated: true) {
            self.onClose?()  // 내부 호출 시 onClose 콜백 (nil이면 무시)
        }
    }

    func handleComplete() {
        guard !isCompleted else { return }
        isCompleted = true
        currentProvider?.stopAd()
        dismiss(animated: true) { self.onComplete() }
    }

    func handleFail() {
        guard !isCompleted else { return }
        currentProvider?.stopAd()
        currentProvider = nil
        loadingIndicator.startAnimating()
        // 팝업 유지 — onFail 콜백으로 다음 provider 로드 요청
        onFail()
    }

    func dismissWithFail() {
//        guard !isCompleted else { return }
        isCompleted = true
        currentProvider?.stopAd()
        dismiss(animated: true) {
            if self.showToastOnFail {
                OverlayManager.shared.showToast(Constants.Text.noAvailableAdDesc)
            }
        }
    }

    /// 순환 없이 팝업만 닫기 (5초 미만 복귀 등)
    func dismissOnly() {
        guard !isCompleted else { return }
        isCompleted = true
        currentProvider?.stopAd()
        dismiss(animated: true) {
            self.onDismiss?()
        }
    }
}

// MARK: - AdPopcornSSPBannerProvider (D0000287)

final class AdPopcornSSPBannerProvider: NSObject, AdContentProvider {

    var onLoaded:    (() -> Void)?
    var onFailed:    (() -> Void)?
    var onDismiss:   (() -> Void)?
    var onClicked:   (() -> Void)?
    var onCompleted: (() -> Void)?

    /// 광고 영역 크기 — 외부에서 주입 가능 (기본값 300×250)
    var adSize: CGSize = CGSize(width: CommonAdPopupViewController.contentWidth,
                                height: CommonAdPopupViewController.contentHeight)

    private let placementId: String
    private weak var viewController: UIViewController?
    private var bannerView: AdPopcornSSPBannerView?
    private var hasLoadedOnce  = false
    private var safariOpenedAt: Date?  // 클릭 후 Safari 이동 시각

    func handleForeground() {
        guard let openedAt = safariOpenedAt else { return }
        let elapsed = Date().timeIntervalSince(openedAt)
        safariOpenedAt = nil
        // CULog("[AdPopcornSSP] Safari 복귀 | 체류: \(String(format: "%.1f", elapsed))초")
        if elapsed >= 5.0 {
            onCompleted?()
        } else {
            // CULog("[AdPopcornSSP] 5초 미만 복귀 → 미완료")
            onDismiss?()
        }
    }

    private(set) lazy var contentView: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        return v
    }()

    init(placementId: String, viewController: UIViewController) {
        self.placementId    = placementId
        self.viewController = viewController
    }

    func loadAd() { loadAd(into: nil) }

    func loadAd(into targetView: UIView?) {
        guard let vc = viewController else { return }
        let container = targetView ?? contentView
        let banner = AdPopcornSSPBannerView(
            bannerViewSize: SSPBannerViewSize300x250,
            origin: .zero,
            appKey: Constants.AdPopcorn.appKey,
            placementId: placementId,
            viewController: vc
        )
        banner?.delegate = self
        banner?.setAutoBgColor(false)
        banner?.adRefreshRate = -1
        if let banner = banner {
            // container 크기에 맞게 frame 설정
            banner.frame = container.bounds
            banner.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            container.addSubview(banner)
        }
        bannerView = banner
        bannerView?.loadRequest()
        CULog("[AdPopcornSSP] 배너 로드 | placementId=\(placementId)")
    }


    func stopAd() {
        bannerView?.removeFromSuperview()
        bannerView = nil
    }
}

extension AdPopcornSSPBannerProvider: APSSPBannerViewDelegate {
    func apsspBannerViewLoadSuccess(_ bannerView: AdPopcornSSPBannerView!) {
        CULog("[AdPopcornSSP] 로드 성공")
        hasLoadedOnce = true
        // banner frame 재설정 — adSize 기준
        if let banner = bannerView {
            banner.frame = CGRect(origin: .zero, size: adSize)
        }
        onLoaded?()
    }

    func apsspBannerViewLoadFail(_ bannerView: AdPopcornSSPBannerView!, error: AdPopcornSSPError!) {
        CULog("[AdPopcornSSP] 로드 실패: \(error?.description ?? "unknown")")
        if hasLoadedOnce { return }  // 리프레시 No Ad 무시
        onFailed?()
    }

    func apsspBannerViewClicked(_ bannerView: AdPopcornSSPBannerView!) {
        CULog("[AdPopcornSSP] 클릭")
        safariOpenedAt = Date()
        onClicked?()
        // onCompleted는 handleForeground에서 5초 체류 후 호출
    }
}

// MARK: - AdPopcornWebSDKProvider (D0000276)

final class AdPopcornWebSDKProvider: NSObject, AdContentProvider, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {

    var onLoaded:    (() -> Void)?
    var onRendered:  (() -> Void)?  // AdPopcornWebSDK는 onLoaded와 동시
    var onFailed:    (() -> Void)?
    var onDismiss:   (() -> Void)?
    var onClicked:   (() -> Void)?
    var onCompleted: (() -> Void)?

    /// 광고 영역 크기 — 외부에서 주입 가능 (기본값 300×250)
    var adSize: CGSize = CGSize(width: CommonAdPopupViewController.contentWidth,
                                height: CommonAdPopupViewController.contentHeight)

    private let placementId:   String
    private let zoneId:        String   // MobiWith 패스백용
    private var isClickedFired = false  // onClicked 중복 방지
    private var webView:     WKWebView?
    private var adTimeoutTask: Task<Void, Never>?
    private var isCompleted   = false
    private var safariOpenedAt: Date?
    private let requiredSafariDuration: TimeInterval = 5.0
    var showToastOnShortVisit: Bool = true  // false: 외부 호출(타이틀 없음) — 5초 미만 토스트 생략

    func handleForeground() {
        guard let openedAt = safariOpenedAt else { return }
        let elapsed = Date().timeIntervalSince(openedAt)
        safariOpenedAt = nil
//        CULog("[WebSDK] Safari 복귀 | 체류: \(String(format: "%.1f", elapsed))초")
        if elapsed >= requiredSafariDuration {
            CULog("[WebSDK] 5초 이상 체류 → 완료")
            onCompleted?()
        } else {
            CULog("[WebSDK] 5초 미만 복귀 → 미완료")
            guard !isCompleted else { return }
            isCompleted = true
            adTimeoutTask?.cancel()
            if showToastOnShortVisit {
                DispatchQueue.main.async {
                    OverlayManager.shared.showToast(Constants.Text.mustOverFiveSeconds)
                }
            }
            // 순환 없이 팝업만 닫기
            onDismiss?()
        }
    }

    private(set) lazy var contentView: UIView = UIView()

    init(placementId: String, zoneId: String) {
        self.placementId = placementId
        self.zoneId      = zoneId
    }

    func loadAd() { loadAd(into: nil) }

    func loadAd(into targetView: UIView?) {
        let container = targetView ?? contentView
        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "adLoaded")
        config.userContentController.add(self, name: "adFailed")
        config.userContentController.add(self, name: "adClicked")
        config.userContentController.add(self, name: "jsLog")
        config.allowsInlineMediaPlayback = true

        let wv = WKWebView(frame: CGRect(x: 0, y: 0,
                                         width:  adSize.width,
                                         height: adSize.height),
                           configuration: config)
        wv.navigationDelegate = self
        wv.uiDelegate         = self
        wv.scrollView.isScrollEnabled = false
        wv.scrollView.bounces         = false
        wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        container.addSubview(wv)
        webView = wv

        let idfa = adIdentifier()  // Utils.swift 전역 함수 — IDFA 우선, 없으면 IDFV
        let html = buildHTML(adId: idfa)
        wv.loadHTMLString(html, baseURL: URL(string: "https://webapi.adpopcorn.com"))

        // 10초 타임아웃
        adTimeoutTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            guard !Task.isCancelled, self?.isCompleted == false else { return }
            CULog("[WebSDK] 타임아웃 → 실패")
            self?.isCompleted = true
            self?.onFailed?()
        }
        CULog("[WebSDK] 광고 로드 | placementId=\(placementId)")
    }

    func stopAd() {
        adTimeoutTask?.cancel()
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adLoaded")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adFailed")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adClicked")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "jsLog")
        webView?.removeFromSuperview()
        webView = nil
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "adLoaded":
            guard !isCompleted else { return }
            adTimeoutTask?.cancel()
            CULog("[WebSDK] 광고 로드 완료")
            onLoaded?()
            onRendered?()
        case "adFailed":
            guard !isCompleted else { return }
            adTimeoutTask?.cancel()
            isCompleted = true
            CULog("[WebSDK] adFailed | body=\(message.body)")
            onFailed?()
        case "adClicked":
            // JS에서 직접 발송하는 클릭 이벤트
            // safariOpenedAt 세팅 → handleForeground에서 5초 체류 확인 후 onCompleted
//            CULog("[WebSDK] adClicked — safariOpenedAt 세팅")
            safariOpenedAt = Date()
            if !isClickedFired {
                isClickedFired = true
                onClicked?()
            }
        case "jsLog":
            CULog("[WebSDK][JS] \(message.body)")
        default: break
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        guard !isCompleted else { return }
        isCompleted = true
        adTimeoutTask?.cancel()
        CULog("[WebSDK] didFail: \(error.localizedDescription)")
        onFailed?()
    }

    // 광고 클릭 → Safari 오픈 (AdPopcorn 네이티브 광고 링크 처리)
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow); return
        }
        guard navigationAction.navigationType == .linkActivated else {
            decisionHandler(.allow); return
        }
        decisionHandler(.cancel)
        if UIApplication.shared.canOpenURL(url) {
            safariOpenedAt = Date()
            if !isClickedFired {
                isClickedFired = true
                onClicked?()
            }
            CULog("[WebSDK] move | url=\(url.absoluteString)")
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }

    // window.open 처리
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else { return nil }
        if UIApplication.shared.canOpenURL(url) {
            safariOpenedAt = Date()
            if !isClickedFired {
                isClickedFired = true
                onClicked?()
            }
            CULog("[WebSDK] window.open | url=\(url.absoluteString)")
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        return nil
    }

    private func buildHTML(adId: String) -> String {
        let hasPassback = !zoneId.isEmpty
        let noAdAction  = hasPassback
            ? "setPassbackBannerAd(bannerAdInventoryFrameId, \"reward-banner-ad-inventory-frame\");"
            : "window.webkit.messageHandlers.adFailed.postMessage(\"failed\");"

        let passbackScript = hasPassback ? """
            const setPassbackBannerAd = (frameId, bannerAdId) => {
                const frame = document.getElementById(frameId);
                const bannerAd = document.createElement("iframe");
                bannerAd.id = bannerAdId;
                bannerAd.dataset.clicked = "false";
                Object.assign(bannerAd.style, { border: "none", width: "300px", height: "250px" });
                bannerAd.src = "https://www.mobwithad.com/api/banner/app/adpopcorn/v2/adpopcorn?zone=\(zoneId)&w=300&h=250&adid=\(adId)";
                frame.appendChild(bannerAd);
                bannerAd.addEventListener("load", () => {
                    try { const doc = bannerAd.contentDocument || bannerAd.contentWindow?.document; if (doc && doc.body) doc.body.style.margin = "0"; } catch(e) {}
                    window.webkit.messageHandlers.adLoaded.postMessage("loaded");
                    window.addEventListener("blur", () => iframeClickEventHandler(bannerAd));
                    window.focus();
                });
                bannerAd.addEventListener("error", () => { window.webkit.messageHandlers.adFailed.postMessage("passback_error"); });
            };
            const iframeClickEventHandler = (adElement) => {
                if (!document.activeElement || document.activeElement.tagName !== "IFRAME") return;
                if (adElement.dataset.clicked === "true") return;
                if (document.activeElement.id === adElement.id) {
                    adElement.dataset.clicked = "true";
                    window.webkit.messageHandlers.adClicked.postMessage("clicked");
                }
                window.addEventListener("visibilitychange", () => { window.focus(); });
            };
        """ : ""

        return """
        <!DOCTYPE html><html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script async src="https://webapi.adpopcorn.com/ssp/web-sdk/ap-ssp-web-sdk-1.14.1.min.js"></script>
            <script>window.AdPopcornSSPWebSDK = window.AdPopcornSSPWebSDK || { cmd: [] };</script>
            <style>body { margin: 0; padding: 0; overflow: hidden; }</style>
        </head>
        <body>
            <div id="adpopcorn-banner-ad-inventory-frame"></div>
            <script>
                let banner300x250;
                AdPopcornSSPWebSDK.cmd.push(() => {
                    AdPopcornSSPWebSDK.init({ app_key: "\(Constants.AdPopcorn.appKey)", placement_id: "\(placementId)", log_enabled: false, log_level: 0 });
                    AdPopcornSSPWebSDK.setConfig({ idfa: "\(adId)" });
                });
                AdPopcornSSPWebSDK.cmd.push(() => {
                    const bannerAdInventoryFrameId = "adpopcorn-banner-ad-inventory-frame";
                    banner300x250 = AdPopcornSSPWebSDK.createBannerSize300x250();
                    banner300x250.addEventListener("sdkError", (e) => { window.webkit.messageHandlers.adFailed.postMessage("sdkError"); });
                    banner300x250.addEventListener("adInventoryRendered", (e) => {
                        window.webkit.messageHandlers.jsLog.postMessage("adInventoryRendered isNoAd=" + e.isNoAd);
                        if (e.isNoAd) { \(noAdAction) }
                        else {
                            const imgs = document.querySelectorAll("img");
                            if (imgs.length === 0) { window.webkit.messageHandlers.adLoaded.postMessage("loaded"); return; }
                            let cnt = 0;
                            const notify = () => { if (++cnt >= imgs.length) window.webkit.messageHandlers.adLoaded.postMessage("loaded"); };
                            imgs.forEach(img => { if (img.complete) { notify(); } else { img.addEventListener("load", notify); img.addEventListener("error", notify); } });
                        }
                    });
                    banner300x250.addEventListener("adClicked", () => { window.webkit.messageHandlers.adClicked.postMessage("clicked"); });
                    banner300x250.display(bannerAdInventoryFrameId);
                });
            </script>
            \(hasPassback ? "<script>\(passbackScript)</script>" : "")
        </body></html>
        """
    }
}

// MARK: - MobiWithProvider (D0000246)

final class MobiWithProvider: NSObject, AdContentProvider, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {

    var onLoaded:    (() -> Void)?
    var onRendered:  (() -> Void)?  // 실제 렌더링 완료 시점 (인디케이터 제거용)
    var onFailed:    (() -> Void)?
    var onDismiss:   (() -> Void)?
    var onClicked:   (() -> Void)?
    var onCompleted: (() -> Void)?

    /// 광고 영역 크기 — 외부에서 주입 가능 (기본값 300×250)
    var adSize: CGSize = CGSize(width: CommonAdPopupViewController.contentWidth,
                                height: CommonAdPopupViewController.contentHeight)

    private let zoneId: String

    private var webView:        WKWebView?
    private var timeoutTask:    Task<Void, Never>?
    private var isLoading       = false
    private var isAdReady       = false
    private var isCompleted     = false
    private var safariOpenedAt: Date?
    var showToastOnShortVisit: Bool = true  // false: 외부 호출 — 5초 미만 토스트 생략
    private let timeoutSec: Double = 6.0

    private let baseURL   = "https://www.mobwithad.com"
    private let mediaId   = "adwon"
    private let serviceId = "adwon"

    private(set) lazy var contentView: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        return v
    }()

    init(zoneId: String) {
        self.zoneId = zoneId
    }

    // MARK: - AdContentProvider

    func loadAd() { loadAd(into: nil) }

    func loadAd(into targetView: UIView?) {
        let container = targetView ?? contentView
        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "mobwithBridge")
        config.allowsInlineMediaPlayback = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            config.defaultWebpagePreferences.allowsContentJavaScript = true
        }

        let wv = WKWebView(frame: CGRect(x: 0, y: 0,
                                         width:  adSize.width,
                                         height: adSize.height),
                           configuration: config)
        wv.navigationDelegate      = self
        wv.uiDelegate              = self
        wv.scrollView.bounces      = false
        wv.scrollView.isScrollEnabled = false
        wv.scrollView.minimumZoomScale = 1.0
        wv.scrollView.maximumZoomScale = 1.0
        wv.scrollView.zoomScale    = 1.0
        wv.backgroundColor         = .white
        wv.isUserInteractionEnabled = false  // 로드 완료 전 터치 차단
        wv.autoresizingMask        = [.flexibleWidth, .flexibleHeight]
        container.addSubview(wv)
        webView = wv

        let adId = adIdentifier()
        let urlString = "\(baseURL)/api/banner/app/\(mediaId)/v2/\(serviceId)"
            + "?zone=\(zoneId)"
            + "&output=html"
            + "&os_type=ios"
            + "&w=300&h=250"
            + "&adid=\(adId)"
            + "&userAdTrackingYn=Y"

        CULog("[MobiWith] 광고 로드 | zone=\(zoneId)")
        guard let url = URL(string: urlString) else {
            onFailed?()
            return
        }


        isLoading = true
        wv.load(URLRequest(url: url))

        timeoutTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64((self?.timeoutSec ?? 6.0) * 1_000_000_000))
            guard !Task.isCancelled, self?.isLoading == true else { return }
            CULog("[MobiWith] 타임아웃 → 실패")
            self?.fail()
        }
    }

    func stopAd() {
        timeoutTask?.cancel()
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "mobwithBridge")
        webView?.removeFromSuperview()
        webView = nil
    }

    func handleForeground() {
        guard let openedAt = safariOpenedAt else { return }
        let elapsed = Date().timeIntervalSince(openedAt)
        safariOpenedAt = nil
//        CULog("[MobiWith] Safari 복귀 | 체류: \(String(format: "%.1f", elapsed))초")

        if elapsed >= 5.0 {
            complete()
        } else {
//            CULog("[MobiWith] 5초 미만 복귀 → 미완료")
            guard !isCompleted else { return }
            isCompleted = true
            isLoading   = false
            timeoutTask?.cancel()
            if showToastOnShortVisit {
                DispatchQueue.main.async {
                    OverlayManager.shared.showToast(Constants.Text.mustOverFiveSeconds)
                }
            }
            // 순환 없이 팝업만 닫기
            onDismiss?()
        }
    }

    // MARK: - 완료/실패

    private func complete() {
        guard !isCompleted else { return }
        isCompleted = true
        isLoading   = false
        timeoutTask?.cancel()
//        CULog("[MobiWith] 완료")
        onCompleted?()
    }

    private func fail() {
        guard !isCompleted else { return }
        isCompleted = true
        isLoading   = false
        timeoutTask?.cancel()
        CULog("[MobiWith] 실패")
        onFailed?()
    }

    // MARK: - 렌더링 완료 감지

    private func activateAd() {
        isAdReady = true
        webView?.isUserInteractionEnabled = true
        CULog("[MobiWith] 광고 활성화 완료")
        // MobiWith는 iframe 기반이라 실제 렌더링에 시간이 더 걸림
        // 추가 1초 대기 후 onLoaded 호출 → CommonAdPopupViewController에서 최소 2초 보장과 합산
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            guard let self, let wv = self.webView else { return }
            // WKWebView 크기 강제 재설정 — 타임아웃 후 레이아웃 어긋남 보정
            wv.frame = CGRect(origin: .zero, size: self.adSize)
            wv.setNeedsLayout()
            wv.layoutIfNeeded()
            self.onLoaded?()
        }
    }

    /// 안드로이드 RenderDetectWebViewClient 동일 로직 iOS 포팅
    /// 0.5초마다 스냅샷 하단 10% 영역을 크롭해 픽셀 변화율 비교
    /// 변화율 5% 이상 감지 시 렌더링 완료로 판단 (연속 1회)
    private func waitForRenderComplete(attempt: Int = 0, previousSnapshot: UIImage? = nil) {
        let maxAttempts    = 90    // 최대 45초 (0.5초 × 90)
        let threshold      = 5.0   // 픽셀 변화율 임계값 (%)
        let activateDelay  = 0.5   // 감지 후 실제 렌더링 완료까지 대기 (초)
        let checkAreaRatio = 0.1   // 하단 10% 영역 체크
        let widthRatio     = 0.8   // 좌우 80% 체크

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self, !self.isCompleted else { return }
            guard let webView = self.webView else { return }

            let config = WKSnapshotConfiguration()
            // webView.bounds 대신 adSize 사용 — bounds가 0인 경우 스크린샷이 빈 이미지가 되는 것 방지
            let snapSize = webView.bounds.size.width > 0 ? webView.bounds.size : self.adSize
            config.rect = CGRect(origin: .zero, size: snapSize)

            webView.takeSnapshot(with: config) { [weak self] image, error in
                guard let self, !self.isCompleted else { return }

                guard let image else {
                    if attempt < maxAttempts {
                        self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: previousSnapshot)
                    } else { self.fail() }
                    return
                }

                // 첫 프레임 — 기준으로만 저장
                guard let prev = previousSnapshot else {
                    self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: image)
                    return
                }

                // 하단 10%, 좌우 80% 크롭
                let cropped    = self.cropTargetArea(image,  areaRatio: checkAreaRatio, widthRatio: widthRatio)
                let croppedPrev = self.cropTargetArea(prev,  areaRatio: checkAreaRatio, widthRatio: widthRatio)

                let diff = self.calculateDiff(old: croppedPrev, new: cropped)
//                CULog("[MobiWith] 스냅샷 attempt=\(attempt) diff=\(String(format: "%.1f", diff))%")

                if diff >= threshold {
                    // 변화율 감지 → 실제 렌더링 완료까지 2초 대기
                    CULog("[MobiWith] 렌더링 감지 (diff=\(String(format: "%.1f", diff))%) → \(activateDelay)초 후 활성화")
                    DispatchQueue.main.asyncAfter(deadline: .now() + activateDelay) { [weak self] in
                        guard let self = self else { return }
                        guard !self.isCompleted else { return }
                        CULog("[MobiWith] 렌더링 완료")
                        self.activateAd()
                    }
                    return  // 타이머 등록 후 루프 중단
                } else if attempt < maxAttempts {
                    self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: image)
                } else {
                    CULog("[MobiWith] 렌더링 타임아웃")
                    self.activateAd()
                }
            }
        }
    }

    /// 하단 areaRatio%, 중앙 widthRatio% 영역 크롭 (안드로이드 cropTargetArea 동일)
    private func cropTargetArea(_ image: UIImage, areaRatio: Double, widthRatio: Double) -> UIImage {
        guard let cgImage = image.cgImage else { return image }
        let w = CGFloat(cgImage.width)
        let h = CGFloat(cgImage.height)

        let cropH = max(h * CGFloat(areaRatio), 1)
        let cropW = max(w * CGFloat(widthRatio), 1)
        let cropX = (w - cropW) / 2
        let cropY = h - cropH

        guard let cropped = cgImage.cropping(to: CGRect(x: cropX, y: cropY, width: cropW, height: cropH)) else {
            return image
        }
        return UIImage(cgImage: cropped)
    }

    /// 픽셀 변화율 계산 — 8픽셀 간격 샘플링 (안드로이드 calculateDiff 동일)
    private func calculateDiff(old: UIImage, new: UIImage) -> Double {
        guard let oldCG = old.cgImage, let newCG = new.cgImage else { return 0 }

        let width  = min(oldCG.width, newCG.width)
        let height = min(oldCG.height, newCG.height)
        guard width > 0, height > 0 else { return 0 }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let bytesPerPixel = 4
        let bytesPerRow   = bytesPerPixel * width

        var oldPixels = [UInt8](repeating: 0, count: height * bytesPerRow)
        var newPixels = [UInt8](repeating: 0, count: height * bytesPerRow)

        guard let oldCtx = CGContext(data: &oldPixels, width: width, height: height,
                                     bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                     space: colorSpace, bitmapInfo: bitmapInfo.rawValue),
              let newCtx = CGContext(data: &newPixels, width: width, height: height,
                                     bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                     space: colorSpace, bitmapInfo: bitmapInfo.rawValue)
        else { return 0 }

        oldCtx.draw(oldCG, in: CGRect(x: 0, y: 0, width: width, height: height))
        newCtx.draw(newCG, in: CGRect(x: 0, y: 0, width: width, height: height))

        var changed = 0
        var total   = 0
        let step    = 8  // 8픽셀 간격 샘플링

        for x in stride(from: 0, to: width, by: step) {
            for y in stride(from: 0, to: height, by: step) {
                let idx = y * bytesPerRow + x * bytesPerPixel
                if oldPixels[idx]   != newPixels[idx]   ||
                   oldPixels[idx+1] != newPixels[idx+1] ||
                   oldPixels[idx+2] != newPixels[idx+2] {
                    changed += 1
                }
                total += 1
            }
        }

        return total > 0 ? Double(changed) / Double(total) * 100.0 : 0
    }
}

// MARK: - WKNavigationDelegate

extension MobiWithProvider {

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow); return
        }
        let urlStr = url.absoluteString

        if urlStr == "about:blank" { decisionHandler(.allow); return }
        if urlStr.contains("mobwithad.com") { decisionHandler(.allow); return }

        guard navigationAction.navigationType == .linkActivated else {
            decisionHandler(.allow); return
        }
        guard isAdReady else { decisionHandler(.cancel); return }

        CULog("[MobiWith] 광고 클릭 → Safari: \(urlStr)")
        decisionHandler(.cancel)

        if UIApplication.shared.canOpenURL(url) {
            safariOpenedAt = Date()
            onClicked?()  // 광고 클릭 콜백
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            fail()
        }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoading = false
        webView.evaluateJavaScript("document.body.innerHTML") { [weak self] result, _ in
            guard let self, !self.isCompleted else { return }
            let html = result as? String ?? ""

//            CULog("[MobiWith] HTML 길이=\(html.count) 앞200=\(String(html.prefix(200)))")

            if html.contains("noad") || html.contains("no ad") || html.isEmpty {
                CULog("[MobiWith] noad 감지 → 실패")
                self.fail()
                return
            }
            CULog("[MobiWith] HTML LOADED")
            self.waitForRenderComplete()
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        CULog("[MobiWith] didFail: \(error.localizedDescription) code=\((error as NSError).code)")
        fail()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        CULog("[MobiWith] didFailProvisional: \(error.localizedDescription) code=\((error as NSError).code)")
        fail()
    }
}

// MARK: - WKUIDelegate (window.open 처리)

extension MobiWithProvider {
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard isAdReady, let url = navigationAction.request.url else { return nil }
        let urlStr = url.absoluteString
        if urlStr != "about:blank", !urlStr.contains("mobwithad.com") {
            // CULog("[MobiWith] window.open → Safari: \(urlStr)")
            safariOpenedAt = Date()
            onClicked?()  // 광고 클릭 콜백
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        return nil
    }
}

// MARK: - WKScriptMessageHandler

extension MobiWithProvider {
    func userContentController(_ userContentController: WKUserContentController,
                                didReceive message: WKScriptMessage) {
        guard message.name == "mobwithBridge",
              let body = message.body as? String,
              let data = body.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let detail = json["detail"] as? [String: Any],
              detail["landingURL"] is String else { return }
        CULog("[MobiWith] postMessage → 완료")
        complete()
    }
}
