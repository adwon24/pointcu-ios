//
//  BannerRouter.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/29/26.
//
//  Android 라우팅 로직 iOS 포팅:
//  1. 게임(가위바위보, 동전뒤집기) → 게임 화면으로 이동
//  2. 오퍼월 → mainData의 offerwallServiceCodeList에서 해당 detailId로 SDK 코드 조회 → 오퍼월 실행
//  3. 배너(애드팝콘 등) → 광고 처리
//  4. 룰렛/복권 영역 → 해당 게임 화면으로 이동
//

import UIKit
 
@MainActor
struct BannerRouter {
 
    // MARK: - 단일 진입점
 
    static func handle(_ item: UiBannerItem) {
        guard let orderCode = UiOrderCode(rawValue: item.detailId) else {
            CULog("[BannerRouter] 알 수 없는 detailId: \(item.detailId)")
            return
        }
 
        switch orderCode {
 
        // ── 가위바위보 ────────────────────────────────────────────────
        case .serviceGameRPS:
            if let adKey = resolveAdKey(detailId: item.detailId),
               let topVC = topViewController() {
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
                NStationManager.shared.openRPSGame(adKey: adKey, userId: userId, from: topVC)
            }
 
        case .serviceGameCoin:
            if let adKey = resolveAdKey(detailId: item.detailId),
               let topVC = topViewController() {
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
                NStationManager.shared.openCoinGame(adKey: adKey, userId: userId, from: topVC)
            }
 
        case .offerwallAdForusSDK:
            if let appCode = resolveOfferwallAdKey(from: item),
               let topVC = topViewController() {
                // {"app":"adwon_cu","id":서버UserInfo.id} JSON 형식
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
//                let userKey  = "{\"app\":\"adwon_cu\",\"id\":\(serverId)}"
                GreenPManager.shared.openOfferwall(appCode: appCode, userId: userId, from: topVC)
            }
 
        case .offerwallNStationSDK:
            if let adKey = resolveOfferwallAdKey(from: item),
               let topVC = topViewController() {
                // {mcKey},{서버UserInfo.id} 형식 — NStationManager 내부에서 조합
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
                NStationManager.shared.openOfferwall(adKey: adKey, userId: userId, from: topVC)
            }

        // ── 룰렛 / 복권 영역 ─────────────────────────────────────────
        // 해당 케이스는 MainBenefitListView의 BenefitItemView에서 직접 처리
        // BannerRouter에서는 UiBannerItem만 받으므로 BenefitItem을 알 수 없음
        // → 실제로 이 경로로 진입하지 않음
        case .rouletteArea, .lotteryArea:
            CULog("[BannerRouter] 룰렛/복권 영역은 BenefitItemView에서 처리")
 
        // ── 애드팝콘 배너 ─────────────────────────────────────────────
        case .bannerHomeSmall:
            // TODO: 애드팝콘 배너 타입 확정 후 구현
            CULog("[BannerRouter] 애드팝콘 배너 탭 — 미구현")
 
        // ── 애드원 배너 (link_type 분기) ─────────────────────────────
        case .bannerAdwon:
            handleAdwonBanner(item: item)
 
        default:
            CULog("[BannerRouter] 알 수 없는 코드: \(item.detailId)")
        }
    }
 
    // MARK: - 애드원 배너 (link_type 기반 분기)
 
    private static func handleAdwonBanner(item: UiBannerItem) {
        guard let bannerInfo = item.bannerInfo else { return }
 
        switch bannerInfo.linkType {
 
        case "S":
            // 서비스 화면으로 이동 — serviceDetailId 기준으로 재귀 호출
            guard !bannerInfo.serviceDetailId.isEmpty,
                  let code = UiOrderCode(rawValue: bannerInfo.serviceDetailId) else { return }
            handle(UiBannerItem(
                detailId: code.rawValue,
                title: bannerInfo.title,
                displayOrder: item.displayOrder,
                bannerInfo: bannerInfo
            ))
 
        case "O":
            // 오퍼월
            handleOfferwallFromAdwon(item: item, bannerInfo: bannerInfo)
 
        case "U":
            // 외부 URL → Safari
            guard !bannerInfo.linkData.isEmpty,
                  let url = URL(string: bannerInfo.linkData) else { return }
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
 
        case "N":
            // TODO: 공지사항 화면/팝업 구현
            CULog("[BannerRouter] 공지사항 | linkData: \(bannerInfo.linkData)")
 
        default:
            CULog("[BannerRouter] 알 수 없는 linkType: \(bannerInfo.linkType)")
        }
    }
 
    // MARK: - 애드원 배너 오퍼월 처리
 
    private static func handleOfferwallFromAdwon(item: UiBannerItem, bannerInfo: BannerInfo) {
        guard !bannerInfo.offerwallDetailId.isEmpty else { return }
 
        let offerwallOrderCode = UiOrderCode(rawValue: bannerInfo.offerwallDetailId)
 
        switch offerwallOrderCode {
        case .offerwallNStationSDK:
            if let adKey = resolveOfferwallAdKey(from: item),
               let topVC = topViewController() {
                // {mcKey},{서버UserInfo.id} 형식 — NStationManager 내부에서 조합
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
                NStationManager.shared.openOfferwall(adKey: adKey, userId: userId, from: topVC)
            }
        case .offerwallAdForusSDK:
            if let appCode = resolveOfferwallAdKey(from: item),
               let topVC = topViewController() {
                // {"app":"adwon_cu","id":서버UserInfo.id} JSON 형식
                let userId = String(AppDataManager.shared.mainData?.user.id ?? 0)
//                let userKey  = "{\"app\":\"adwon_cu\",\"id\":\(serverId)}"
                GreenPManager.shared.openOfferwall(appCode: appCode, userId: userId, from: topVC)
            }
        default:
            CULog("[BannerRouter] 미지원 오퍼월: \(bannerInfo.offerwallDetailId)")
        }
    }
 
    // MARK: - 헬퍼
 
    /// detailId로 offerwallServiceCodeList에서 adKey 조회 (게임용)
    private static func resolveAdKey(detailId: String) -> String? {
        AppDataManager.shared.mainData?.sdk.offerwallServiceCodeList
            .first(where: { $0.detailId == detailId })
            .map { $0.code }
    }
 
    /// bannerInfo.offerwallDetailId로 adKey 조회 (오퍼월용)
    private static func resolveOfferwallAdKey(from item: UiBannerItem) -> String? {
        guard let offerwallDetailId = item.bannerInfo?.offerwallDetailId,
              !offerwallDetailId.isEmpty else { return nil }
        return AppDataManager.shared.mainData?.sdk.offerwallServiceCodeList
            .first(where: { $0.detailId == offerwallDetailId })
            .map { $0.code }
    }
 
    /// 현재 최상위 UIViewController 반환 — SwiftUI 내부 호스팅 VC 제외
    private static func topViewController() -> UIViewController? {
        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }),
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
        else { return nil }
 
        var top = root
        while let presented = top.presentedViewController {
            top = presented
        }
 
        // SwiftUI PresentationHostingController면 parent로 올라감
        while top.isSwiftUIHostingController {
            guard let parent = top.parent ?? top.presentingViewController else { break }
            top = parent
        }
 
        return top
    }
}
 
// MARK: - UIViewController SwiftUI 호스팅 VC 판별
 
private extension UIViewController {
    var isSwiftUIHostingController: Bool {
        let typeName = String(describing: type(of: self))
        return typeName.contains("PresentationHostingController")
            || typeName.contains("HostingController")
    }
}
