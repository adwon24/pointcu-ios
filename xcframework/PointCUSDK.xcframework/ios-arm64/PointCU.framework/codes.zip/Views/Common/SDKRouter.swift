//
//  Router.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/5/26.
//

import Foundation
import Combine

class SDKRouter: ObservableObject {
    static let shared = SDKRouter()
    
    @Published var activeSheet: SDKRoute? = nil
    @Published var activeFullScreen: SDKRoute? = nil
    
    private init() {}
    
    func presentSheet(_ route: SDKRoute) {
        DispatchQueue.main.async {
            self.activeSheet = route
        }
    }
    
    func presentFullScreen(_ route: SDKRoute) {
        DispatchQueue.main.async {
            // 같은 route를 다시 열 때 SwiftUI가 변경을 감지하도록 nil → route 순서로 설정
            if self.activeFullScreen?.id == route.id {
                self.activeFullScreen = nil
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.activeFullScreen = route
                }
            } else {
                // activeFullScreen이 nil이 아닌데 다른 route면 먼저 닫고 열기
                if self.activeFullScreen != nil {
                    self.activeFullScreen = nil
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.activeFullScreen = route
                    }
                } else {
                    self.activeFullScreen = route
                }
            }
        }
    }
    
    func dismiss() {
        DispatchQueue.main.async {
            self.activeSheet = nil
            self.activeFullScreen = nil
        }
    }
 
    func dismissAndRefresh() {
        DispatchQueue.main.async {
            self.activeSheet = nil
            self.activeFullScreen = nil
            Task { await AppDataManager.shared.refreshMainData() }
        }
    }
}
