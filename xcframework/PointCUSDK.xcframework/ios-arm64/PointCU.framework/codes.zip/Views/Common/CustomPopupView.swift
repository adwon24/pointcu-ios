//
//  CustomPopupView.swift
//  PointCU
//
//  Created by Juno Yoon on 4/18/26.
//

//import UIKit
import SwiftUI

struct CustomPopupView: View {
    @ObservedObject private var manager = OverlayManager.shared
    
    @State private var dynamicTextHeight: CGFloat = 0
    @State private var isDoNotShowAgainChecked: Bool = false
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // 1. 컨텐츠 영역 (타입에 따라 다른 뷰 렌더링)
                switch manager.buttonType {
                case .single, .double:
                    normalTextContent()
                case .extraSingle, .extraDouble:
                    extraTextContent()
                case .reward(let imageName, _, _):
                    rewardContent(imageName: imageName)
                case .inspection:
                    inspectionTextContent()
                case .notification:
                    notificationTextContent()
                case .permission:
                    permissionContent()
                }
                
                // 2. 버튼 영역
                HStack(spacing: 12) {
                    switch manager.buttonType {
                    case .single(let confirmTitle, let confirmAction),
                            .extraSingle(let confirmTitle, let confirmAction),
                            .inspection(let confirmTitle, let confirmAction):
                        confirmButton(title: confirmTitle, action: confirmAction)
                    case .double(let cancelTitle, let confirmTitle, let cancelAction, let confirmAction),
                            .extraDouble(let cancelTitle, let confirmTitle, let cancelAction, let confirmAction),
                            .permission(let cancelTitle, let confirmTitle, let cancelAction, let confirmAction):
                        cancelButton(title: cancelTitle, action: cancelAction)
                        confirmButton(title: confirmTitle, action: confirmAction)
                    case .reward(_, let confirmTitle, let confirmAction):
                        confirmButton(title: confirmTitle, action: confirmAction)
                    case .notification(let confirmTitle, let confirmAction):
                        confirmButton(title: confirmTitle, action: {
                            confirmAction(isDoNotShowAgainChecked)
                        })
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            }
            .background(Color.white)
            .cornerRadius(20)
            .padding(.horizontal, 24)
        }
    }

    @ViewBuilder
    private func normalTextContent() -> some View {
        VStack(spacing: manager.title != nil ? 12 : 0) {
            if let title = manager.title, !title.isEmpty {
                Text(title)
                    .typography(.h4B)
                    .padding(.top, 10)
            }
            
            Text(manager.message)
                .typography(.body1M)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 24)
        .padding(.top, 40)
        .padding(.bottom, 24)
        .frame(minHeight: 140)
    }
    
    @ViewBuilder
    private func extraTextContent() -> some View {
        VStack {
            Text(manager.message)
                .typography(.h4R)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 24)
        .padding(.top, 40)
        .padding(.bottom, 37)
        .frame(minHeight: 60)
    }
    
    @ViewBuilder
    private func rewardContent(imageName: String) -> some View {
        VStack(spacing: 0) {
            Image(imageName, bundle: .pointCU)
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
            Text(manager.message)
                .typography(.h4R)
                .frame(height: 26)
        }
        .padding(.horizontal, 24)
        .padding(.top, 40)
        .padding(.bottom, 20)
    }
    
    @ViewBuilder
    private func inspectionTextContent() -> some View {
        VStack(alignment: .leading, spacing: manager.title != nil ? 16 : 0) {
            if let title = manager.title, !title.isEmpty {
                Text(title)
                    .typography(.h4R, alignment: .leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            
            ScrollView(.vertical, showsIndicators: true) {
                Text(manager.message)
                    .typography(.body2R, alignment: .leading)
                    .lineSpacing(5)
                    .padding(.trailing, 8)
                    .background(
                        GeometryReader { geometry in
                            Color.clear
                                .preference(key: TextHeightPreferenceKey.self, value: geometry.size.height)
                        }
                    )
            }
            .frame(height: dynamicTextHeight == 0 ? 0 : min(dynamicTextHeight, 180))
        }
        .padding(.leading, 24)
        .padding(.trailing, 16)
        .padding(.top, 40)
        .padding(.bottom, 20)
        .onPreferenceChange(TextHeightPreferenceKey.self) { newHeight in
            DispatchQueue.main.async {
                self.dynamicTextHeight = newHeight
            }
        }
    }
    
    @ViewBuilder
    private func permissionContent() -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(Constants.Text.permissionGuideTitle)
                .typography(.h4R, alignment: .leading)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.bottom, 22)

            Text(Constants.Text.permissionMotionTitle)
                .typography(.body1B, alignment: .leading)
                .frame(maxWidth: .infinity, alignment: .leading)
 
            Text(Constants.Text.permissionMotionDesc)
                .typography(.body2R, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
 
            Divider()
                .padding(.vertical, 16)
 
            Text(Constants.Text.permissionMotionGuide)
                .typography(.body2R, color: AppColor.graySummaryText102, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 35)
        .padding(.top, 40)
        .padding(.bottom, 20)
    }
    
    @ViewBuilder
    private func notificationTextContent() -> some View {
        VStack(alignment: .leading, spacing: manager.title != nil ? 16 : 0) {
            if let title = manager.title, !title.isEmpty {
                Text(title)
                    .typography(.h4R, alignment: .leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            
            ScrollView(.vertical, showsIndicators: true) {
                Text(manager.message)
                    .typography(.body2R, alignment: .leading)
                    .lineSpacing(5)
                    .padding(.trailing, 8)
                    .background(
                        GeometryReader { geometry in
                            Color.clear
                                .preference(key: TextHeightPreferenceKey.self, value: geometry.size.height)
                        }
                    )
            }
            .frame(height: dynamicTextHeight == 0 ? 0 : min(dynamicTextHeight, 160))
            
            CheckboxToggleView(isChecked: $isDoNotShowAgainChecked)
                .padding(.top, 20)
                .padding(.bottom, 0)
        }
        .padding(.leading, 24)
        .padding(.trailing, 16)
        .padding(.top, 40)
        .padding(.bottom, 20)
        .onAppear {
            isDoNotShowAgainChecked = false
        }
        .onPreferenceChange(TextHeightPreferenceKey.self) { newHeight in
            DispatchQueue.main.async {
                self.dynamicTextHeight = newHeight
            }
        }
    }
    
    @ViewBuilder
    private func cancelButton(title: String, action: @escaping () -> Void) -> some View {
        Button(action: {
            action()
            manager.hide()
        }) {
            Text(title)
                .typography(.h5B, color: AppColor.grayButtonText68)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(AppColor.grayTextField242)
                .cornerRadius(24)
        }
    }
    
    @ViewBuilder
    private func confirmButton(title: String, action: @escaping () -> Void) -> some View {
        Button(action: {
            action()
            manager.hide()
        }) {
            Text(title)
                .typography(.h5B, color: Color.white)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(AppColor.secondaryGreen)
                .cornerRadius(24)
        }
    }
}

struct TextHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = max(value, nextValue())
    }
}

private struct CheckboxToggleView: View {
    @Binding var isChecked: Bool
    
    var body: some View {
        Button(action: {
            isChecked.toggle()
        }) {
            HStack(spacing: 6) {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(isChecked ? AppColor.secondaryGreen : AppColor.grayTextField170)
                    .font(.system(size: 16))
                Text(Constants.Text.doNotShowToday)
                    .typography(.body1M, color: .black, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}
