//
//  AdPopcornWebAdViewController.swift
//  PointCUSDK
//
//  메인 앱에서 PointCUSDK.startAdvertise() 호출 시 사용
//  애드팝콘 Web SDK (ap-ssp-web-sdk) 기반 300x250 배너 팝업
//  No Ad 시 MobiWith 패스백 자동 처리 (Web SDK 내부 처리)
//
//  메인 앱 필수 설정:
//  - Info.plist NSAllowsArbitraryLoads = true (MobiWith HTTP 허용)
//

import UIKit
import WebKit

final class AdPopcornWebAdViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {

    private let placementId: String
    private let zoneId: String         // MobiWith 패스백용 zone
    private let onComplete: () -> Void
    private let onFail: () -> Void
    private let showToastOnFail: Bool  // 실패 시 토스트 표시 여부 (순환 중에는 false)
    private let onClose: (() -> Void)?

    // 타이틀/서브타이틀 옵션 (nil이면 MobiWith 스타일 헤더 미표시)
    private let adTitle:    String?
    private let adSubTitle: String?

    private var webView: WKWebView!
    private var loadingIndicator: UIActivityIndicatorView!
    private var isCompleted = false
    private var adTimeoutTask: Task<Void, Never>?
    private var safariOpenedAt: Date? = nil          // Safari 이동 시각
    private let requiredSafariDuration: TimeInterval = 5.0  // Safari 5초 이상 → onComplete
    private var indicatorShownAt: Date? = nil
    private let minIndicatorDuration: TimeInterval = 2.0

    // 배너 고정 사이즈
    private let bannerWidth:  CGFloat = 300
    private let bannerHeight: CGFloat = 250
    private let margin:       CGFloat = 16  // 좌우, 하단 마진

    init(
        placementId: String,
        zoneId: String,
        title:    String? = nil,
        subTitle: String? = nil,
        onComplete: @escaping () -> Void,
        onFail: @escaping () -> Void,
        showToastOnFail: Bool = true,
        onClose: (() -> Void)? = nil
    ) {
        self.placementId = placementId
        self.zoneId      = zoneId
        self.adTitle     = title
        self.adSubTitle  = subTitle
        self.onComplete  = onComplete
        self.onFail          = onFail
        self.showToastOnFail = showToastOnFail
        self.onClose         = onClose
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        modalTransitionStyle   = .crossDissolve
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadAd()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleForeground),
            name: UIApplication.willEnterForegroundNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        // retain cycle 해제 — add(self) 했으므로 반드시 remove 필요
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adLoaded")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adClicked")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "adFailed")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "jsLog")
    }

    // MARK: - UI

    private func setupUI() {
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        let containerWidth: CGFloat  = bannerWidth + margin * 2   // 좌우 마진 각 16pt
        let hasHeader = adTitle != nil || adSubTitle != nil
        // 헤더 없음: 닫기버튼(36) + gap(8) + 배너 + 하단마진(16)
        // 헤더 있음: 상단패딩(16) + title(22) + gap(4) + sub(18) + gap(12) + 배너 + 하단마진(16)
        //           닫기 버튼은 헤더 영역 안에 absolute 위치 → 높이에 별도 미포함
        let topHeight: CGFloat = hasHeader ? (16 + 22 + 4 + 18 + 12) : (36 + 8)
        let containerHeight: CGFloat = topHeight + bannerHeight + margin

        let container = UIView()
        container.backgroundColor    = .white
        container.layer.cornerRadius = 16
        container.clipsToBounds      = true
        container.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(container)

        NSLayoutConstraint.activate([
            container.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            container.widthAnchor.constraint(equalToConstant: containerWidth),
            container.heightAnchor.constraint(equalToConstant: containerHeight)
        ])

        // 닫기 버튼
        let closeButton = UIButton(type: .system)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .black
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        container.addSubview(closeButton)

        // 타이틀/서브타이틀 헤더 (옵션)
        var webViewTopAnchor: NSLayoutYAxisAnchor = closeButton.bottomAnchor
        var webViewTopOffset: CGFloat = 8

        if hasHeader {
            let titleLabel = UILabel()
            titleLabel.text          = adTitle ?? ""
            titleLabel.font          = .systemFont(ofSize: 16, weight: .bold)
            titleLabel.textColor     = .black
            titleLabel.textAlignment = .left
            titleLabel.numberOfLines = 1
            titleLabel.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(titleLabel)

            let subLabel = UILabel()
            subLabel.text          = adSubTitle ?? ""
            subLabel.font          = .systemFont(ofSize: 13, weight: .regular)
            subLabel.textColor     = UIColor(red: 102/255, green: 102/255, blue: 102/255, alpha: 1)
            subLabel.textAlignment = .left
            subLabel.numberOfLines = 1
            subLabel.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(subLabel)

            NSLayoutConstraint.activate([
                titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 16),
                titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                titleLabel.trailingAnchor.constraint(equalTo: closeButton.leadingAnchor, constant: -8),
                titleLabel.heightAnchor.constraint(equalToConstant: 22),

                subLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
                subLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                subLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
                subLabel.heightAnchor.constraint(equalToConstant: 18),
            ])

            webViewTopAnchor = subLabel.bottomAnchor
            webViewTopOffset = 12
        }

        // WebView
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.userContentController.add(self, name: "adLoaded")
        config.userContentController.add(self, name: "adClicked")
        config.userContentController.add(self, name: "adFailed")
        config.userContentController.add(self, name: "jsLog")

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate         = self
        webView.uiDelegate                 = self
        webView.scrollView.bounces         = false
        webView.scrollView.isScrollEnabled = false
        webView.backgroundColor            = .white
        webView.layer.cornerRadius         = 12
        webView.layer.borderWidth          = 1
        webView.layer.borderColor          = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1).cgColor
        webView.clipsToBounds              = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(webView)

        loadingIndicator = UIActivityIndicatorView(style: .medium)
        loadingIndicator.color = .gray
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(loadingIndicator)  // webView 다음에 추가 → 최상단에 위치

        NSLayoutConstraint.activate([
            closeButton.topAnchor.constraint(equalTo: container.topAnchor, constant: hasHeader ? 12 : 4),
            closeButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: hasHeader ? -12 : -4),
            closeButton.widthAnchor.constraint(equalToConstant: hasHeader ? 28 : 36),
            closeButton.heightAnchor.constraint(equalToConstant: hasHeader ? 28 : 36),

            webView.topAnchor.constraint(equalTo: webViewTopAnchor, constant: webViewTopOffset),
            webView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: margin),
            webView.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -margin),
            webView.heightAnchor.constraint(equalToConstant: bannerHeight),

            loadingIndicator.centerXAnchor.constraint(equalTo: webView.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: webView.centerYAnchor)
        ])
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        CULog("[WebAd] viewWillAppear | isCompleted=\(isCompleted) placementId=\(placementId)")
        // 매번 표시 시 인디케이터 초기 상태로 리셋
        isCompleted = false
        indicatorShownAt = Date()
        loadingIndicator.isHidden = false
        loadingIndicator.startAnimating()
    }

    // MARK: - 광고 로드

    private func loadAd() {
        indicatorShownAt = Date()
        loadingIndicator.isHidden = false
        loadingIndicator.startAnimating()

        let adId = adIdentifier()

        // 애드팝콘 Web SDK HTML 생성
        let html = buildWebSDKHTML(adId: adId)
        // baseURL 설정: AdPopcorn Web SDK 스크립트 로드를 위해 필요
        webView.loadHTMLString(html, baseURL: URL(string: "https://webapi.adpopcorn.com"))
        CULog("[WebAd] 광고 로드 | placementId=\(placementId)")
    }

    private func buildWebSDKHTML(adId: String) -> String {
        // zoneId가 있으면 No Ad 시 MobiWith 패스백, 없으면 바로 adFailed
        // zoneId가 있으면 No Ad 시 MobiWith 패스백
        // zoneId가 없거나 placementId와 같으면 No Ad 시 adFailed (다음 광고로 순환)
        let hasPassback = !zoneId.isEmpty

        let passbackScript: String
        if hasPassback {
            passbackScript = """
                    const setPassbackBannerAd = (frameId, bannerAdId) => {
                        const frame = document.getElementById(frameId);
                        const bannerAd = document.createElement("iframe");
                        bannerAd.id = bannerAdId;
                        bannerAd.dataset.clicked = "false";
                        Object.assign(bannerAd.style, { border: "none", width: "300px", height: "250px" });
                        bannerAd.src = "https://www.mobwithad.com/api/banner/app/adpopcorn/v2/adpopcorn?zone=\(zoneId)&w=300&h=250&adid=\(adId)";
                        frame.appendChild(bannerAd);
                        bannerAd.addEventListener("load", () => {
                            // cross-origin이라도 load 이벤트는 발생 — adLoaded 전송
                            try {
                                const doc = bannerAd.contentDocument || bannerAd.contentWindow?.document;
                                if (doc && doc.body) doc.body.style.margin = "0";
                            } catch(e) {}
                            window.webkit.messageHandlers.adLoaded.postMessage("loaded");
                            window.addEventListener("blur", () => iframeClickEventHandler(bannerAd));
                            window.focus();
                        });
                        bannerAd.addEventListener("error", () => {
                            window.webkit.messageHandlers.adFailed.postMessage("passback_error");
                        });
                    };
                    const iframeClickEventHandler = (adElement) => {
                        if (!document.activeElement || document.activeElement.tagName !== "IFRAME") return;
                        if (adElement.dataset.clicked === "true") return;
                        if (document.activeElement.id === adElement.id) {
                            adElement.dataset.clicked = "true";
                            window.webkit.messageHandlers.adClicked.postMessage("clicked");
                        }
                        window.addEventListener("visibilitychange", () => { window.focus(); });
                    };
            """
        } else {
            passbackScript = ""
        }

        let noAdAction = hasPassback
            ? "setPassbackBannerAd(bannerAdInventoryFrameId, \"reward-banner-ad-inventory-frame\");"
            : "window.webkit.messageHandlers.adFailed.postMessage(\"failed\");"

        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script async src="https://webapi.adpopcorn.com/ssp/web-sdk/ap-ssp-web-sdk-1.14.1.min.js"></script>
            <script>window.AdPopcornSSPWebSDK = window.AdPopcornSSPWebSDK || { cmd: [] };</script>
            <style>body { margin: 0; padding: 0; overflow: hidden; }</style>
            <script>
                // console.log를 native로 전달 (디버깅용)
                var _origLog = console.log;
                console.log = function() {
                    _origLog.apply(console, arguments);
                    try { window.webkit.messageHandlers.jsLog.postMessage(Array.from(arguments).join(' ')); } catch(e){}
                };
            </script>
        </head>
        <body>
            <div id="adpopcorn-banner-ad-inventory-frame"></div>
            <script>
                let banner300x250;
                AdPopcornSSPWebSDK.cmd.push(() => {
                    AdPopcornSSPWebSDK.init({
                        app_key: "\(Constants.AdPopcorn.appKey)",
                        placement_id: "\(placementId)",
                        log_enabled: false,
                        log_level: 0,
                    });
                    AdPopcornSSPWebSDK.setConfig({ idfa: "\(adId)" });
                });
                AdPopcornSSPWebSDK.cmd.push(() => {
                    const bannerAdInventoryFrameId = "adpopcorn-banner-ad-inventory-frame";
                    banner300x250 = AdPopcornSSPWebSDK.createBannerSize300x250();
                    banner300x250.addEventListener("sdkError", (e) => {
                        var errMsg = JSON.stringify(e) || "sdkError";
                        window.webkit.messageHandlers.adFailed.postMessage("sdkError:" + errMsg);
                    });
                    banner300x250.addEventListener("adInventoryRendered", (e) => {
                        window.webkit.messageHandlers.jsLog.postMessage("adInventoryRendered isNoAd=" + e.isNoAd);
                        if (e.isNoAd) {
                            \(noAdAction)
                        } else {
                            const imgs = document.querySelectorAll("img");
                            if (imgs.length === 0) {
                                window.webkit.messageHandlers.adLoaded.postMessage("loaded"); return;
                            }
                            let loadedCount = 0;
                            const notify = () => { if (++loadedCount >= imgs.length) window.webkit.messageHandlers.adLoaded.postMessage("loaded"); };
                            imgs.forEach(img => { if (img.complete) { notify(); } else { img.addEventListener("load", notify); img.addEventListener("error", notify); } });
                        }
                    });
                    banner300x250.addEventListener("adClicked", (e) => {
                        window.webkit.messageHandlers.adClicked.postMessage("clicked");
                    });
                    banner300x250.display(bannerAdInventoryFrameId);
                });
            </script>
            \(hasPassback ? "<script>\(passbackScript)</script>" : "")
        </body>
        </html>
        """
    }
    
    private func stopIndicatorAfterMinDuration() {
        let elapsed = indicatorShownAt.map { Date().timeIntervalSince($0) } ?? minIndicatorDuration
        let remaining = max(minIndicatorDuration - elapsed, 0)
        DispatchQueue.main.asyncAfter(deadline: .now() + remaining) { [weak self] in
            self?.loadingIndicator.stopAnimating()
        }
    }

    // MARK: - 완료/실패/닫기

    private func handleComplete() {
        guard !isCompleted else { return }
        isCompleted = true
        OverlayManager.shared.hideIndicator()
        dismiss(animated: true) { self.onComplete() }
    }

    private func handleFail() {
        guard !isCompleted else { return }
        CULog("[WebAd] handleFail 호출 | placementId=\(placementId)")
        isCompleted = true
        OverlayManager.shared.hideIndicator()
        adTimeoutTask?.cancel()
        dismiss(animated: true) {
            if self.showToastOnFail {
                OverlayManager.shared.showToast(Constants.Text.noAvailableAdDesc)
            }
            self.onFail()
        }
    }

    private func handleClose() {
        guard !isCompleted else { return }
        isCompleted = true
        OverlayManager.shared.hideIndicator()
        dismiss(animated: true) { self.onClose?() }
    }

    @objc private func closeTapped() { handleClose() }

    @objc private func handleForeground() {
        guard let openedAt = safariOpenedAt else { return }
        let elapsed = Date().timeIntervalSince(openedAt)
        safariOpenedAt = nil
        CULog("[WebAd] Safari 복귀 | 체류: \(String(format: "%.1f", elapsed))초")
        adTimeoutTask?.cancel()
        
        if elapsed >= requiredSafariDuration {
            handleComplete()
        } else {
            OverlayManager.shared.hideIndicator()
            dismiss(animated: true) {
                self.onClose?()
                OverlayManager.shared.showToast(Constants.Text.mustOverFiveSeconds)
            }
        }
    }
}

// MARK: - WKScriptMessageHandler

extension AdPopcornWebAdViewController {
    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        switch message.name {
        case "adLoaded":
            adTimeoutTask?.cancel()
            CULog("[WebAd] 이미지 로드 완료")
            self.stopIndicatorAfterMinDuration()
        case "adFailed":
            adTimeoutTask?.cancel()
            CULog("[WebAd] adFailed 수신 | body=\(message.body)")
            handleFail()
        case "jsLog":
            CULog("[WebAd][JS] \(message.body)")
        case "adClicked":
            CULog("[WebAd] 광고 클릭")
        default:
            break
        }
    }
}

// MARK: - WKNavigationDelegate

extension AdPopcornWebAdViewController {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        CULog("[WebAd] HTML 로드 완료 — adInventoryRendered 대기 중")
        startAdTimeout()
    }

    private func startAdTimeout() {
        adTimeoutTask?.cancel()
        adTimeoutTask = Task { @MainActor [weak self] in
            guard let self = self else { return }
            try? await Task.sleep(nanoseconds: 10_000_000_000)  // 10초
            guard !Task.isCancelled, !self.isCompleted else { return }
            CULog("[WebAd] 타임아웃 → 실패 처리")
            self.handleFail()
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        CULog("[WebAd] didFail: \(error.localizedDescription) code=\((error as NSError).code)")
        handleFail()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        CULog("[WebAd] didFailProvisional: \(error.localizedDescription) code=\((error as NSError).code)")
        handleFail()
    }

    // JS console.log 캡처
    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        CULog("[WebAd][JS Alert] \(message)")
        completionHandler()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow); return
        }
        guard navigationAction.navigationType == .linkActivated else {
            decisionHandler(.allow); return
        }
        decisionHandler(.cancel)
        if UIApplication.shared.canOpenURL(url) {
            safariOpenedAt = Date()
            CULog("[WebAd] Safari 이동 | url=\(url.absoluteString)")
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}

// MARK: - WKUIDelegate

extension AdPopcornWebAdViewController {
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url,
           UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        return nil
    }
}
