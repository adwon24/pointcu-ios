//
//  MobiWithAdViewController.swift
//  PointCUSDK
//
//  모비위드 광고 팝업
//
//  UI (피그마 기준):
//  - 타이틀: "클릭하고 페이지 방문하여 보상 받아요." (볼드)
//  - 서브타이틀: "페이지 5초 이상 머물러야 보상 획득 가능!" (일반)
//  - 닫기 버튼: 우측 상단
//  - 광고 배너: 300×250 WebView, 둥근 모서리
//
//  완료 감지:
//  1. JS postMessage → landingURL 수신
//  2. mobwithad.com 외 URL로 네비게이션 변경
//  3. HTML에 "noad" 포함
//  4. 6초 타임아웃
//

import UIKit
import WebKit

final class MobiWithAdViewController: UIViewController {

    private let zoneId: String
    private let onComplete: () -> Void
    private let onFail: () -> Void
    private let onClose: (() -> Void)?

    private var webView: WKWebView!
    private var loadingIndicator: UIActivityIndicatorView!
    private var timeoutTask: Task<Void, Never>?
    private var isLoading       = false
    private var isAdReady       = false
    private var isCompleted     = false
    private var safariOpenedAt: Date? = nil
    private var indicatorShownAt: Date? = nil         // 인디케이터 표시 시각 (최소 2초 보장)
    private let minIndicatorDuration: TimeInterval = 2.0

    private let baseURL    = "https://www.mobwithad.com"
    private let mediaId    = "adwon"
    private let serviceId  = "adwon"
    private let timeoutSec = 6.0

    // 배너 고정 사이즈
    private let bannerWidth:  CGFloat = 300
    private let bannerHeight: CGFloat = 250
    private let showHeader:   Bool

    init(zoneId: String, showHeader: Bool = true, onComplete: @escaping () -> Void, onFail: @escaping () -> Void, onClose: (() -> Void)? = nil) {
        self.zoneId     = zoneId
        self.showHeader = showHeader
        self.onComplete = onComplete
        self.onFail     = onFail
        self.onClose    = onClose
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .overFullScreen
        modalTransitionStyle   = .crossDissolve
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // 팝업 표시 즉시 indicator 시작 — 이미지 로드 완료 시까지 유지 (최소 2초)
        indicatorShownAt = Date()
        loadingIndicator.isHidden = false
        loadingIndicator.startAnimating()
        loadAd()
        NotificationCenter.default.addObserver(self, selector: #selector(handleForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        timeoutTask?.cancel()
        NotificationCenter.default.removeObserver(self)
    }

    @objc private func handleForeground() {
        guard let openedAt = safariOpenedAt else { return }
        let elapsed = Date().timeIntervalSince(openedAt)
        safariOpenedAt = nil
        CULog("[MobiWith] Safari 복귀 | 체류: \(String(format: "%.1f", elapsed))초")

        if elapsed >= 5.0 {
            handleComplete()
        } else {
            CULog("[MobiWith] 5초 미만 복귀 → 광고 미완료")
            guard !isCompleted else { return }
            isCompleted = true
            isLoading   = false
            timeoutTask?.cancel()
            OverlayManager.shared.hideIndicator()
            presentingViewController?.dismiss(animated: true) {
                self.onClose?()
                OverlayManager.shared.showToast(Constants.Text.mustOverFiveSeconds)
            }
        }
    }

    // MARK: - UI 설정

    private func setupUI() {
        // 반투명 딤 배경
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)

        // 컨테이너 카드
        let containerWidth: CGFloat  = bannerWidth + 32
        // showHeader: 상단패딩(16)+타이틀(22)+서브(22)+간격(12)+배너+하단패딩(16)
        // no header: 닫기버튼(36)+gap(8)+배너+하단패딩(16)
        let containerHeight: CGFloat = showHeader
            ? (16 + 22 + 4 + 18 + 12 + bannerHeight + 16)
            : (36 + 8 + bannerHeight + 16)

        let container = UIView()
        container.backgroundColor    = .white
        container.layer.cornerRadius = 16
        container.clipsToBounds      = true
        container.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(container)

        NSLayoutConstraint.activate([
            container.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            container.widthAnchor.constraint(equalToConstant: containerWidth),
            container.heightAnchor.constraint(equalToConstant: containerHeight)
        ])

        // 닫기 버튼
        let closeButton = UIButton(type: .system)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .black
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        container.addSubview(closeButton)

        // 타이틀
        let titleLabel = UILabel()
        titleLabel.text          = Constants.Text.showAdForReward
        titleLabel.font          = .systemFont(ofSize: 16, weight: .bold)
        titleLabel.textColor     = .black
        titleLabel.textAlignment = .left
        titleLabel.numberOfLines = 1
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(titleLabel)

        // 서브타이틀
        let subLabel = UILabel()
        subLabel.text          = Constants.Text.mustOverFiveSeconds
        subLabel.font          = .systemFont(ofSize: 13, weight: .regular)
        subLabel.textColor     = UIColor(red: 102/255, green: 102/255, blue: 102/255, alpha: 1)
        subLabel.textAlignment = .left
        subLabel.numberOfLines = 1
        subLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(subLabel)

        // WebView (300×250)
        let config = WKWebViewConfiguration()
        config.userContentController.add(self, name: "mobwithBridge")
        config.allowsInlineMediaPlayback = true
        // 외부 스크립트(img.mobwithad.com CDN) 로드 허용
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        if #available(iOS 14.0, *) {
            config.defaultWebpagePreferences.allowsContentJavaScript = true
        }

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate         = self
        webView.uiDelegate                 = self
        webView.scrollView.bounces                    = false
        webView.scrollView.isScrollEnabled            = false
        webView.scrollView.minimumZoomScale           = 1.0
        webView.scrollView.maximumZoomScale           = 1.0
        webView.scrollView.zoomScale                  = 1.0
        webView.backgroundColor            = .white
        webView.layer.cornerRadius         = 12
        webView.layer.borderWidth          = 1
        webView.layer.borderColor          = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1).cgColor
        webView.clipsToBounds              = true
        webView.isUserInteractionEnabled   = false  // 로드 완료 전 터치 차단
        webView.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(webView)

        // 로딩 인디케이터
        loadingIndicator = UIActivityIndicatorView(style: .medium)
        loadingIndicator.color = .gray
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(loadingIndicator)

        if showHeader {
            // 헤더 있음 — 타이틀 + 서브타이틀 표시
            NSLayoutConstraint.activate([
                closeButton.topAnchor.constraint(equalTo: container.topAnchor, constant: 12),
                closeButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -12),
                closeButton.widthAnchor.constraint(equalToConstant: 28),
                closeButton.heightAnchor.constraint(equalToConstant: 28),

                titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 16),
                titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                titleLabel.trailingAnchor.constraint(equalTo: closeButton.leadingAnchor, constant: -8),
                titleLabel.heightAnchor.constraint(equalToConstant: 22),

                subLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
                subLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
                subLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
                subLabel.heightAnchor.constraint(equalToConstant: 18),

                webView.topAnchor.constraint(equalTo: subLabel.bottomAnchor, constant: 12),
                webView.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                webView.widthAnchor.constraint(equalToConstant: bannerWidth),
                webView.heightAnchor.constraint(equalToConstant: bannerHeight),

                loadingIndicator.centerXAnchor.constraint(equalTo: webView.centerXAnchor),
                loadingIndicator.centerYAnchor.constraint(equalTo: webView.centerYAnchor)
            ])
        } else {
            // 헤더 없음 — X 버튼만, 배너 바로 아래
            titleLabel.isHidden = true
            subLabel.isHidden   = true
            NSLayoutConstraint.activate([
                closeButton.topAnchor.constraint(equalTo: container.topAnchor, constant: 4),
                closeButton.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -4),
                closeButton.widthAnchor.constraint(equalToConstant: 36),
                closeButton.heightAnchor.constraint(equalToConstant: 36),

                webView.topAnchor.constraint(equalTo: closeButton.bottomAnchor, constant: 8),
                webView.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                webView.widthAnchor.constraint(equalToConstant: bannerWidth),
                webView.heightAnchor.constraint(equalToConstant: bannerHeight),

                loadingIndicator.centerXAnchor.constraint(equalTo: webView.centerXAnchor),
                loadingIndicator.centerYAnchor.constraint(equalTo: webView.centerYAnchor)
            ])
        }
    }

    // MARK: - 광고 로드 (300×250 고정)

    private func loadAd() {
        let idfv = adIdentifier()  // IDFA 우선, 없으면 IDFV
        let urlString = "\(baseURL)/api/banner/app/\(mediaId)/v2/\(serviceId)"
            + "?zone=\(zoneId)"
            + "&output=html"
            + "&os_type=ios"
            + "&w=300&h=250"
            + "&adid=\(idfv)"
            + "&userAdTrackingYn=Y"

        CULog("[MobiWith] 광고 로드 | zone=\(zoneId)")

        guard let url = URL(string: urlString) else { handleFail(); return }

        isLoading = true
        // baseURL을 MobiWith 도메인으로 설정하여 JS CORS 허용
        webView.load(URLRequest(url: url))

        timeoutTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: UInt64(timeoutSec * 1_000_000_000))
            guard !Task.isCancelled, isLoading else { return }
            CULog("[MobiWith] 타임아웃 → 실패")
            handleFail()
        }
    }

    // MARK: - 완료/실패

    private func handleComplete() {
        guard !isCompleted else { return }
        isCompleted = true
        isLoading   = false
        timeoutTask?.cancel()
//        CULog("[MobiWith] 완료")
        OverlayManager.shared.hideIndicator()
        presentingViewController?.dismiss(animated: true) { self.onComplete() }
    }

    private func handleFail() {
        guard !isCompleted else { return }
        isCompleted = true
        isLoading   = false
        timeoutTask?.cancel()
        CULog("[MobiWith] 실패")
        OverlayManager.shared.hideIndicator()
        presentingViewController?.dismiss(animated: true) {
            OverlayManager.shared.showToast(Constants.Text.noAvailableAdDesc)
            self.onFail()
        }
    }

    @objc private func closeTapped() { handleClose() }

    /// 닫기 버튼 — 광고 미시청으로 처리, onClose 콜백 호출
    private func handleClose() {
        guard !isCompleted else { return }
        isCompleted = true
        isLoading   = false
        timeoutTask?.cancel()
        OverlayManager.shared.hideIndicator()
        presentingViewController?.dismiss(animated: true) { self.onClose?() }
    }
}

// MARK: - WKNavigationDelegate

extension MobiWithAdViewController: WKNavigationDelegate {

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        let urlStr = url.absoluteString

        // about:blank → 허용
        if urlStr == "about:blank" {
            decisionHandler(.allow)
            return
        }

        // mobwithad.com 도메인 내부 요청 → 허용
        if urlStr.contains("mobwithad.com") {
            decisionHandler(.allow)
            return
        }

        // 사용자가 직접 링크를 클릭한 경우에만 Safari로 이동
        // .linkActivated 외 나머지(리소스 로드, iframe 등)는 허용
        guard navigationAction.navigationType == .linkActivated else {
            decisionHandler(.allow)
            return
        }

        // isAdReady 전이면 차단
        guard isAdReady else {
            decisionHandler(.cancel)
            return
        }

        // 사용자 클릭 → Safari로 열고 완료 처리
        CULog("[MobiWith] 광고 클릭 → Safari: \(urlStr)")
        decisionHandler(.cancel)

        if UIApplication.shared.canOpenURL(url) {
            safariOpenedAt = Date()
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            handleFail()
        }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoading = false

        webView.evaluateJavaScript("document.body.innerHTML") { [weak self] result, _ in
            guard let self = self, !self.isCompleted else { return }
            let html = result as? String ?? ""

//            CULog("[MobiWith] HTML 길이=\(html.count) 앞200=\(String(html.prefix(200)))")

            if html.contains("noad") || html.contains("no ad") || html.isEmpty {
                CULog("[MobiWith] noad 감지 → 실패")
                self.handleFail()
                return
            }

            CULog("[MobiWith] HTML 로드 완료 → 렌더링 대기 중...")
            self.waitForRenderComplete()
        }
    }

    /// didFinish 후 렌더링 완료 감지
    /// 0.5초마다 스냅샷 하단 10% 영역을 크롭해 픽셀 변화율 비교
    /// 변화율 5% 이상 감지 시 렌더링 완료로 판단
    private func waitForRenderComplete(attempt: Int = 0, previousSnapshot: UIImage? = nil) {
        let maxAttempts    = 90    // 최대 45초 (0.5초 × 90)
        let threshold      = 5.0   // 픽셀 변화율 임계값 (%)
        let checkAreaRatio = 0.1   // 하단 10% 영역 체크
        let widthRatio     = 0.8   // 좌우 80% 체크

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self = self, !self.isCompleted else { return }

            let config = WKSnapshotConfiguration()
            config.rect = CGRect(origin: .zero, size: self.webView.bounds.size)

            self.webView.takeSnapshot(with: config) { [weak self] image, error in
                guard let self = self, !self.isCompleted else { return }

                guard let image else {
                    if attempt < maxAttempts {
                        self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: previousSnapshot)
                    } else { self.handleFail() }
                    return
                    }

                // 첫 프레임 — 기준으로만 저장
                guard let prev = previousSnapshot else {
                    self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: image)
                    return
                }

                // 하단 10%, 좌우 80% 크롭
                let cropped     = self.cropTargetArea(image, areaRatio: checkAreaRatio, widthRatio: widthRatio)
                let croppedPrev = self.cropTargetArea(prev,  areaRatio: checkAreaRatio, widthRatio: widthRatio)

                let diff = self.calculateDiff(old: croppedPrev, new: cropped)
//                CULog("[MobiWith] 스냅샷 attempt=\(attempt) diff=\(String(format: "%.1f", diff))%")

                if diff >= threshold {
//                    CULog("[MobiWith] 렌더링 완료 (diff=\(String(format: "%.1f", diff))%)")
                    self.activateAd()
                } else if attempt < maxAttempts {
                    self.waitForRenderComplete(attempt: attempt + 1, previousSnapshot: image)
                } else {
                    CULog("[MobiWith] 렌더링 체크 타임아웃")
                    self.activateAd()
                }
            }
        }
    }

    /// 하단 areaRatio%, 중앙 widthRatio% 영역 크롭
    private func cropTargetArea(_ image: UIImage, areaRatio: Double, widthRatio: Double) -> UIImage {
        guard let cgImage = image.cgImage else { return image }
        let w = CGFloat(cgImage.width)
        let h = CGFloat(cgImage.height)

        let cropH = max(h * CGFloat(areaRatio), 1)
        let cropW = max(w * CGFloat(widthRatio), 1)
        let cropX = (w - cropW) / 2
        let cropY = h - cropH

        guard let cropped = cgImage.cropping(to: CGRect(x: cropX, y: cropY, width: cropW, height: cropH)) else {
            return image
        }
        return UIImage(cgImage: cropped)
    }

    /// 픽셀 변화율 계산 — 8픽셀 간격 샘플링 (안드로이드 calculateDiff 동일)
    private func calculateDiff(old: UIImage, new: UIImage) -> Double {
        guard let oldCG = old.cgImage, let newCG = new.cgImage else { return 0 }

        let width  = min(oldCG.width, newCG.width)
        let height = min(oldCG.height, newCG.height)
        guard width > 0, height > 0 else { return 0 }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let bytesPerPixel = 4
        let bytesPerRow   = bytesPerPixel * width

        var oldPixels = [UInt8](repeating: 0, count: height * bytesPerRow)
        var newPixels = [UInt8](repeating: 0, count: height * bytesPerRow)

        guard let oldCtx = CGContext(data: &oldPixels, width: width, height: height,
                                     bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                     space: colorSpace, bitmapInfo: bitmapInfo.rawValue),
              let newCtx = CGContext(data: &newPixels, width: width, height: height,
                                     bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                     space: colorSpace, bitmapInfo: bitmapInfo.rawValue)
        else { return 0 }

        oldCtx.draw(oldCG, in: CGRect(x: 0, y: 0, width: width, height: height))
        newCtx.draw(newCG, in: CGRect(x: 0, y: 0, width: width, height: height))

        var changed = 0
        var total   = 0
        let step    = 8  // 8픽셀 간격 샘플링

        for x in stride(from: 0, to: width, by: step) {
            for y in stride(from: 0, to: height, by: step) {
                let idx = y * bytesPerRow + x * bytesPerPixel
                if oldPixels[idx]   != newPixels[idx]   ||
                   oldPixels[idx+1] != newPixels[idx+1] ||
                   oldPixels[idx+2] != newPixels[idx+2] {
                    changed += 1
                }
                total += 1
            }
        }

        return total > 0 ? Double(changed) / Double(total) * 100.0 : 0
    }

    private func stopIndicatorAfterMinDuration() {
        let elapsed = indicatorShownAt.map { Date().timeIntervalSince($0) } ?? minIndicatorDuration
        let remaining = max(minIndicatorDuration - elapsed, 0)
        DispatchQueue.main.asyncAfter(deadline: .now() + remaining) { [weak self] in
            self?.loadingIndicator.stopAnimating()
        }
    }

    private func activateAd() {
        isAdReady = true
        stopIndicatorAfterMinDuration()
        webView.isUserInteractionEnabled = true
        CULog("[MobiWith] 광고 활성화 완료")
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        CULog("[MobiWith] didFail: \(error.localizedDescription) code=\((error as NSError).code)")
        handleFail()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        CULog("[MobiWith] didFailProvisional: \(error.localizedDescription) code=\((error as NSError).code)")
        handleFail()
    }
}

// MARK: - WKUIDelegate (window.open 등 팝업 네비게이션 처리)

extension MobiWithAdViewController: WKUIDelegate {
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard isAdReady, let url = navigationAction.request.url else { return nil }
        let urlStr = url.absoluteString
        if urlStr != "about:blank", !urlStr.contains("mobwithad.com") {
            CULog("[MobiWith] window.open → Safari: \(urlStr)")
            safariOpenedAt = Date()
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        return nil
    }
}

// MARK: - WKScriptMessageHandler

extension MobiWithAdViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController,
                                didReceive message: WKScriptMessage) {
        guard message.name == "mobwithBridge",
              let body = message.body as? String,
              let data = body.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let detail = json["detail"] as? [String: Any],
              detail["landingURL"] is String else { return }
        CULog("[MobiWith] postMessage → 완료")
        handleComplete()
    }
}
