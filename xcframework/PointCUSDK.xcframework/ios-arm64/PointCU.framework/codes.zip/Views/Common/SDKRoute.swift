//
//  SDKRoute.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/5/26.
//

import SwiftUI
 
enum SDKRoute: Identifiable {
    case statistics
    case guide
    case faq
    case stepMissionGame
    case rouletteGame(benefit: BenefitItem)  // 룰렛 게임
    case lotteryGame(benefit: BenefitItem)   // 복권 게임

    var id: String {
        switch self {
        case .statistics:       return "statistics"
        case .guide:            return "guide"
        case .faq:              return "faq"
        case .stepMissionGame:  return "stepMissionGame"
        case .rouletteGame(let benefit): return "rouletteGame_\(benefit.id)"
        case .lotteryGame(let benefit):  return "lotteryGame_\(benefit.id)"
        }
    }

    @ViewBuilder
    var destination: some View {
        switch self {
        case .statistics:
            NavigationView {
                StepStatisticsView()
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()
        case .guide:
            NavigationView {
                ServiceGuideView()
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()
        case .faq:
            NavigationView {
                FAQView()
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()
        case .stepMissionGame:
            NavigationView {
                StepMissionGameView()
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()
        case .rouletteGame(let benefit):
            NavigationView {
                RouletteGameView(benefit: benefit)
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()

        case .lotteryGame(let benefit):
            NavigationView {
                LotteryGameView(benefit: benefit)
            }
            .navigationViewStyle(.stack)
            .useGlobalPopup()
            .useGlobalIndicator()
        }
    }
}
