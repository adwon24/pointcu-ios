//
//  CustomToggleStyle.swift
//  PointCU
//
//  Created by Juno Yoon on 4/18/26.
//

import SwiftUI

struct CustomToggleStyle: ToggleStyle {
    let width: CGFloat
    let height: CGFloat
    
    // 내부 디자인 상수
    private let circlePadding: CGFloat = 2
    
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            RoundedRectangle(cornerRadius: height / 2)
                .fill(configuration.isOn ? AppColor.secondaryGreen : AppColor.grayDisalbeBg221)
                .frame(width: width, height: height)
                .overlay(
                    Circle()
                        .fill(Color.white)
                        .padding(circlePadding)
                        .offset(x: configuration.isOn ? (width - height) / 2 : -(width - height) / 2)
                )
                .onTapGesture {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                        configuration.isOn.toggle()
                    }
                }
        }
    }
}
