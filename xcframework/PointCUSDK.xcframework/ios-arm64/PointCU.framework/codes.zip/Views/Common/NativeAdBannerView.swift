//
//  NativeAdBannerView.swift
//  PointCUSDK
//
//  애드팝콘 NAM 미디에이션 네이티브 배너
//  - UIViewRepresentable 기반 (UIViewControllerRepresentable 제거)
//  - GFPNativeSimpleAdView, APNAMNativeAdRenderer 런타임 동적 접근
//
//  메인 앱 필수 설정:
//  1. NAM SDK — CocoaPods: pod 'NAMSDK', '8.15.0' + pod 'NAMSDK/MediationNDA'
//  2. NAMAdapter.h/.m 수동 추가 → Bridge Header에 #import "NAMAdapter.h"
//  3. AppDelegate에서 GFPAdManager.setup(withPublisherCd: "N256497692", ...) 초기화
//  4. GFPNativeSimpleAdView.xib 프로젝트에 추가
//  5. Info.plist NSAllowsArbitraryLoads = true
//

import SwiftUI
import AdPopcornSSP

// MARK: - SwiftUI 래퍼

struct NativeAdBannerView: View {
    let placement: AdsPlacementType
    var externalLoaded:  Binding<Bool?>? = nil   // 외부 로드 상태 관찰
    var externalHeight:  Binding<CGFloat>? = nil // 외부 실제 높이 전달
    var containerWidth:  CGFloat? = nil          // 실제 배너 가로 폭
    var containerHeight: CGFloat? = nil          // 컨테이너 높이 (센터 정렬용)

    @State private var internalLoaded: Bool? = nil
    @State private var internalHeight: CGFloat = 0

    private var adLoaded: Binding<Bool?> {
        externalLoaded ?? $internalLoaded
    }

    private var adHeight: Binding<CGFloat> {
        externalHeight ?? $internalHeight
    }

    private var targetWidth: CGFloat {
        containerWidth ?? UIScreen.main.bounds.width
    }

    var body: some View {
        Group {
            if adLoaded.wrappedValue != false {
                NativeAdBannerUIView(
                    placement:       placement,
                    adLoaded:        adLoaded,
                    adHeight:        adHeight,
                    containerWidth:  targetWidth,
                    containerHeight: containerHeight ?? adHeight.wrappedValue
                )
                .frame(width:  targetWidth,
                       height: adLoaded.wrappedValue == true
                           ? max(containerHeight ?? adHeight.wrappedValue, 1)
                           : 1)
                .opacity(adLoaded.wrappedValue == true ? 1 : 0)
            }
        }
    }
}

// MARK: - UIViewRepresentable

struct NativeAdBannerUIView: UIViewRepresentable {
    let placement:       AdsPlacementType
    @Binding var adLoaded: Bool?
    @Binding var adHeight: CGFloat
    let containerWidth:  CGFloat
    let containerHeight: CGFloat

    func makeCoordinator() -> Coordinator {
        Coordinator(adLoaded: $adLoaded, adHeight: $adHeight)
    }

    func makeUIView(context: Context) -> NativeAdContainerView {
        let view = NativeAdContainerView(frame: CGRect(x: 0, y: 0, width: containerWidth, height: containerHeight))
        view.coordinator = context.coordinator
        view.containerWidth  = containerWidth
        view.containerHeight = containerHeight

        let placementId = MediationManager.shared
            .ads(for: placement.rawValue)
            .first?.adKey ?? ""

        guard !placementId.isEmpty else {
            CULog("[NativeAd] placementId 없음 | placement=\(placement.rawValue)")
            DispatchQueue.main.async { self.adLoaded = false }
            return view
        }

        view.setupAd(placementId: placementId)
        return view
    }

    func updateUIView(_ uiView: NativeAdContainerView, context: Context) {
        // containerHeight가 변경되면 UIView에 반영
        if uiView.containerHeight != containerHeight {
            uiView.containerHeight = containerHeight
            uiView.setNeedsLayout()
            uiView.layoutIfNeeded()
        }
    }

    // MARK: - Coordinator

    class Coordinator {
        @Binding var adLoaded: Bool?
        @Binding var adHeight: CGFloat

        init(adLoaded: Binding<Bool?>, adHeight: Binding<CGFloat>) {
            _adLoaded = adLoaded
            _adHeight = adHeight
        }
    }
}

// MARK: - UIView 컨테이너

class NativeAdContainerView: UIView {
    var coordinator: NativeAdBannerUIView.Coordinator?
    var containerWidth:  CGFloat = UIScreen.main.bounds.width
    var containerHeight: CGFloat = 80

    private var nativeAd: AdPopcornSSPNativeAd?
    private var namSuperView: UIView = UIView()
    private var namSimpleAdView: AnyObject?
    private var namRenderer: AnyObject?
    private var namWidth:  CGFloat = 320
    private var namHeight: CGFloat = 68

    private var pendingPlacementId: String?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        clipsToBounds = false
        namSuperView.backgroundColor = .clear
        namSuperView.clipsToBounds = false
        addSubview(namSuperView)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil, let placementId = pendingPlacementId else { return }
        pendingPlacementId = nil
        waitAndLoadAd(placementId: placementId)
    }

    private func waitAndLoadAd(placementId: String, attempt: Int = 0) {
        // MediationManager 준비 완료 후 NAM 배너 로드
        // 최대 3초(30 × 0.1초) 대기
        if MediationManager.shared.isReady {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self, self.window != nil else { return }
                self.loadAd(placementId: placementId)
            }
        } else if attempt < 30 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                self?.waitAndLoadAd(placementId: placementId, attempt: attempt + 1)
            }
        } else {
            CULog("[NativeAd] MediationManager 준비 타임아웃 — 로드 스킵")
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard namWidth > 0, namHeight > 0 else { return }

        // 컨테이너 폭에 맞게 스케일
        let targetW = containerWidth > 0 ? containerWidth : bounds.width
        let scaledH = ceil(targetW * namHeight / namWidth)

        // 컨테이너 높이 기준 세로 가운데 정렬
        // bounds.height = SwiftUI frame(height:)으로 지정된 컨테이너 높이
        // containerHeight 우선, 없으면 bounds.height
        let containerH = containerHeight > 0 ? containerHeight : (bounds.height > 0 ? bounds.height : scaledH)
        let offsetY = max((containerH - scaledH) / 2, 0)

        namSuperView.frame = CGRect(x: 0, y: offsetY, width: targetW, height: scaledH)
        if let sv = namSimpleAdView as? UIView {
            sv.frame = CGRect(x: 0, y: 0, width: targetW, height: scaledH)
        }
    }

    func setupAd(placementId: String) {
        if window != nil {
            loadAd(placementId: placementId)
        } else {
            pendingPlacementId = placementId
        }
    }

    private func loadAd(placementId: String) {
        let w = containerWidth > 0 ? containerWidth : UIScreen.main.bounds.width
        // 320×68 비율 기준 스케일 높이 (NAM이 이 크기로 렌더링)
        let h = ceil(w * 68 / 320)

        // GFPNativeSimpleAdView — 런타임 동적 생성
        guard NSClassFromString("GFPNativeSimpleAdView") != nil,
              let simpleView = Bundle.main.loadNibNamed(
                  "GFPNativeSimpleAdView", owner: nil, options: nil
              )?.first as? UIView else {
            CULog("[NativeAd] GFPNativeSimpleAdView 로드 실패")
            DispatchQueue.main.async { self.coordinator?.adLoaded = false }
            return
        }
        simpleView.frame = CGRect(x: 0, y: 0, width: w, height: h)
        simpleView.clipsToBounds = false  // AD 마크 영역 밖 허용
        namSimpleAdView = simpleView
        namSuperView.addSubview(simpleView)

        // APNAMNativeAdRenderer — 런타임 동적 생성
        guard let rendererClass = NSClassFromString("APNAMNativeAdRenderer") as? NSObject.Type else {
            CULog("[NativeAd] APNAMNativeAdRenderer 로드 실패")
            DispatchQueue.main.async { self.coordinator?.adLoaded = false }
            return
        }
        let renderer = rendererClass.init()
        renderer.setValue(simpleView,   forKey: "namNativeSimpleAdView")
        renderer.setValue(namSuperView, forKey: "namNativeSuperView")
        namRenderer = renderer

        // AdPopcornSSPNativeAd 생성
        guard let vc = findViewController() else {
            CULog("[NativeAd] ViewController를 찾을 수 없음")
            DispatchQueue.main.async { self.coordinator?.adLoaded = false }
            return
        }

        nativeAd = AdPopcornSSPNativeAd()
        nativeAd?.setPlacementInfoWithAppKey(
            Constants.AdPopcorn.appKey,
            placementId: placementId,
            viewController: vc
        )
        nativeAd?.delegate = self

        let selector = NSSelectorFromString("setNAMRenderer:superView:")
        if nativeAd?.responds(to: selector) == true {
            nativeAd?.perform(selector, with: renderer, with: namSuperView)
        }

        // GFPNativeSimpleAdView는 별도 delegate 설정 없음
        // didChangeMediaViewSize는 APNAMNativeAdRenderer 내부에서 처리됨

        nativeAd?.loadRequest()
        CULog("[NativeAd] loadRequest | placementId=\(placementId)")
    }

    private func findViewController() -> UIViewController? {
        UIApplication.shared.topViewController()
    }

    @objc func didChangeMediaViewSize(_ width: CGFloat, height: CGFloat) {
        CULog("[NativeAd] NAM 반환 크기: \(width) x \(height)")
        guard width > 0, height > 0 else { return }

        namWidth  = width
        namHeight = height  // NAM이 반환한 실제 높이 그대로 사용

        DispatchQueue.main.async {
            self.coordinator?.adHeight = height
            self.setNeedsLayout()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                self.coordinator?.adLoaded = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                    self.setNeedsLayout()
                    self.layoutIfNeeded()
                }
            }
        }
    }
}

// MARK: - APSSPNativeAdDelegate

extension NativeAdContainerView: APSSPNativeAdDelegate {
    func apsspNativeAdLoadSuccess(_ nativeAd: AdPopcornSSPNativeAd!) {
        CULog("[NativeAd] 로드 성공 — didChangeMediaViewSize 콜백에서 adLoaded 설정 예정")
        // adLoaded는 didChangeMediaViewSize 콜백에서 adHeight 설정 후 처리
        // NAM이 사이즈 콜백을 주지 않을 경우를 위한 fallback
        let w = containerWidth > 0 ? containerWidth : UIScreen.main.bounds.width
        let fallbackH = ceil(w * 68 / 320)
        CULog("[NativeAd] fallbackHeight: \(fallbackH)")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if self.coordinator?.adLoaded != true {
                // didChangeMediaViewSize가 호출됐으면 namHeight 사용, 아니면 비율 계산값 사용
                let h = self.namHeight > 0 ? self.namHeight : fallbackH
                CULog("[NativeAd] fallback adHeight=\(h)")
                self.coordinator?.adHeight = h
                self.coordinator?.adLoaded = true
            }
        }
    }

    func apsspNativeAdLoadFail(_ nativeAd: AdPopcornSSPNativeAd!, error: AdPopcornSSPError!) {
        CULog("[NativeAd] 로드 실패: \(error?.description ?? "unknown")")
        DispatchQueue.main.async { self.coordinator?.adLoaded = false }
    }

    func apsspNativeAdImpression(_ nativeAd: AdPopcornSSPNativeAd!) {
        CULog("[NativeAd] 노출")
    }

    func apsspNativeAdClicked(_ nativeAd: AdPopcornSSPNativeAd!) {
        CULog("[NativeAd] 클릭")
    }

    // APSSPNativeAdDelegate 원본 스펠링 (Hidden → Hiden) — SDK 오타이므로 변경 불가
    func apsspNativeAdHiden(_ nativeAd: AdPopcornSSPNativeAd!) {
        CULog("[NativeAd] 닫힘")
    }
}
