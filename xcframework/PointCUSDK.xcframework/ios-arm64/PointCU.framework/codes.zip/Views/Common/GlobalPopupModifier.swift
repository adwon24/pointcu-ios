//
//  GlobalPopupModifier.swift
//  PointCU
//
//  Created by Juno Yoon on 4/20/26.
//

import SwiftUI

struct GlobalPopupModifier: ViewModifier {
    @ObservedObject private var overlayManger = OverlayManager.shared

    func body(content: Content) -> some View {
        ZStack {
            content
            // 팝업
            if overlayManger.isShowing {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                CustomPopupView()
                    .transition(.opacity.combined(with: .scale(scale: 0.95)))
                    .zIndex(1)
            }

            // 화면 중앙 메시지 (광고 로딩 대기 등 — 인디케이터와 별개)
            if let centerMsg = overlayManger.centerMessage {
                Text(centerMsg)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 18)
                    .background(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(red: 34/255, green: 34/255, blue: 34/255).opacity(0.9))
                    )
                    .transition(.opacity)
                    .zIndex(1.5)  // 팝업(1)보다 위, 인디케이터(2)보다 아래
            }

        }
        .customToast(
            isPresented: Binding(
                get: { overlayManger.toastMessage != nil },
                set: { if !$0 { overlayManger.toastMessage = nil } }
            ),
            message: overlayManger.toastMessage ?? ""
        )
    }
}
