//
//  CustomNavigationBar.swift
//  PointCU
//
//  Created by Juno Yoon on 4/21/26.
//

import SwiftUI

struct CustomNavigationBar<TrailingContent: View>: View {
    let title: String
    let backAction: (() -> Void)?
    let trailingContent: TrailingContent
    
    @Environment(\.dismiss) private var dismiss
    
    init(
        title: String,
        backAction: (() -> Void)? = nil,
        @ViewBuilder trailingContent: () -> TrailingContent
    ) {
        self.title = title
        self.backAction = backAction
        self.trailingContent = trailingContent()
    }
    
    var body: some View {
        HStack(spacing: 6) {
            // 좌측 뒤로가기 버튼
            Button(action: {
                if let backAction = backAction {
                    backAction()
                } else {
                    dismiss()
                }
            }) {
                Image(Constants.ImageName.back, bundle: .pointCU)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 32, height: 32)
            }
            
            // 중앙(좌측 정렬) 타이틀
            Text(title)
                .typography(.robotoH5B)
                .frame(height: 32)
            
            Spacer()
            
            // 우측 옵션 뷰
            trailingContent
        }
        .padding(.leading, 10)
        .padding(.trailing, 16)
        .frame(height: 56)
        .frame(maxWidth: .infinity, alignment: .center)
        .background(Color.white)
    }
}

// MARK: - 우측 버튼이 필요 없는 경우를 위한 Convenience Init
extension CustomNavigationBar where TrailingContent == EmptyView {
    init(title: String, backAction: (() -> Void)? = nil) {
        self.init(title: title, backAction: backAction) {
            EmptyView()
        }
    }
}
