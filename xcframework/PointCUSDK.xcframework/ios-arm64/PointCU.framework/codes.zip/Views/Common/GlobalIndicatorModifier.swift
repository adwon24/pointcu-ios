//
//  GlobalIndicatorModifier.swift
//  PointCU
//
//  Created by Juno Yoon on 4/29/26.
//


import SwiftUI
 
struct GlobalIndicatorModifier: ViewModifier {
    @ObservedObject private var overlayManager = OverlayManager.shared
 
    func body(content: Content) -> some View {
        ZStack {
            content
 
            if overlayManager.isIndicating {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                 ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    .scaleEffect(1.5)
                    .zIndex(2)
            }
        }
        .animation(.easeInOut(duration: 0.2), value: overlayManager.isIndicating)
    }
}
