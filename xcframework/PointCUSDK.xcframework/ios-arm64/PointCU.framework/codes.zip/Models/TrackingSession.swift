//
//  TrackingSession.swift
//  PointCU
//
//  Created by Juno Yoon on 4/19/26.
//
import SwiftUI

struct TrackingSession: Codable {
    var start: Date
    var end: Date?
    var steps: Int?
}
