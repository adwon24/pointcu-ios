//
//  UiOrderCode.swift
//  PointCU
//
//  Created by Juno Yoon on 4/22/26.
//
//  Android AdsPlacementType / UiOrderCode 기준으로 코드값 정렬
//

import Foundation

// MARK: - UI 배너 영역 코드

enum UiOrderCode: String, Codable, CaseIterable {

    // 오퍼월
    case offerwallAdForusAPI   = "D0000215"  // Adforus API
    case offerwallNStationAPI  = "D0000216"  // NStation API
    case offerwallMotto        = "D0000217"  // 모또
    case offerwallMocation     = "D0000218"  // 모테이션
    case offerwallAdForusSDK   = "D0000256"  // Adforus SDK
    case offerwallNStationSDK  = "D0000257"  // NStation SDK

    // 게임 서비스
    case serviceGameRPS        = "D0000258"  // 가위바위보
    case serviceGameCoin       = "D0000259"  // 동전 뒤집기

    // 게임 영역
    case rouletteArea          = "D0000239"  // 룰렛 영역
    case lotteryArea           = "D0000249"  // 복권 영역

    // 배너
    case bannerHomeSmall       = "D0000265"  // 배너 홈 - 애드팝콘 small
    case bannerAdwon           = "D0000244"  // 배너 - 애드원 (공지, 오퍼월 등)

    var desc: String {
        switch self {
        case .offerwallAdForusAPI:  return "Adforus API"
        case .offerwallNStationAPI: return "NStation API"
        case .offerwallMotto:       return "모또"
        case .offerwallMocation:    return "모테이션"
        case .offerwallAdForusSDK:  return "Adforus SDK"
        case .offerwallNStationSDK: return "NStation SDK"
        case .serviceGameRPS:       return "가위바위보"
        case .serviceGameCoin:      return "동전 뒤집기"
        case .rouletteArea:         return "룰렛 영역"
        case .lotteryArea:          return "복권 영역"
        case .bannerHomeSmall:      return "배너 홈 small"
        case .bannerAdwon:          return "배너 - 애드원"
        }
    }

    /// 배너 타입 여부 (광고 배너 영역으로 사용되는 코드)
    public var isBanner: Bool {
        switch self {
        case .bannerHomeSmall: return true
        default:               return false
        }
    }

    /// 오퍼월 타입 여부
    var isOfferwall: Bool {
        switch self {
        case .offerwallAdForusAPI, .offerwallNStationAPI,
             .offerwallMotto, .offerwallMocation,
             .offerwallAdForusSDK, .offerwallNStationSDK:
            return true
        default:
            return false
        }
    }

    /// 게임 서비스 타입 여부 (가위바위보, 동전뒤집기)
    var isServiceGame: Bool {
        switch self {
        case .serviceGameRPS, .serviceGameCoin: return true
        default:                                return false
        }
    }
}

// MARK: - 광고 노출 타입 (미디에이션 priority_code 기준)

enum AdsType: String, CaseIterable {
    case adPopcornBanner        = "D0000261"  // 애드팝콘 배너
    case adPopcornReward        = "D0000263"  // 애드팝콘 보상형
    case adPopcornFull          = "D0000262"  // 애드팝콘 전면
    case adPopcornRewardBanner  = "D0000276" // 애드팝콘 리워드 배너
    case mobiWithPopup          = "D0000246"  // MobiWith Script 팝업
    case adPopcornBannerPopup   = "D0000287"  // CU광고-애드팝콘 배너 팝업(300x250)
    case adPopcornNAMBanner     = "D0000293"  // 애드팝콘 NAM 네이티브 배너
    case unknown                = "D0000000"

    static func parse(_ code: String) -> AdsType {
        return AdsType(rawValue: code) ?? .unknown
    }
}

// MARK: - 광고 지면 위치 코드 (미디에이션 advertisement_location 기준)

public enum AdsPlacementType: String, CaseIterable {
    // 광고 지면
    case missionTicket          = "D0000195"  // 미션 티켓
    case roulette               = "D0000197"  // 룰렛 시간별
    case rouletteView           = "D0000275"  // 룰렛 게임 단독 화면
    case lottery                = "D0000266"  // 복권 시간별
    case moneyBox               = "D0000274"  // 저금통

    // 배너
    case bannerHomeSmall        = "D0000265"  // 배너-애드팝콘 : 홈 리스트 small
    case bannerRoulette         = "D0000289"  // 배너-애드팝콘 : 시간별 룰렛 화면 하단 small
    case bannerMissionTicket    = "D0000290" // 배너-애드팝콘 : 걷기 복권 화면 하단 small
    case bannerRouletteView     = "D0000292"  // 배너-애드팝콘 : 룰렛 게임 단독 화면 하단 small
    case bannerLottery          = "D0000291"  // 배너-애드팝콘 : 시간별 복권 화면 하단 small

    // CU 자체 광고
    case cuAdNewProduct         = "D0000285"  // CU 광고 - 신상품
    case cuAdPreOrder           = "D0000286"  // CU 광고 - 예약구매
    case cuAdEat                = "D0000283"  // CU 광고 - 오늘 뭐먹지
    case cuAdInventory          = "D0000284"  // CU 광고 - 재고조회

    case unknown                = "D0000000"

    public static func parse(_ code: String) -> AdsPlacementType {
        return AdsPlacementType(rawValue: code) ?? .unknown
    }

    public var isBanner: Bool {
        switch self {
        case .bannerHomeSmall, .bannerRoulette, .bannerMissionTicket,
             .bannerRouletteView, .bannerLottery:
            return true
        default:
            return false
        }
    }
}
