//
//  RewardMilestone.swift
//  PointCU
//
//  Created by Juno Yoon on 4/16/26.
//

import Foundation

// SDK 내부에서만 사용하는 모델 (internal)
struct RewardMilestone: Identifiable {
    let id: Int                     // missionScheduleId 기반 고유 식별자
    let step: Int                   // 목표 걸음 수 (예: 0, 1000,...)
    let displayText: String         // 목표 걸명 명 (예: 0걸음, 1000걸음,...)
    let rewardType: RewardType      // 보상 종류 (체크, 포인트, 복권 등)
    let status: RewardStatus        // 현재 상태 (완료, 수령 가능, 잠김 등)
    
    enum RewardType {
        case point
        case ticket
    }
    
    enum RewardStatus {
        case completed
        case available
        case locked
    }
}
