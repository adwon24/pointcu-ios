//
//  ApiModel.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/5/26.
//

import Foundation

// MARK: - 공통 응답 래퍼

struct ApiResponse<T: Codable>: Codable {
    let result: Bool
    let resultCode: String?   // result:false 시 없을 수 있음
    let resultMsg: String?    // result:false 시 없을 수 있음
    let resultData: T?

    enum CodingKeys: String, CodingKey {
        case result
        case resultCode = "result_code"
        case resultMsg  = "result_msg"
        case resultData = "result_data"
    }
}

// MARK: - 1. 인증 (로그인 / 회원가입)

// 로그인 응답 result_data
// 신규 회원(is_registered: false): data_gathering_id, data_gathering_name 포함
// 기존 회원(is_registered: true) : auth_level, member_id 등 포함, data_gathering 없음
// → 두 케이스를 모두 수용하도록 공통 필드만 필수, 나머지는 옵셔널
struct LoginResponse: Codable {
    let isRegistered: Bool
    let token: String
    // 신규 회원 전용
    let dataGatheringId: String?
    let dataGatheringName: String?
    // 기존 회원 전용
    let authLevel: String?
    let memberId: Int?

    enum CodingKeys: String, CodingKey {
        case isRegistered      = "is_registered"
        case token
        case dataGatheringId   = "data_gathering_id"
        case dataGatheringName = "data_gathering_name"
        case authLevel         = "auth_level"
        case memberId          = "member_id"
    }
}

// 회원가입 응답 result_data
// {"auth_level":"...","etiquette_start":0,"etiquette_end":0,"terms_list":"",
//  "push_enable":true,"guide_url":"...","is_registered":true,"token":"..."}
struct SignUpResponse: Codable {
    let isRegistered: Bool
    let token: String
    let authLevel: String
    let etiquetteStart: Int
    let etiquetteEnd: Int
    let termsList: String
    let pushEnable: Bool
    let guideUrl: String

    enum CodingKeys: String, CodingKey {
        case isRegistered  = "is_registered"
        case token
        case authLevel     = "auth_level"
        case etiquetteStart = "etiquette_start"
        case etiquetteEnd   = "etiquette_end"
        case termsList     = "terms_list"
        case pushEnable    = "push_enable"
        case guideUrl      = "guide_url"
    }
}

// MARK: - 2. 걸음 미션 현황 (GET /api/v2/member/mission/ticketIssue)

struct MissionData: Codable {
    let missionId: Int
    let targetStep: Int              // 완료 기준 걸음 수
    var stepCount: Int               // 서버 기준 현재 걸음 수 (추후 업데이트 가능)
    var ticketCount: Int             // 발행한 티켓 수 (추후 업데이트 가능)
    var ticketUseCount: Int          // 사용한 티켓 수 (추후 업데이트 가능)
    let ticketLimit: Int             // 최대 발행 가능 티켓 수
    let customDisplayTextYn: String? // "Y": 커스텀 텍스트 사용 — ticketIssue 응답엔 없을 수 있음
    let missionType: String?         // 미션 타입 — ticketIssue 응답엔 없을 수 있음
    var scheduleList: [MissionSchedule]

    // step_count / step 둘 다 수용하기 위해 별도 DecodingKeys 사용
    private enum DecodingKeys: String, CodingKey {
        case missionId           = "mission_id"
        case targetStep          = "target_step"
        case stepCount           = "step_count"
        case step                              // 서버 버그 대응
        case ticketCount         = "ticket_count"
        case ticketUseCount      = "ticket_use_count"
        case ticketLimit         = "ticket_limit"
        case customDisplayTextYn = "custom_display_text_yn"
        case missionType         = "mission_type"
        case scheduleList        = "schedule_list"
    }

    enum CodingKeys: String, CodingKey {
        case missionId           = "mission_id"
        case targetStep          = "target_step"
        case stepCount           = "step_count"
        case ticketCount         = "ticket_count"
        case ticketUseCount      = "ticket_use_count"
        case ticketLimit         = "ticket_limit"
        case customDisplayTextYn = "custom_display_text_yn"
        case missionType         = "mission_type"
        case scheduleList        = "schedule_list"
    }

    // processMissionData에서 직접 생성할 때 사용하는 멤버와이즈 이니셜라이저
    // init(from:) 커스텀 구현으로 자동 생성이 사라져서 명시적으로 추가
    init(missionId: Int, targetStep: Int, stepCount: Int,
         ticketCount: Int, ticketUseCount: Int, ticketLimit: Int,
         customDisplayTextYn: String?, missionType: String?,
         scheduleList: [MissionSchedule]) {
        self.missionId           = missionId
        self.targetStep          = targetStep
        self.stepCount           = stepCount
        self.ticketCount         = ticketCount
        self.ticketUseCount      = ticketUseCount
        self.ticketLimit         = ticketLimit
        self.customDisplayTextYn = customDisplayTextYn
        self.missionType         = missionType
        self.scheduleList        = scheduleList
    }

    init(from decoder: Decoder) throws {
        let container    = try decoder.container(keyedBy: DecodingKeys.self)
        missionId        = try container.decode(Int.self, forKey: .missionId)
        targetStep       = try container.decode(Int.self, forKey: .targetStep)
        ticketCount      = try container.decode(Int.self, forKey: .ticketCount)
        ticketUseCount   = try container.decode(Int.self, forKey: .ticketUseCount)
        ticketLimit      = try container.decode(Int.self, forKey: .ticketLimit)
        customDisplayTextYn = try container.decodeIfPresent(String.self, forKey: .customDisplayTextYn)
        missionType      = try container.decodeIfPresent(String.self, forKey: .missionType)
        scheduleList     = try container.decode([MissionSchedule].self, forKey: .scheduleList)

        // step_count / step 둘 다 수용 — 서버 버그 대응
        if let count = try container.decodeIfPresent(Int.self, forKey: .stepCount) {
            stepCount = count
        } else if let count = try container.decodeIfPresent(Int.self, forKey: .step) {
            stepCount = count
        } else {
            stepCount = 0
        }
    }

    // encode는 CodingKeys 기준으로 step_count로 저장
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(missionId,           forKey: .missionId)
        try container.encode(targetStep,          forKey: .targetStep)
        try container.encode(stepCount,           forKey: .stepCount)
        try container.encode(ticketCount,         forKey: .ticketCount)
        try container.encode(ticketUseCount,      forKey: .ticketUseCount)
        try container.encode(ticketLimit,         forKey: .ticketLimit)
        try container.encodeIfPresent(customDisplayTextYn, forKey: .customDisplayTextYn)
        try container.encodeIfPresent(missionType,         forKey: .missionType)
        try container.encode(scheduleList,        forKey: .scheduleList)
    }
}

struct MissionSchedule: Codable {
    let missionScheduleId: Int    // 걸음 구간 아이디
    let stepCountDuration: Int    // 걸음 구간 수 (예: 100, 200, 300)
    let advertisementYn: String   // "Y": 광고 시청 필요, "N": 광고 없이 수령
    let customDisplayText: String // customDisplayTextYn == "Y"일 때 표시할 텍스트

    // 서버 응답값이 아닌 processMissionData()에서 가공해서 주입하는 값
    var isIssued: Bool   = false  // 티켓 발행 여부 (ticketCount 기준)
    var isComplete: Bool = false  // 티켓 사용/참여 여부 (ticketUseCount 기준)

    enum CodingKeys: String, CodingKey {
        case missionScheduleId = "mission_schedule_id"
        case stepCountDuration = "step_count_duration"
        case advertisementYn   = "advertisement_yn"
        case customDisplayText = "custom_display_text"
        // isIssued, isComplete 는 디코딩 대상 제외
    }
}

// MARK: - 3. 메인 정보 (POST /api/v2/member/home/main)

struct MainData: Codable {
    let user: UserInfo
    let adPopup: [AdPopup]
    let appVersion: Int
    let sdk: SdkInfo
    let admobType: String

    enum CodingKeys: String, CodingKey {
        case user
        case adPopup     = "ad_popup"
        case appVersion  = "app_version"
        case sdk
        case admobType   = "admob_type"
    }
}

struct UserInfo: Codable {
    let id: Int
    let memberCode: String
    let sdkCode: String
    let gender: String
    let registered: String    // 가입일 (yyyy-MM-dd)
    let updateDate: String
    let badgeDisplayYn: String
    let withdrawYn: String

    enum CodingKeys: String, CodingKey {
        case id
        case memberCode    = "member_code"
        case sdkCode       = "sdk_code"
        case gender
        case registered
        case updateDate    = "update_date"
        case badgeDisplayYn = "badge_display_yn"
        case withdrawYn    = "withdraw_yn"
    }
}

struct AdPopup: Codable, Identifiable {
    let id: Int
    let title: String
    let linkType: String      // "U": URL, "O": 오퍼월, "N": 공지사항
    let linkData: String
    let noticeTitle: String
    let noticeContent: String
    let noticeRegDate: String
    let offerwallDetailId: String
    let serviceDetailId: String
    let displayOrder: String
    let url: String           // 이미지 경로 (base_url + url)

    enum CodingKeys: String, CodingKey {
        case id              = "popup_id"
        case title
        case linkType        = "link_type"
        case linkData        = "link_data"
        case noticeTitle     = "notice_title"
        case noticeContent   = "notice_content"
        case noticeRegDate   = "notice_reg_date"
        case offerwallDetailId = "offerwall_detail_id"
        case serviceDetailId   = "service_detail_id"
        case displayOrder    = "display_order"
        case url
    }
}

struct SdkInfo: Codable {
    let sdkId: Int
    let shopSupplyType: String
    let dataGatheringId: String
    let offerwallServiceCodeList: [OfferwallServiceCode]

    enum CodingKeys: String, CodingKey {
        case sdkId                   = "sdk_id"
        case shopSupplyType          = "shop_supply_type"
        case dataGatheringId         = "data_gathering_id"
        case offerwallServiceCodeList = "offerwall_service_code_list"
    }
}

struct OfferwallServiceCode: Codable {
    let detailId: String
    let code: String
    let name: String

    enum CodingKeys: String, CodingKey {
        case detailId = "detail_id"
        case code
        case name
    }
}

// MARK: - 4. UI 리스트 (GET /api/v2/member/ui/list)

struct UiListData: Codable {
    let location: String
    let bannerList: [UiBannerItem]

    enum CodingKeys: String, CodingKey {
        case location
        case bannerList = "banner_list"
    }
}

struct UiBannerItem: Codable, Identifiable {
    // displayOrder를 id로 사용 — detail_id(D0000244 등)는 중복될 수 있음
    var id: String { displayOrder }
    let detailId: String      // UiOrderCode 분기용 (detail_id)
    let title: String?
    let displayOrder: String
    let bannerInfo: BannerInfo?
 
    enum CodingKeys: String, CodingKey {
        case detailId     = "detail_id"
        case title
        case displayOrder = "display_order"
        case bannerInfo   = "banner_info"
    }
}
 
struct BannerInfo: Codable {
    let bannerId: Int
    let title: String
    let bannerContentType: String   // "T": 텍스트형
    let descriptionUpper: String
    let descriptionLower: String
    let linkType: String            // "S": 서비스, "O": 오퍼월, "U": URL, "N": 공지
    let linkData: String
    let offerwallDetailId: String
    let serviceDetailId: String
    let url: String                 // 이미지 경로
 
    enum CodingKeys: String, CodingKey {
        case bannerId          = "banner_id"
        case title
        case bannerContentType = "banner_content_type"
        case descriptionUpper  = "description_upper"
        case descriptionLower  = "description_lower"
        case linkType          = "link_type"
        case linkData          = "link_data"
        case offerwallDetailId = "offerwall_detail_id"
        case serviceDetailId   = "service_detail_id"
        case url
    }
}

// MARK: - ticketConfirm 응답 (POST /api/v2/member/mission/ticketConfirm)

struct TicketConfirmResponse: Codable {
    let missionId: Int
    let targetStep: Int
    let stepCount: Int
    let ticketCount: Int
    let ticketUseCount: Int
    let ticketLimit: Int
    let winPoint: Int              // 이번 확인으로 획득한 포인트

    private enum DecodingKeys: String, CodingKey {
        case missionId      = "mission_id"
        case targetStep     = "target_step"
        case stepCount      = "step_count"
        case step                          // 서버 버그 대응
        case ticketCount    = "ticket_count"
        case ticketUseCount = "ticket_use_count"
        case ticketLimit    = "ticket_limit"
        case winPoint       = "win_point"
    }

    enum CodingKeys: String, CodingKey {
        case missionId      = "mission_id"
        case targetStep     = "target_step"
        case stepCount      = "step_count"
        case ticketCount    = "ticket_count"
        case ticketUseCount = "ticket_use_count"
        case ticketLimit    = "ticket_limit"
        case winPoint       = "win_point"
    }

    init(from decoder: Decoder) throws {
        let container  = try decoder.container(keyedBy: DecodingKeys.self)
        missionId      = try container.decode(Int.self, forKey: .missionId)
        targetStep     = try container.decode(Int.self, forKey: .targetStep)
        ticketCount    = try container.decode(Int.self, forKey: .ticketCount)
        ticketUseCount = try container.decode(Int.self, forKey: .ticketUseCount)
        ticketLimit    = try container.decode(Int.self, forKey: .ticketLimit)
        winPoint       = try container.decode(Int.self, forKey: .winPoint)

        // step_count / step 둘 다 수용 — 서버 버그 대응
        if let count = try container.decodeIfPresent(Int.self, forKey: .stepCount) {
            stepCount = count
        } else if let count = try container.decodeIfPresent(Int.self, forKey: .step) {
            stepCount = count
        } else {
            stepCount = 0
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(missionId,      forKey: .missionId)
        try container.encode(targetStep,     forKey: .targetStep)
        try container.encode(stepCount,      forKey: .stepCount)
        try container.encode(ticketCount,    forKey: .ticketCount)
        try container.encode(ticketUseCount, forKey: .ticketUseCount)
        try container.encode(ticketLimit,    forKey: .ticketLimit)
        try container.encode(winPoint,       forKey: .winPoint)
    }
}

// MARK: - 광고 미디에이션 (GET /api/v2/member/advertisement/mediation/list)

struct MediationListData: Codable {
    let mediationList: [MediationLocation]
    let pangleAppId: String
    let unityGameId: String

    enum CodingKeys: String, CodingKey {
        case mediationList = "mediation_list"
        case pangleAppId   = "pangle_app_id"
        case unityGameId   = "unity_game_id"
    }
}

struct MediationLocation: Codable {
    let advertisementLocation: String      // 광고 위치 코드 (예: "D0000128")
    let advertisementLocationName: String  // 광고 위치명 (예: "미션 티켓")
    let advertisementList: [MediationAd]

    enum CodingKeys: String, CodingKey {
        case advertisementLocation     = "advertisement_location"
        case advertisementLocationName = "advertisement_location_name"
        case advertisementList         = "advertisement_list"
    }
}

struct MediationAd: Codable {
    let priorityCode: String  // 광고 종류 코드 (예: "D0000143")
    let priorityName: String  // 광고 종류명 (예: "팽글 전면")
    let adKey: String         // 광고 키 (빈 문자열이면 미사용)

    enum CodingKeys: String, CodingKey {
        case priorityCode = "priority_code"
        case priorityName = "priority_name"
        case adKey        = "ad_key"
    }
}


// MARK: - 룰렛/복권 상세 (GET /api/v2/member/benefit/detail)

struct BenefitDetailResponse: Codable {
    let benefitId: Int
    let trialPoint: Int
    let maxPoint: Int
    let todayPoint: Int
    let memberParticipationCount: Int
    let backgroundImageUrl: String
    let benefitType: String            // "R": 룰렛, "L": 복권

    // 룰렛 전용
    let rouletteImageUrl: String?
    let rouletteArrowImageUrl: String?
    let rouletteTextImageUrl: String?

    // 복권 전용
    let lotteryScratchImageUrl: String?
    let lotteryTextImageUrl: String?

    let displayTimeYn: String
    let startTime: String
    let endTime: String
    let location: String
    let dataList: [RouletteSlice]?     // 룰렛 섹터 목록 (복권은 nil 또는 빈 배열)
    let ticketCount: Int
    let ticketUseCount: Int
    let ticketLimit: Int
    let ticketLimitYn: String

    enum CodingKeys: String, CodingKey {
        case benefitId                = "benefit_id"
        case trialPoint               = "trial_point"
        case maxPoint                 = "max_point"
        case todayPoint               = "today_point"
        case memberParticipationCount = "member_participation_count"
        case backgroundImageUrl       = "background_image_url"
        case benefitType              = "benefit_type"
        case rouletteImageUrl         = "roulette_image_url"
        case rouletteArrowImageUrl    = "roulette_arrow_image_url"
        case rouletteTextImageUrl     = "roulette_text_image_url"
        case lotteryScratchImageUrl   = "lottery_scratch_image_url"
        case lotteryTextImageUrl      = "lottery_text_image_url"
        case displayTimeYn            = "display_time_yn"
        case startTime                = "start_time"
        case endTime                  = "end_time"
        case location
        case dataList                 = "data_list"
        case ticketCount              = "ticket_count"
        case ticketUseCount           = "ticket_use_count"
        case ticketLimit              = "ticket_limit"
        case ticketLimitYn            = "ticket_limit_yn"
    }
}

struct RouletteSlice: Codable {
    let rouletteId: Int
    let startAngle: Double
    let endAngle: Double

    enum CodingKeys: String, CodingKey {
        case rouletteId = "roulette_id"
        case startAngle = "start_angle"
        case endAngle   = "end_angle"
    }

    /// 섹터 중앙 각도 — 룰렛 회전 멈춤 목표값
    var centerAngle: Double { (startAngle + endAngle) / 2.0 }

    init(rouletteId: Int, startAngle: Double, endAngle: Double) {
        self.rouletteId = rouletteId
        self.startAngle = startAngle
        self.endAngle   = endAngle
    }
}

// MARK: - 룰렛/복권 당첨 확인 (POST /api/v2/member/benefit/confirm)

struct BenefitConfirmResponse: Codable {
    let ticketCount: Int
    let ticketUseCount: Int
    let ticketLimit: Int
    let benefitId: Int
    let winRouletteId: Int?   // 룰렛 전용 — 복권은 nil
    let winPoint: Int
    let trialPoint: Int
    let maxPoint: Int
    let todayPoint: Int
    let benefitType: String
    let memberParticipationCount: Int

    enum CodingKeys: String, CodingKey {
        case ticketCount              = "ticket_count"
        case ticketUseCount           = "ticket_use_count"
        case ticketLimit              = "ticket_limit"
        case benefitId                = "benefit_id"
        case winRouletteId            = "win_roulette_id"
        case winPoint                 = "win_point"
        case trialPoint               = "trial_point"
        case maxPoint                 = "max_point"
        case todayPoint               = "today_point"
        case benefitType              = "benefit_type"
        case memberParticipationCount = "member_participation_count"
    }
}

// MARK: - 혜택 티켓 발급 (POST /api/v2/member/benefit/ticketIssue)

struct BenefitTicketIssueResponse: Codable {
    let benefitId: String   // result_data 안에서는 String으로 내려옴
    let ticketCount: Int
    let ticketUseCount: Int
    let ticketLimit: Int

    enum CodingKeys: String, CodingKey {
        case benefitId      = "benefit_id"
        case ticketCount    = "ticket_count"
        case ticketUseCount = "ticket_use_count"
        case ticketLimit    = "ticket_limit"
    }
}

// MARK: - MoneyBox (포인트뱅크)

struct MoneyBoxResponse: Codable {
    let moneyBoxScheduleId: Int?   // 간혹 없을 수 있음
    let moneyBoxId: Int?
    let startTime: String?
    let endTime: String?
    let participationCount: Int?
    let participationLimit: Int?

    /// 노출 조건:
    /// 1. moneyBoxId, moneyBoxScheduleId > 0
    /// 2. 현재 시각이 startTime ~ endTime 사이
    /// 3. participationCount < participationLimit
    var isVisible: Bool {
        // 1. ID 유효성
        guard let mbId = moneyBoxId, mbId > 0,
              let mbScheduleId = moneyBoxScheduleId, mbScheduleId > 0 else { return false }

        // 2. 참여 횟수
        if let count = participationCount, let limit = participationLimit {
            guard count < limit else { return false }
        }

        // 3. 시간 범위 (HH:mm 형식)
        if let start = startTime, let end = endTime,
           !start.isEmpty, !end.isEmpty {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"
            formatter.timeZone = TimeZone.current
            let now = formatter.string(from: Date())
            guard now >= start && now <= end else { return false }
        }

        return true
    }
    
    let title: String
    let displayDescription: String
    let imageUrl: String

    enum CodingKeys: String, CodingKey {
        case moneyBoxScheduleId = "moneybox_schedule_id"
        case moneyBoxId         = "moneybox_id"
        case startTime          = "start_time"
        case endTime            = "end_time"
        case participationCount = "participation_count"
        case participationLimit = "participation_limit"
        case title
        case displayDescription = "display_description"
        case imageUrl           = "image_url"
    }
}

struct MoneyBoxConfirmResponse: Codable {
    let moneyBoxId: Int
    let moneyBoxScheduleId: Int
    let winPoint: Int
    let participationCount: Int
    let participationLimit: Int

    enum CodingKeys: String, CodingKey {
        case moneyBoxId         = "moneybox_id"
        case moneyBoxScheduleId = "moneybox_schedule_id"
        case winPoint           = "win_point"
        case participationCount = "participation_count"
        case participationLimit = "participation_limit"
    }
}

// MARK: - 5. 혜택 리스트 (GET /api/v2/member/benefit/list)
//           룰렛(R) / 복권(L) 공통 모델

struct BenefitListData: Codable {
    let dataList: [BenefitItem]

    enum CodingKeys: String, CodingKey {
        case dataList = "data_list"
    }
}

struct BenefitItem: Codable, Identifiable {
    let id: Int
    let benefitType: String           // "R": 룰렛, "L": 복권
    let titleUpper: String
    let titleLower: String
    let participationCount: Int        // 참여 횟수 제한 (0 = 무제한)
    let participationPayment: Int      // 참여 비용 포인트
    let ticketLimitYn: String          // "Y": 티켓 제한 있음
    let memberParticipationCount: Int  // 오늘 사용자 참여 횟수
    let displayTimeYn: String          // "Y": 시간 표시
    let startTime: String
    let endTime: String

    enum CodingKeys: String, CodingKey {
        case id                       = "benefit_id"
        case benefitType              = "benefit_type"
        case titleUpper               = "title_upper"
        case titleLower               = "title_lower"
        case participationCount       = "participation_count"
        case participationPayment     = "participation_payment"
        case ticketLimitYn            = "ticket_limit_yn"
        case memberParticipationCount = "member_participation_count"
        case displayTimeYn            = "display_time_yn"
        case startTime                = "start_time"
        case endTime                  = "end_time"
    }
}

// MARK: - 공지/FAQ 페이징 (GET /api/v2/member/notice/pagingList)

struct NoticePagingResponse: Codable {
    let totalCount: Int
    let noticeList: [NoticeItem]

    enum CodingKeys: String, CodingKey {
        case totalCount  = "total_count"
        case noticeList  = "notice_list"
    }
}

struct NoticeItem: Codable, Identifiable, Equatable {
    let id: Int
    let title: String
    let content: String
    let positionYn: String   // "Y": 상단 고정
    let regDate: String
    let popupYn: String
    let registDate: String

    enum CodingKeys: String, CodingKey {
        case id         = "notice_id"
        case title      = "notice_title"
        case content    = "notice_content"
        case positionYn = "position_yn"
        case regDate    = "reg_date"
        case popupYn    = "popup_yn"
        case registDate = "regist_date"
    }
}

// MARK: - 통계 (GET /api/v2/member/statistic/list)

struct StatisticResponse: Codable {
    let height: Int?
    let weight: Int?
    let items: [StatisticItem]
    let result: Bool

    enum CodingKeys: String, CodingKey {
        case height, weight, items, result
    }
}

struct StatisticItem: Codable {
    let useYn: String?  // 옵셔널 (응답에 없는 경우 있음)
    let duration: Int
    let step: Int
    let date: Int64     // Unix timestamp (ms)

    enum CodingKeys: String, CodingKey {
        case useYn   = "use_yn"
        case duration
        case step
        case date
    }
}

// MARK: - 걸음 수 업데이트 (POST /api/v2/member/step/updateList)

struct StepUpdateItem: Codable {
    let stepDate: String   // "yyyy-MM-dd"
    let stepCount: Int

    enum CodingKeys: String, CodingKey {
        case stepDate  = "step_date"
        case stepCount = "step_count"
    }
}

// MARK: - 시스템 점검 (GET /api/v2/member/home/inspection)

struct InspectionData: Codable {
    let inspectionId: Int
    let description:  String

    enum CodingKeys: String, CodingKey {
        case inspectionId = "inspection_id"
        case description
    }
}

// MARK: - 공지 팝업 (GET /api/v2/member/popup/list)

struct NoticePopupListData: Codable {
    let popupList: [NoticePopupItem]
 
    enum CodingKeys: String, CodingKey {
        case popupList = "popup_list"
    }
}

struct NoticePopupItem: Codable {
    let popupId:    Int
    let title:      String
    let content:    String
    let positionYn: String
    let regDate:    String
 
    enum CodingKeys: String, CodingKey {
        case popupId    = "popup_id"
        case title
        case content
        case positionYn = "position_yn"
        case regDate    = "reg_date"
    }
}
