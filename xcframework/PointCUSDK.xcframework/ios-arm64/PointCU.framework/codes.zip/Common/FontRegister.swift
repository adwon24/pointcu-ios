//
//  FontRegister.swift
//  PointCU
//
//  Created by Juno Yoon on 4/10/26.
//

import UIKit
import CoreText

struct FontRegistrar {
    // 1. static let 클로저를 활용한 1회 실행 보장
    private static let _registerFonts: () = {
        registerSingleFont(name: "Roboto-Bold", extension: "ttf", bundle: .pointCU)
        registerSingleFont(name: "Roboto-Medium", extension: "ttf", bundle: .pointCU)
        registerSingleFont(name: "Roboto-Regular", extension: "ttf", bundle: .pointCU)
    }()
    
    // 2. 고객사(Host App)나 SDK 초기화단에서 호출할 공개 메서드
    static func setup() {
        _ = _registerFonts
    }
    
    // 3. 실제 폰트를 등록하는 내부 로직 (외부에서 직접 못 부르게 private 처리)
    private static func registerSingleFont(name: String, extension: String, bundle: Bundle) {
        guard let url = bundle.url(forResource: name, withExtension: `extension`),
              let fontData = try? Data(contentsOf: url),
              let provider = CGDataProvider(data: fontData as CFData),
              let font = CGFont(provider) else {
            print("[SDK] 폰트 파일을 찾을 수 없습니다: \(name)")
            return
        }
        
        var error: Unmanaged<CFError>?
        if !CTFontManagerRegisterGraphicsFont(font, &error) {
            print("[SDK] 폰트 등록 실패: \(String(describing: error?.takeUnretainedValue()))")
        }
    }
}

class FontDebugger {
    public static func printAllAvailableFonts() {
        let familyNames = UIFont.familyNames.sorted()
        for family in familyNames {
            print("Family: [ \(family) ]")
            let fontNames = UIFont.fontNames(forFamilyName: family)
            for fontName in fontNames {
                print("  ㄴ Font Name: \(fontName)")
            }
        }
    }
}
