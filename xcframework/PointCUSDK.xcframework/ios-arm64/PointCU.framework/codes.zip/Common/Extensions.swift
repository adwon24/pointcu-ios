//
//  Extensions.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/3/26.
//

import SwiftUI
//import UIKit
import Foundation
import CoreMotion

extension Bundle {
    // 프레임워크의 Bundle Identifier를 정확히 입력해 줘
    static var pointCU: Bundle {
        return Bundle(identifier: "com.adwon.pointcu") ?? .main
    }
}

extension View {
    func useGlobalPopup() -> some View {
        self.modifier(GlobalPopupModifier())
    }
    
    func useGlobalIndicator() -> some View {
        self.modifier(GlobalIndicatorModifier())
    }
    
    // SCREEN CENTER TOAST
    func customToast(
        isPresented: Binding<Bool>,
        message: String,
        duration: TimeInterval = 2.0,
        bottomPadding: CGFloat = 0.0
    ) -> some View {
        self.modifier(
            CustomToastModifier(
                isPresented: isPresented,
                message: message,
                duration: duration,
                bottomPadding: bottomPadding
            )
        )
    }
    
    // TARGET VIEW ON TOP TOAST
    func targetRelativeToast(
        isPresented: Binding<Bool>,
        message: String,
        duration: TimeInterval = 2.0,
        spacing: CGFloat = 0.0
    ) -> some View {
        self.modifier(
            RelativeToastModifier(
                isPresented: isPresented,
                message: message,
                duration: duration,
                spacing: spacing
            )
        )
    }
}

extension StepManager {
    // 현재 권한 상태 확인
    func checkMotionAuthorization(completion: @escaping (CMAuthorizationStatus) -> Void) {
        let status = CMPedometer.authorizationStatus()
        completion(status)
    }
    
    // 설정창으로 이동하는 함수
    func openAppSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl)
        }
    }
}

extension Date {
    /// 원하는 포맷의 문자열로 변환 (예: "yyyy-MM-dd")
    func toString(format: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale.current
        formatter.timeZone = TimeZone.current
        return formatter.string(from: self)
    }
    
    /// 해당 날짜의 00시 00분 00초 반환
    func startOfDay() -> Date {
        Calendar.current.startOfDay(for: self)
    }
    
    /// 해당 날짜의 23시 59분 59초 반환
    func endOfDay() -> Date {
        var components = DateComponents()
        components.day = 1
        components.second = -1
        return Calendar.current.date(byAdding: components, to: startOfDay()) ?? self
    }
}

extension UserDefaults {
    // 제네릭 인코딩
    func encode<T: Encodable>(_ value: T, forKey key: String) {
        if let encoded = try? JSONEncoder().encode(value) {
            self.set(encoded, forKey: key)
        } else {
            print("[UserDefaults] Encode Error for key: \(key)")
        }
    }
    
    // 제네릭 디코딩 (에러 추적 기능 포함)
    func decode<T: Decodable>(_ type: T.Type, forKey key: String) -> T? {
        guard let data = self.data(forKey: key) else { return nil }
        
        do {
            return try JSONDecoder().decode(type, from: data)
        } catch {
            print("[UserDefaults] Decode Error for key '\(key)': \(error)")
            return nil
        }
    }
}

extension Int {
    var formattedWithSeparator: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        return formatter.string(from: NSNumber(value: self)) ?? "\(self)"
    }
}

extension Text {
    /// - Parameters:
    ///   - fontName: 커스텀 폰트 이름 (nil일 경우 시스템 폰트 사용)
    ///   - size: Font Size (px -> pt)
    ///   - weight: 시스템 폰트 사용 시 적용할 굵기 (기본값: .regular)
    ///   - lineHeight: Line Height (px)
    ///   - letterSpacingPercent: Letter Spacing (%)
    ///   - color: 글자 색상
    ///   - alignment: 정렬 방식
    func applyFigmaStyle(
        fontName: String? = nil,
        size: CGFloat,
        weight: Font.Weight = .regular,
        lineHeight: CGFloat,
        letterSpacingPercent: CGFloat,
        color: Color = .black,
        alignment: TextAlignment = .center
    ) -> some View {
        
        let trackingValue = size * (letterSpacingPercent / 100.0)
        let lineSpacingValue = lineHeight - size
        
        // 1. 폰트 분기 처리 로직
        let appliedFont: Font
        if let fontName = fontName, !fontName.isEmpty {
            // 커스텀 폰트명(예: "AppleSDGothicNeo-Bold")이 명확히 지정된 경우
            appliedFont = .custom(fontName, size: size)
        } else {
            // nil이거나 빈 문자열일 경우 OS 시스템 폰트 적용
            appliedFont = .system(size: size, weight: weight)
        }
        
        // 2. 스타일 적용
        return self
            .font(appliedFont)
            .tracking(trackingValue)
            .foregroundColor(color)
            .multilineTextAlignment(alignment)
            .lineSpacing(max(0, lineSpacingValue))
            .padding(.vertical, max(0, lineSpacingValue) / 2)
    }
    
    func typography(_ style: PointCUTypography, color: Color = .black, alignment: TextAlignment = .center) -> some View {
        return self.applyFigmaStyle(
            fontName: style.fontName,
            size: style.size,
            weight: style.weight, // 웨이트 파라미터 전달
            lineHeight: style.lineHeight,
            letterSpacingPercent: style.letterSpacingPercent,
            color: color,
            alignment: alignment
        )
    }
}

extension UIFont {
    /// 폰트의 실제 정보를 콘솔에 출력하여 디버깅을 돕습니다.
    func debugFontInfo(context: String = "Unknown UI") {
        print("📌 [\(context)] 적용된 폰트 정보")
        print("   - Family Name: \(self.familyName)")
        print("   - Font Name (PostScript): \(self.fontName)")
        print("   - Point Size: \(self.pointSize)")
        print("-----------------------------------")
    }
}

// MARK: - UIApplication 헬퍼
 
extension UIApplication {
    /// 현재 최상위 UIViewController 반환
    func topViewController() -> UIViewController? {
        guard let scene = connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }),
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
        else { return nil }
 
        var top = root
        while let presented = top.presentedViewController { top = presented }
        return top
    }
}
