//
//  Utils.swift
//  PointCU
//
//  Created by Juno Yoon on 4/23/26.
//

import Foundation
import SwiftUI
import AdSupport
import AppTrackingTransparency

func formatNumber(_ value: Int) -> String {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal // 1000단위 콤마
    return formatter.string(from: NSNumber(value: value)) ?? "0"
}

func formatFloat(_ value: Double) -> String {
    return String(format: "%.1f", value) // 소수점 1자리까지
}

func formatDecimal(_ value: Double) -> String {
    return String(format: "%.0f", value.rounded())
}

// MARK: - 공통 AsyncImage 뷰

var sdkBaseURL: String {
    switch Constants.devServerType {
    case .stg:  return Constants.Api.devBaseURL
    case .aws:  return Constants.Api.devBaseURL2
    case .prod: return Constants.Api.prodBaseURL
    }
}

/// SDK 서버 상대경로를 받아 이미지로 렌더링
/// URLCache를 무시하고 항상 최신 이미지를 로드
@ViewBuilder
func SDKAsyncImage(path: String) -> some View {
    SDKRemoteImage(urlString: sdkBaseURL + path)
}

private struct SDKRemoteImage: View {
    let urlString: String
    @State private var uiImage: UIImage? = nil
    @State private var isLoading = true

    var body: some View {
        Group {
            if let img = uiImage {
                Image(uiImage: img).resizable()
            } else if isLoading {
                Color.clear.overlay(ProgressView().scaleEffect(0.6))
            } else {
                Color.clear
            }
        }
        .task(id: urlString) {
            await loadImage()
        }
    }

    private func loadImage() async {
        guard let url = URL(string: urlString) else { isLoading = false; return }
        // 캐시 무시 — 서버에서 이미지가 변경됐을 때 항상 최신 이미지 표시
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.timeoutInterval = 15
        do {
            let (data, _) = try await URLSession.shared.data(for: request)
            if let image = UIImage(data: data) {
                uiImage = image
            }
        } catch {}
        isLoading = false
    }
}

// MARK: - Custom Logger

func CULog(_ message: String) {
    guard Constants.devServerType != .prod else { return }

    let formatter = DateFormatter()
    formatter.dateFormat = "HH:mm:ss"
    let time = formatter.string(from: Date())

    print("[\(time)] \(message)")
}

// MARK: - 광고 ID 유틸

/// IDFA 우선, 없으면 IDFV 반환 (minSDK 15.0 기준)
/// ATT 권한 허용 시 IDFA, 미허용 시 IDFV
func adIdentifier() -> String {
    if ATTrackingManager.trackingAuthorizationStatus == .authorized {
        let idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString
        if !idfa.isEmpty && idfa != "00000000-0000-0000-0000-000000000000" {
            return idfa
        }
    }
    return UIDevice.current.identifierForVendor?.uuidString ?? ""
}

/// 광고 추적 동의 여부 (ATT)
var isAdTrackingAuthorized: Bool {
    ATTrackingManager.trackingAuthorizationStatus == .authorized
}
