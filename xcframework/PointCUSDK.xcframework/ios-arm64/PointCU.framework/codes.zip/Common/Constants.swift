//
//  Constants.swift
//  PointCU
//
//  Created by Juno Yoon on 4/15/26.
//
import SwiftUI
import Foundation

public enum PointCUServerType {
    case stg   // https://stg.api.point4u.co.kr
    case aws   // https://aws.api.point4u.co.kr
    case prod  // https://api.point4u.co.kr (상용)
}

enum Constants {

    static let TEST_MODE    = true
    static let NETWORK_LOG  = true
    
    static var devServerType: PointCUServerType = .prod
    
    enum SDKLayout {
        static let deviceWidth: CGFloat = UIScreen.main.bounds.width
        static let deviceHeight: CGFloat = UIScreen.main.bounds.height
    }
    
    enum Key {
        static let userDefualtSuiteName = "com.pointcu.sdk.defaults"
        static let tokenKey = "PointCU_Authorization"
        static let userIdKey = "PointCU_UserId"
        static let stepHistoryKey = "PointCU_StepHistory"
        static let trackingStateKey = "PointCU_TrackingState"
        static let frozenStepsKey = "PointCU_FrozenSteps"
        static let frozenDistanceKey = "PointCU_FrozenDistance"
        static let frozenCaloriesKey = "PointCU_FrozenCalories"
        static let frozenDateKey = "PointCU_FrozenDate"
        static let stepEmergencyKey = "PointCU_EmergencySteps"
        static let stepEmergencyDateKey  = "PointCU_EmergencyDate" 
        static let trackingStartDateKey = "PointCU_TrackingStartDate"
        static let syncedDatesKey = "PointCU_SyncedDates"
    }
    
    enum Api {
        static let devBaseURL   = "https://stg.api.point4u.co.kr"
        static let devBaseURL2  = "https://aws.api.point4u.co.kr"
        static let prodBaseURL  = "https://api.point4u.co.kr"
        static let devCompanyCode  = "b67f4c7b-157d-45bc-8bb8-a664a520c8e7"  // STG OR AWS
        static let prodCompanyCode = "d5d6a02f-65f4-4b2a-b411-c433766e6f9b"  // 상용
        static var companyCode: String {
            devServerType == .prod ? prodCompanyCode : devCompanyCode
        }
        static let devSdkCode   = "2062c9c8-792b-4e97-bd6b-82be8afec4a8"  // STG OR AWS
        static let prodSdkCode  = "2062c9c8-792b-4e97-bd6b-82be8afec4a8"  // 상용
        static var sdkCode: String {
            devServerType == .prod ? prodSdkCode : devSdkCode
        }
        static let packageCode  = "com.adwon.pointcu"
    }
    
    // ── 애드팝콘 SSP ─────────────────────────────────────────
    enum AdPopcorn {
        static let appKey = "329767435"
    }
    
    enum NAM {
        static let publisherCd = "N256497692"
    }

    // ── 애드포러스 GreenP 오퍼월 ──────────────────────────────
    enum GreenP {
        static let appCode = "wQdxbGloub"
    }

    // ── 나스미디어 엔스테이션 오퍼월 ────────────────────────────
    enum NStation {
        static let mkey         = 10989   // 오퍼월
        static let rpsGameMkey  = 11000   // 가위바위보
        static let coinGameMkey = 11002   // 동전뒤집기
        // mckey는 사업부서 확인 필요
    }
 
    // ── 모비위드 ─────────────────────────────────────────────
    // zone 파라미터로 사용
    enum MobiWith {
        static let roulettePlayground = "10894054"  // CU놀이터 룰렛
        static let pointPiggyBank     = "10894056"  // 포인트저금통
        static let stepReward         = "10894058"  // 걸음수 보상
        static let walkingRoulette    = "10894060"  // CU걷기 룰렛
        static let walkingLottery     = "10894062"  // CU걷기 복권
    }
    
    enum Margin {
        static let horizontal = 16.0
        static let vertical = 26.0
    }
    
    enum ImageName {
        static let back = "btn_back" // 뒤로가기 아이콘
        static let mail = "icn_mail" // 문의 메일 아이콘
        static let bear = "bear_walk" // JWebP 플레이어용 파일 이름
        static let pointBadgeOn = "point_badge_on"
        static let pointBadgeOff = "point_badge_off"
        static let ticketBadgeOn = "ticket_badge_on"
        static let ticketBadgeOff = "ticket_badge_off"
        static let icnInventory = "icn_inventory"
        static let listArrow = "chevron.right" // 리스트 화살표 시스템 아이콘
        static let moveBottomArrow = "icn_move_bottom"
        static let scratchResultBg = "scratch_result_bg"
        static let scratchCover = "scratch_cover"
        static let fireCracker = "icn_firecracker"
        static let bearWalkBackground = "bear_walk_background"
        static let pigBank = "icn_pig"
        static let missionCheckMark = "icn_check_on"
        static let rouletteThumb = "icn_roulette"
        static let lotteryThumb = "icn_lottery"
        static let lotteryTicketBg = "ticket_bg"
    }
    
    enum Id {
        static let mainScrollTopId = "mainScrollTopId"
        static let mainScrollBottomId = "mainScrollBottomId"
    }
    
    enum Text {
        static let mainTitle = "CU 걷기"
        static let textConfirm = "확인"
        static let textCancel = "취소"
        static let textClose = "닫기"
        static let textLater = "나중에"
        static let textRefusal = "거부"
        static let textAllowance = "허용"
        static let actionGoToSettings = "설정으로 이동"
        static let actionConfirm = "확인하기"
        static let textTrackingStop = "중단하기"
        static let dashboardDataTitle = "오늘 이만큼 걸었어요"
        static let steps = "걸음"
        static let km = "Km"
        static let kcal = "Kcal"
        static let point = "포인트"
        static let ticket = "복권"
        static let permissionGuideTitle    = "권한 허용 안내"
        static let permissionMotionTitle   = "신체활동(필수)"
        static let permissionMotionDesc    = "CU걷기를 통해 신체 활동 정보(걸음수)를 제공 하는데 필요합니다."
        static let permissionMotionGuide   = "위 접근 권한은 CU 걷기 서비스를 원활하게 이용하기 위해 사용됩니다. 권한을 허용하지 않는 경우 서비스 이용이 제한될 수 있습니다."
        static let permissionDeniedGuide   = "신체활동 권한이 거부되어 있습니다.\n설정에서 권한을 허용하시면 서비스를 이용할 수 있습니다."
        static let getPrevStepMissonReward = "앞의 보상부터 순차적으로 받아주세요."
        static let stockDesc = "지금 뜨는 신상품, 근처에서 찾아요"
        static let statsDesc = "지금까지 얼마나 걸었을까요?"
        static let showStats = "통계보기"
        static let trackingDisabledTitle = "걸음 수 측정이 꺼져 있어요."
        static let trackingDisabledDesc = "포인트를 적립하고 싶으면 하단 토글에서 걸음 수 측정을 켜주세요."
        static let moveToStcokDesc = "CU 걷기를 종료하고\n재고조회를 하러 갈까요?"
        static let trackingToggleTitle = "걸음수 측정"
        static let trackingEnabledDesc = "걸음수 측정이 시작되었어요.\n이제부터 걸음 수 달성 후\n보상을 받을 수 있어요!"
        static let trackingDisableDesc = "걸음수 측정을 종료하면\n걸음수 보상을 받을 수 없어요!\n그래도 측정을 종료하시겠어요?"
        static let motionPermissionDeniedTitle = "동작 권한 필요"
        static let motionPermissionDeniedMessage = "걸음 수를 측정하려면 '동작 및 피트니스' 권한이 필요합니다. 설정에서 허용해 주세요."
        static let scratchBeforeAdTitle = "광고를 보고\n복권 1장을 받아보세요"
        static let scratchBeforeAdDesc = "광고를 보고 복권을 긁으면 포인트를 받을 수 있어요"
        static let scratchAfterAdTitle = "복권 1장을 받았어요"
        static let scratchAfterAdDesc = "복권을 긁고 당첨 포인트를 확인해 보세요"
        static let showAndScratch = "광고보고 복권긁기 >"
        static let scratchHere = "여기를 긁어보세요"
        static let youHaveWon = "당첨되었습니다!"
        static let _getWinPointMessage = "P를 받았어요"
        static let getWinPointFailureMessage = "보상 수령에 실패했습니다. 다시 시도해 주세요."
        static let missionExitWarning = "복권을 긁어 포인트를 획득해주세요!\n긁지 않고 화면을 나가시면\n광고를 다시 시청하셔야 복권을 받아요."
        static let serviceInfo = "서비스 안내"
        static let faq = "FAQ"
        static let inquiry = "문의"
        static let noMailClient = "메일을 보낼 수 있는 앱이 설치되어 있지 않습니다."
        static let faqDesc = "자주 묻는 질문에서\n궁금한 내용을 확인해 보세요."
        static let statistics = "통계"
        static let yesterday = "이번 주"
        static let oneWeekAgo = "1주 전"
        static let twoWeekAgo = "2주 전"
        static let latest = "최근"
        static let oneWeekPerDayAvg = "7일간 하루 평균"
        static let didWalk = "걸었어요."
        static let statisticsDesc01 = "• 통계 그래프는 일주일 단위로 표시됩니다."
        static let statisticsDesc02 = "• 주간 평균 걸음 수는 전날부터 일주일의 걸음 수로 계산됩니다."
        static let stepDiffDesc = "걸음 수가 실제와 다른가요?"
        static let doNotShowToday = "오늘 하루 보지 않기"
        static let waitingAdAvailable = "광고를 준비중입니다."
        static let noAvailableAdTime = "참여 시간이 지났어요. 다음 시간에 도전해주세요."
        static let serverError       = "일시적인 오류가 발생했습니다. 잠시 후 다시 시도해주세요."
        static let noAvailableAdDesc = "현재 시청 가능한 광고가 없습니다.\n잠시 후 참여해주세요."
        static let getRouleteTicket = "광고 보고 룰렛 참여권 받기"
        static let tryNextTime = "다음 시간에 도전해주세요"
        static let showAdForReward = "클릭하고 페이지 방문하여 보상 받아요."
        static let mustOverFiveSeconds = "페이지 5초 이상 머물러야 보상 획득 가능!"
        static let rouletteSection = "룰렛"
        static let lotterySection  = "복권"
        static let congratulation = "축하합니다!"
        static let getRouletteTicketSuccess = "룰렛 참여권을 받았어요.\n룰렛을 돌리고 포인트를 받아보세요."
        static let doRoulette = "룰렛 돌리기"
        static let processErrorOccurred = "오류가 발생했습니다. 다시 시도해 주세요."
        static let benefitInfoText: [String] = [
            "포인트 획득 게임 참여 시 광고 시청 후에 참여할 수 있습니다.",
            "광고의 종류, 길이 등은 랜덤하게 보여집니다.",
            "포인트 획득 게임은 회사 운영에 따라 일부 내용이 변경되거나 종료될 수 있습니다.",
            "앱을 최신 버전으로 업데이트하지 않는 경우, 포인트 획득 게임 참여가 불가할 수 있으며, 해당 사유로 포인트가 미 지급되는 경우 포인트의 재 지급이 불가할 수 있습니다."
        ]
        
    }
}

enum AppColor {
    static let primaryPurple = Color(red: 116/255.0, green: 74/255.0, blue: 232/255.0)
    static let secondaryGreen = Color(red: 55/255.0, green: 210/255.0, blue: 67/255.0)
    static let stepProgressMarked = Color(red: 237/255.0, green: 228/255.0, blue: 255/255.0)
    
    static let graySubText34 = Color(red: 34/255.0, green: 34/255.0, blue: 34/255.0)
    static let grayButtonText68 = Color(red: 68/255.0, green: 68/255.0, blue: 68/255.0)
    static let graySummaryText102 = Color(red: 102/255.0, green: 102/255.0, blue: 102/255.0)
    static let grayTextField148 = Color(red: 148/255.0, green: 148/255.0, blue: 148/255.0)
    static let grayTextField170 = Color(red: 170/255.0, green: 170/255.0, blue: 170/255.0)
    static let grayBorder204 = Color(red: 204/255.0, green: 204/255.0, blue: 204/255.0)
    static let grayBorderBg219 = Color(red: 219/255.0, green: 219/255.0, blue: 219/255.0)
    static let grayDisalbeBg221 = Color(red: 221/255.0, green: 221/255.0, blue: 221/255.0)
    static let grayBorderNBg238 = Color(red: 238/255.0, green: 238/255.0, blue: 238/255.0)
    static let grayBorderEEEDF5 = Color(red: 238/255.0, green: 237/255.0, blue: 245/255.0)
    static let grayTextField242 = Color(red: 242/255.0, green: 242/255.0, blue: 242/255.0)
    static let grayButton244 = Color(red: 244/255.0, green: 244/255.0, blue: 244/255.0)
    static let grayBgDivider248 = Color(red: 248/255.0, green: 248/255.0, blue: 248/255.0)
    
    static let toastBgColor = Color(red: 34/255.0, green: 34/255.0, blue: 34/255.0, opacity: 0.9)
    
    static let successGreen = Color(red: 116/255.0, green: 74/255.0, blue: 232/255.0)
    static let warningRed = Color(red: 255/255.0, green: 0/255.0, blue: 60/255.0)
    
    static let statsTabBlue = Color(red: 51/255.0, green: 0/255.0, blue: 255/255.0)
    static let startBarChart = Color(red: 146/255.0, green: 107/255.0, blue: 255/255.0)
    static let endBarChart = Color(red: 171/255.0, green: 141/255.0, blue: 255/255.0)
    
}
