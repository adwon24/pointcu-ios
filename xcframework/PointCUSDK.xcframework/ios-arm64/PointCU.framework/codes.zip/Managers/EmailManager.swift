//
//  EmailManager.swift
//  PointCU
//
//  Created by Juno Yoon on 4/20/26.
//

import SwiftUI

enum EmailManager {
    static func sendContactEmail(userId: String) {
        let recipientEmail = "support@pointcu.com"
        
        let subject = "CU걷기 서비스 문의"
        
        let body = """
         • 문의하는 서비스 명 : CU걷기
         • 문의자 회원 ID : \(userId)
         • 문의자 이용 제휴사코드 : 35
        
        위 내용은 문의하시는 이용자의 정보를 확인하기
        위하여 반드시 필요한 정보입니다.
        삭제하지 마시고 아래 본문에 이어서 문의 내용을
        작성해 주세요.
        답변은 영업일 기준 2~3일 정도 소요됩니다.
        ================================
        
        
        
        """
        
        guard let encodedSubject = subject.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let encodedBody = body.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            return
        }
        
        let urlString = "mailto:\(recipientEmail)?subject=\(encodedSubject)&body=\(encodedBody)"
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            CULog("메일을 보낼 수 있는 앱이 설치되어 있지 않습니다.")
            OverlayManager.shared.showSingle(
                message: Constants.Text.noMailClient,
                confirmTitle: Constants.Text.textConfirm,
                confirmAction: {}
            )
        }
    }
}
