//
//  StepManager.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/4/26.
//
//  ===== 버그 수정 내역 =====
//
//  [Bug D] init에서 isTrackingEnabled 로드 시 didSet 경쟁 조건
//    - 문제: self.isTrackingEnabled = ... 대입 순간 didSet이 발화해 handleToggle이 호출됨
//            finalizePastSessions 실행 전이므로 세션 상태가 불완전한 채로 토글 로직이 동작
//    - 수정: _isTrackingEnabled에 직접 write해 didSet을 우회하고,
//            init이 완전히 끝난 후 resumeTracking을 명시적으로 1회만 호출
//
//  [Bug E] finalizePastSessions에서 오늘 ON 세션이 있어도 EmergencyKey를 삭제
//    - 문제: needsSave == true면 조건 없이 EmergencyKey를 removeObject → 재시작 시 UI가 0으로 리셋
//    - 수정: 오늘 날짜에 활성(미종료) 세션이 없을 때만 EmergencyKey 삭제
//
//  [Bug F] 자정 통과 후 새 세션 start가 now(알림 수신 시각)로 설정
//    - 문제: NSCalendarDayChanged 알림은 자정 이후 수백ms~수초 지연 가능
//            → 자정~알림 수신 사이에 걸은 걸음이 어느 세션에도 속하지 않음
//    - 수정: 새 세션 start와 startLiveUpdates 기준을 Calendar.startOfDay(today)로 변경
//
//  [Bug G] updateTodayTotal 내부에서 steps==nil 세션마다 Task를 띄워 재귀 호출
//    - 문제: 동시에 여러 nil 세션이 있으면 중복 fetch + 재귀 Task 누적
//    - 수정: nil 세션들을 호출 시점에 async let으로 일괄 병렬 fetch 후 채우고,
//            이미 fetch 중인 index는 fetchingSessionIndices Set으로 중복 차단
//
//  [Bug H] backfillMissingDays가 어디서도 호출되지 않음 (데드코드)
//    - 문제: 며칠간 앱을 안 열었다가 재시작하면 그 기간 걸음 데이터가 누락됨
//    - 수정: finalizePastSessions 완료 직후(init 흐름) 및 포그라운드 복귀 시(StepSyncManager)
//            두 지점에서 호출. 포그라운드 콜은 StepSyncManager가 isReadyForSync 구독 후 호출.
//            backfillMissingDays 자체에도 isBackfilling guard를 추가해 중복 실행 방지.
//
//  [Bug I] resumeTracking의 safeStartDate가 현재 세션 start보다 10초 이전으로 설정됨
//    - 문제: ON→OFF→ON 다중 세션 환경에서 OFF 구간 걸음이 현재 세션 걸음으로 혼입될 수 있음
//            CMPedometer는 ON/OFF를 모르고 시간 범위 내 전체 걸음을 반환하기 때문
//    - 수정: safeStartDate를 sessionStartDate와 midnight 중 max값으로 변경(버퍼 제거)
//            단, 완전히 새 세션이면 어차피 lastLiveSteps=0이므로 전진 법칙이 최종 방어

import UIKit
import Foundation

import CoreMotion
import Combine

@MainActor
class StepManager: ObservableObject {
    static let shared = StepManager()

    // CMPedometer 인스턴스를 역할별로 분리
    // - liveUpdater : startUpdates 전용 (실시간 스트림)
    // - queryFetcher: queryPedometerData 전용 (소급/과거 단발 쿼리)
    // 같은 인스턴스에서 두 API를 동시에 실행하면 iOS 내부 충돌로
    // query 콜백이 nil/error를 반환하는 버그가 있어 완전히 분리함.
    private let liveUpdater  = CMPedometer()
    private let queryFetcher = CMPedometer()

    // 모든 날짜 계산에 로컬 타임존을 명시적으로 강제.
    // Calendar.current는 환경(시뮬레이터/기기)에 따라 timeZone이 UTC로 잡혀
    // CMPedometer(로컬 시간 기준)와 날짜 범위가 어긋나 CMError 104 발생.
    private var localCalendar: Calendar {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone.current
        return cal
    }

    private let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard

    let scrollToTopPublisher = PassthroughSubject<Void, Never>()

    // UI에서 관찰할 변수
    @Published var todaySteps: Int = 0
    @Published var todayDuration: TimeInterval = 0
    @Published var todayDistance: Double = 0.0
    @Published var todayCalories: Double = 0.0
    
    // tracking OFF 시 마지막 값 저장 (앱 재시작 후에도 유지)
    @Published var frozenSteps: Int = 0
    @Published var frozenDistance: Double = 0.0
    @Published var frozenCalories: Double = 0.0

    // [Bug D] didSet 경쟁 조건 수정:
    // init 중에는 didSet이 발화하지 않도록 _isTrackingEnabled에 직접 write한다.
    // 사용자가 UI 토글을 조작할 때만 didSet → handleToggle 경로를 탄다.
    @Published var isTrackingEnabled: Bool = false {
        didSet {
            // trackingStateKey는 항상 저장 (init 완료 전이라도)
            userDefaults.set(isTrackingEnabled, forKey: Constants.Key.trackingStateKey)
            // init 완료 전에는 나머지 토글 부작용을 일으키지 않는다.
            guard isInitialized else { return }
            CULog("[StepManager] isTrackingEnabled 변경: \(oldValue) → \(isTrackingEnabled) | 호출 스택: \(Thread.callStackSymbols.prefix(5).joined(separator: "\n"))")
            if oldValue != isTrackingEnabled {
                if isTrackingEnabled {
                    if userDefaults.object(forKey: Constants.Key.trackingStartDateKey) == nil {
                        userDefaults.set(Date(), forKey: Constants.Key.trackingStartDateKey)
                    }
                } else {
                    // tracking OFF — 현재 값을 frozen으로 저장 (날짜 포함)
                    frozenSteps    = todaySteps
                    frozenDistance = todayDistance
                    frozenCalories = todayCalories
                    let today = Calendar.current.startOfDay(for: Date())
                    userDefaults.set(frozenSteps,    forKey: Constants.Key.frozenStepsKey)
                    userDefaults.set(frozenDistance, forKey: Constants.Key.frozenDistanceKey)
                    userDefaults.set(frozenCalories, forKey: Constants.Key.frozenCaloriesKey)
                    userDefaults.set(today,          forKey: Constants.Key.frozenDateKey)
                }
                handleToggle(isOn: isTrackingEnabled)
            }
        }
    }

    var todaySessions: [TrackingSession] = []
    private var lastLiveSteps: Int = 0
    private var isNewUserSession: Bool = false  // resetForUserChange 후 자정 소급 방지

    @Published private(set) var isReadyForSync: Bool = false

    // [Bug D] init 완료 여부 플래그 — didSet 가드에 사용
    private var isInitialized: Bool = false

    // [Bug G] 중복 fetch 방지용 Set
    private var fetchingSessionIndices: Set<Int> = []

    // [Bug H] 중복 backfill 방지 플래그
    private(set) var isBackfilling: Bool = false

    private init() {
        // 1. 오늘 세션을 디스크에서 즉시 로드
        // 단 오늘 키에 어제 세션이 잘못 저장된 경우 미리 교정
        self.fixMisdatedSessionsIfNeeded()
        self.loadTodaySessions()

        // 2. [Bug D] 저장된 추적 상태를 _isTrackingEnabled에 직접 write → didSet 우회
        _isTrackingEnabled = Published(initialValue: userDefaults.bool(forKey: Constants.Key.trackingStateKey))

        // tracking OFF 상태로 재시작 시 저장된 frozen 값 복원
        // 단 날짜가 변경된 경우 0으로 초기화 (자정에 처리 못한 경우 대비)
        if !userDefaults.bool(forKey: Constants.Key.trackingStateKey) {
            let today      = Calendar.current.startOfDay(for: Date())
            let savedDate  = userDefaults.object(forKey: Constants.Key.frozenDateKey) as? Date
            let isSameDay  = savedDate.map { Calendar.current.isDate($0, inSameDayAs: today) } ?? false

            if isSameDay {
                frozenSteps    = userDefaults.integer(forKey: Constants.Key.frozenStepsKey)
                frozenDistance = userDefaults.double(forKey: Constants.Key.frozenDistanceKey)
                frozenCalories = userDefaults.double(forKey: Constants.Key.frozenCaloriesKey)
            } else {
                // 날짜 변경 — frozen 값 초기화
                frozenSteps    = 0
                frozenDistance = 0.0
                frozenCalories = 0.0
                userDefaults.set(0,     forKey: Constants.Key.frozenStepsKey)
                userDefaults.set(0.0,   forKey: Constants.Key.frozenDistanceKey)
                userDefaults.set(0.0,   forKey: Constants.Key.frozenCaloriesKey)
                userDefaults.set(today, forKey: Constants.Key.frozenDateKey)
            }
        }

        self.updateTodayTotal(currentSteps: 0, currentDistance: 0.0)

        setupMidnightObserver()

        Task {
            self.cleanupOldData()
            await self.finalizePastSessions()

            // finalizePastSessions가 날짜 넘김을 감지해 디스크에 오늘 복구 세션을 기록했을 수 있다.
            // 그 내용을 메모리(todaySessions)에 반영하기 위해 여기서 다시 로드한다.
            // (init 첫 loadTodaySessions 시점엔 오늘 키가 없었으므로 todaySessions = [] 상태)
            await MainActor.run {
                self.loadTodaySessions()
            }

            // [Bug H] finalizePastSessions 완료 직후 누락 일자 복구
            await self.backfillMissingDays()

            // [Bug D] 모든 준비가 끝난 후 단 한 번만 추적 재개
            // 권한이 .authorized인 경우에만 실행.
            // notDetermined / denied 상태에서 쿼리하면 CMError 104 반환.
            // 권한 팝업은 MainFooterView.handleToggleOn에서 토글 ON 시점에 처리함.
            if self.isTrackingEnabled && CMPedometer.authorizationStatus() == .authorized {
                await MainActor.run {
                    self.resumeTracking()
                }
            } else if self.isTrackingEnabled {
                print("[StepManager] 모션 권한 미확보 상태 — resumeTracking 스킵")
            }

            await MainActor.run {
                // [Bug D] init이 완전히 끝난 후에야 didSet 가드를 해제
                self.isInitialized = true
                self.isReadyForSync = true

                // init Task 완료 후 isTrackingEnabled=true이면서 아직 추적 안 된 경우 복구
                // (권한 허용이 init Task 실행 도중에 일어난 경우)
                self.resumeTrackingIfNeeded()
            }
        }
    }

    // MARK: - 오늘 세션 추적 재개 및 소급 적용

    private func resumeTracking() {
        // 비즈니스 가드: 활성(미종료) 세션이 없으면 복구 스킵
        guard let lastSession = todaySessions.last, lastSession.end == nil else {
            // CULog("[StepManager] 현재 OFF 상태. 복구 스킵.")
            return
        }

        let sessionStartDate = lastSession.start

        // EmergencyKey(블랙박스) 즉시 복구 → UI에 바로 노출
        // 단, 날짜가 넘어간 복구 세션의 경우 EmergencyKey는 어제 것이므로 사용하지 않음
        let midnight = self.localCalendar.startOfDay(for: Date())
        let todayKey  = Date().toString(format: "yyyy-MM-dd")
        let emergencyDateKey = userDefaults.string(forKey: Constants.Key.stepEmergencyDateKey)
        // EmergencyKey가 오늘 날짜로 저장된 경우에만 사용 (어제 것이면 0으로)
        let isEmergencyFromToday = emergencyDateKey == todayKey
        let savedEmergencySteps = isEmergencyFromToday ? userDefaults.integer(forKey: Constants.Key.stepEmergencyKey) : 0

        if savedEmergencySteps > 0 {
            self.lastLiveSteps = savedEmergencySteps
            if let lastIdx = todaySessions.indices.last {
                self.todaySessions[lastIdx].steps = self.lastLiveSteps
            }
            self.updateTodayTotal(
                currentSteps: self.lastLiveSteps,
                currentDistance: estimateDistance(from: self.lastLiveSteps)
            )
        }

        Task { @MainActor in
            // safeStartDate: 세션 start와 자정 중 큰 값.
            // 날짜 넘김 복구 세션이면 sessionStartDate == midnight이므로
            // 자정부터 현재까지 전체 걸음을 소급 쿼리함.
            let safeStartDate = max(sessionStartDate, midnight)

            // 핵심 순서: 소급 쿼리 먼저 → UI 반영 → startLiveUpdates 마지막
            // startLiveUpdates(startUpdates)와 fetchPedometerData(queryPedometerData)를
            // 같은 CMPedometer 인스턴스에서 동시에 실행하면 iOS 내부 충돌로
            // query 콜백이 nil/error를 반환해 소급 걸음이 0으로 나오는 버그가 있음.

            // Step 1: 소급 쿼리 완료 (safeStartDate == 현재 세션 시작 기준)
            // safeStartDate = max(sessionStart, midnight) 이므로
            // 현재 세션 시작 이후 걸음만 반환됨 → 이전 세션과 중복 없음
            let recoveredData = await self.fetchPedometerData(from: safeStartDate, to: Date())

            // Step 2: lastLiveSteps = 현재 세션 소급값으로 세팅
            // updateTodayTotal이 이전 세션 합계와 합산하므로 현재 세션 단독값만 유지
            if recoveredData.steps > self.lastLiveSteps {
                self.lastLiveSteps = recoveredData.steps
                if let lastIdx = self.todaySessions.indices.last {
                    self.todaySessions[lastIdx].steps = self.lastLiveSteps
                    self.saveTodaySessions()
                }
            }
            self.updateTodayTotal(currentSteps: self.lastLiveSteps, currentDistance: recoveredData.distanceKm)
            // CULog("[StepManager] 세션 복구 완료 (현재세션: \(self.lastLiveSteps)보, 소급시작: \(safeStartDate))")

            // Step 3: 소급 완료 후 라이브 업데이트 시작
            // startDate = safeStartDate(현재 세션 시작)로 지정해야
            // 콜백이 현재 세션 분만 반환함
            self.startLiveUpdates(from: safeStartDate)
        }
    }

    // MARK: - 오래된 데이터 청소 (Garbage Collection)

    private func cleanupOldData() {
        let calendar = self.localCalendar
        let today = calendar.startOfDay(for: Date())

        // 동기화 마커 30일 초과분 삭제
        guard let markerRetentionLimit = calendar.date(byAdding: .day, value: -30, to: today) else { return }
        let markerLimitString = markerRetentionLimit.toString(format: "yyyy-MM-dd")

        var syncedDates = userDefaults.stringArray(forKey: Constants.Key.syncedDatesKey) ?? []
        let originalMarkerCount = syncedDates.count
        syncedDates = syncedDates.filter { $0 >= markerLimitString }
        if syncedDates.count != originalMarkerCount {
            userDefaults.set(syncedDates, forKey: Constants.Key.syncedDatesKey)
//            print("[StepManager] 30일 경과 동기화 마커 \(originalMarkerCount - syncedDates.count)건 삭제")
        }

        // 세션 히스토리 30일 초과분 삭제
        guard let rawRetentionLimit = calendar.date(byAdding: .day, value: -30, to: today) else { return }
        let rawLimitString = rawRetentionLimit.toString(format: "yyyy-MM-dd")

        var history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]
        let originalRawCount = history.count
        history = history.filter { $0.key >= rawLimitString }
        if history.count != originalRawCount {
            if let encoded = try? JSONEncoder().encode(history) {
                userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
            }
//            print("[StepManager] 30일 경과 세션 데이터 \(originalRawCount - history.count)건 삭제")
        }
    }

    // MARK: - 자정 경계 마감 및 진실 덮어쓰기 (병렬 최적화)

    // init 시 오늘 키에 어제 세션이 잘못 저장된 경우 동기적으로 교정
    private func fixMisdatedSessionsIfNeeded() {
        let todayKey      = Date().toString(format: "yyyy-MM-dd")
        let todayMidnight = self.localCalendar.startOfDay(for: Date())

        var history = userDefaults.decode([String: [TrackingSession]].self,
                        forKey: Constants.Key.stepHistoryKey) ?? [:]

        guard let wrongSessions = history[todayKey], !wrongSessions.isEmpty else { return }

        let allFromYesterday = wrongSessions.allSatisfy { $0.start < todayMidnight }
        CULog("[StepManager] fixMisdated | allFromYesterday=\(allFromYesterday)")
        guard allFromYesterday else { return }

        let yesterdayKey = self.localCalendar.date(byAdding: .day, value: -1, to: todayMidnight)!
            .toString(format: "yyyy-MM-dd")
        CULog("[StepManager] init: 오늘 키에 어제 세션 감지 → \(yesterdayKey) 키로 이동")
        // 어제 키에 이미 데이터가 있으면 병합하지 않고 오늘 키만 삭제
        // (병합 시 중복으로 두 배가 될 수 있음)
        if history[yesterdayKey] == nil {
            history[yesterdayKey] = wrongSessions
        } else {
            CULog("[StepManager] 어제 키에 이미 데이터 존재 → 오늘 키만 삭제 (병합 안 함)")
        }
        history.removeValue(forKey: todayKey)

        if let encoded = try? JSONEncoder().encode(history) {
            userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
        }
    }

    private func finalizePastSessions() async {
        let todayKey = Date().toString(format: "yyyy-MM-dd")
        var history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]
        var needsSave = false

        // 오늘 날짜 키에 어제 세션이 잘못 저장된 경우 교정
        let todayMidnight = self.localCalendar.startOfDay(for: Date())
        if let wrongSessions = history[todayKey], !wrongSessions.isEmpty {
            let allFromYesterday = wrongSessions.allSatisfy { $0.start < todayMidnight }
            if allFromYesterday {
                let yesterdayKey = self.localCalendar.date(byAdding: .day, value: -1, to: todayMidnight)!
                    .toString(format: "yyyy-MM-dd")
                CULog("[StepManager] 오늘 키에 어제 세션 감지 → \(yesterdayKey) 키로 이동")
                // 어제 키에 이미 데이터가 있으면 병합하지 않고 오늘 키만 삭제
                if history[yesterdayKey] == nil {
                    history[yesterdayKey] = wrongSessions
                } else {
                    CULog("[StepManager] 어제 키에 이미 데이터 존재 → 오늘 키만 삭제 (병합 안 함)")
                }
                history.removeValue(forKey: todayKey)
                needsSave = true
            }
        }

        let fallbackSteps = userDefaults.integer(forKey: Constants.Key.stepEmergencyKey)

        var pendingQueries: [(dateKey: String, sessionIndex: Int, start: Date, end: Date)] = []

        // 1. 과거 날짜의 미종료 세션에 임시 마감 처리
        for (dateKey, sessions) in history {
            if dateKey == todayKey { continue }

            var updatedSessions = sessions
            for i in 0..<updatedSessions.count {
                if updatedSessions[i].end == nil {
                    let start = updatedSessions[i].start
                    let endOfPastDay = self.localCalendar.startOfDay(for: start).addingTimeInterval(86399)

                    updatedSessions[i].end = endOfPastDay
                    updatedSessions[i].steps = fallbackSteps
                    needsSave = true

                    pendingQueries.append((dateKey, i, start, endOfPastDay))
                }
            }
            history[dateKey] = updatedSessions
        }

        // 2. 병렬 쿼리로 실제 걸음 수 덮어쓰기
        if !pendingQueries.isEmpty {
            typealias QueryResult = (dateKey: String, sessionIndex: Int, exactSteps: Int)

            await withTaskGroup(of: QueryResult.self) { group in
                for query in pendingQueries {
                    group.addTask {
                        let data = await self.fetchPedometerData(from: query.start, to: query.end)
                        return (query.dateKey, query.sessionIndex, data.steps)
                    }
                }
                for await result in group {
                    if result.exactSteps > 0 {
                        history[result.dateKey]?[result.sessionIndex].steps = result.exactSteps
                    }
                }
            }
        }

        // 3. 과거 날짜 세션 단일화 (Flatten) + end 교정 (23:59:59)
        for (dateKey, sessions) in history {
            if dateKey == todayKey { continue }
                let totalStepsForDay = sessions.reduce(0) { $0 + ($1.steps ?? 0) }
                if let firstStart = sessions.first?.start {
                let endOfDay = self.localCalendar.startOfDay(for: firstStart).addingTimeInterval(86399)
                // 세션이 여러 개이거나, end가 23:59:59가 아닌 경우 단일화 및 교정
                let needsNormalize = sessions.count > 1
                    || sessions.last?.end != endOfDay
                if needsNormalize {
                    let summarySession = TrackingSession(
                        start: firstStart,
                        end: endOfDay,
                        steps: totalStepsForDay
                    )
                    history[dateKey] = [summarySession]
                    needsSave = true
                }
            }
        }

        // 4. 단 한 번만 저장
        if needsSave {
            if let encoded = try? JSONEncoder().encode(history) {
                userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
            }

            // [Bug E] 오늘 날짜에 활성(미종료) 세션이 없을 때만 EmergencyKey 삭제
            // 활성 세션이 있는 상태에서 삭제하면 앱 재시작 시 UI가 0으로 순간 리셋됨
            let hasTodayActiveSession = history[todayKey]?.last?.end == nil
            if !hasTodayActiveSession {
                userDefaults.removeObject(forKey: Constants.Key.stepEmergencyKey)
            }

//            CULog("[StepManager] 과거 미종료 세션 마감 및 단일화(Flatten), 실데이터 덮어쓰기 완료")
        }

        // [날짜 넘김 버그 수정 1]
        // 앱이 종료된 채로 날짜가 넘어간 경우:
        //   - 어제 세션은 위에서 마감됨
        //   - 오늘 날짜 세션은 UserDefaults에 존재하지 않음
        //   - isTrackingEnabled == true 이지만 todaySessions == []
        // UserDefaults(디스크)에만 복구 세션을 기록해 둔다.
        // todaySessions(메모리)에는 직접 쓰지 않는다 — init Task가
        // 이 함수 완료 후 loadTodaySessions()를 다시 호출해서 올린다.
        if isTrackingEnabled && history[todayKey] == nil {
            let midnight = self.localCalendar.startOfDay(for: Date())
            let recoverySession = TrackingSession(start: midnight, end: nil, steps: nil)

            // 최신 history를 다시 읽어서 덮어쓴다
            // (위 needsSave 저장과 충돌하지 않도록 별도 read-modify-write)
            var latestHistory = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]
            latestHistory[todayKey] = [recoverySession]
            if let encoded = try? JSONEncoder().encode(latestHistory) {
                userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
            }
            // CULog("[StepManager] 날짜 넘김 감지: 오늘 자정 기준 복구 세션을 디스크에 기록")
        }
    }

    // MARK: - 누락된 공백기 병렬 복구 (Fast Backfill)
    //
    // [Bug H] 호출 시점 두 곳:
    //   1) init Task 내 finalizePastSessions() 완료 직후
    //      → 앱을 오래 안 열었다가 켰을 때 그 기간 걸음을 복구
    //   2) StepSyncManager에서 isReadyForSync == true를 수신한 직후 (포그라운드 복귀 포함)
    //      → 동기화 전에 최신 상태를 확보
    //   isBackfilling 플래그로 동시 중복 실행을 방지한다.

    func backfillMissingDays() async {
        guard isTrackingEnabled else { return }
        guard !isBackfilling else {
            CULog("[StepManager] backfill 이미 실행 중. 스킵.")
            return
        }

        isBackfilling = true

        let calendar = self.localCalendar
        let today = calendar.startOfDay(for: Date())
        let todayKey = today.toString(format: "yyyy-MM-dd")
        var history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]

        let syncedDatesSet = Set(userDefaults.stringArray(forKey: Constants.Key.syncedDatesKey) ?? [])
        let trackingStartDate = userDefaults.object(forKey: Constants.Key.trackingStartDateKey) as? Date ?? Date()
        let trackingStartDay = calendar.startOfDay(for: trackingStartDate)

        // 오늘을 제외한 날짜 중 가장 최근 기록이 있는 날 확인
        let sortedPastDates = history.keys
            .filter { $0 != todayKey }
            .sorted()

        // 히스토리가 아예 없으면 trackingStartDay부터 어제까지를 탐색
        let searchFrom: Date
        if let lastEntryDateString = sortedPastDates.last {
            let fmt = DateFormatter()
            fmt.dateFormat = "yyyy-MM-dd"
            fmt.timeZone = TimeZone.current
            searchFrom = fmt.date(from: lastEntryDateString).flatMap {
                calendar.date(byAdding: .day, value: 1, to: $0)
            } ?? trackingStartDay
        } else {
            searchFrom = trackingStartDay
        }

        // 복구 대상 날짜 리스트업 (trackingStartDay 이후, 동기화 안됨, 기록 없음)
        var targetDates: [Date] = []
        var checkDate = searchFrom
        while checkDate < today {
            let dateKey = checkDate.toString(format: "yyyy-MM-dd")
            if checkDate >= trackingStartDay
                && !syncedDatesSet.contains(dateKey)
                && history[dateKey] == nil {
                targetDates.append(checkDate)
            }
            checkDate = calendar.date(byAdding: .day, value: 1, to: checkDate)!
        }

        guard !targetDates.isEmpty else { isBackfilling = false; return }

        typealias RecoveredSession = (dateKey: String, session: TrackingSession)

        await withTaskGroup(of: RecoveredSession?.self) { group in
            for targetDate in targetDates {
                group.addTask {
                    let startOfDay = targetDate
                    let endOfDay = startOfDay.addingTimeInterval(86399)
                    let data = await self.fetchPedometerData(from: startOfDay, to: endOfDay)
                    guard data.steps > 0 else { return nil }
                    let dateKey = targetDate.toString(format: "yyyy-MM-dd")
                    let newSession = TrackingSession(start: startOfDay, end: endOfDay, steps: data.steps)
                    return (dateKey, newSession)
                }
            }

            var needsSave = false
            for await result in group {
                if let result = result {
                    history[result.dateKey] = [result.session]
                    needsSave = true
                    // CULog("[StepManager] 누락 일자 병렬 복구 완료: \(result.dateKey)")
                }
            }

            if needsSave {
                if let encoded = try? JSONEncoder().encode(history) {
                    userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
                }
            }
        }
        isBackfilling = false
    }

    // MARK: - 사용자 전환 초기화

    /// clearUserData() 호출 시 — 추적 중단 + 로컬 세션 데이터 삭제
    func resetForUserChange() {
        // 추적 중단 (didSet → handleToggle(isOn: false) → stopLiveUpdates)
        isTrackingEnabled = false

        // 메모리 초기화
        todaySessions = []
        lastLiveSteps = 0
        isNewUserSession = true  // 다음 ON 시 자정 소급 방지

        // UserDefaults 초기화
        userDefaults.removeObject(forKey: Constants.Key.trackingStateKey)
        userDefaults.removeObject(forKey: Constants.Key.trackingStartDateKey)
        userDefaults.removeObject(forKey: Constants.Key.stepHistoryKey)
        userDefaults.removeObject(forKey: Constants.Key.syncedDatesKey)
        userDefaults.removeObject(forKey: Constants.Key.stepEmergencyKey)

        // CULog("[StepManager] 사용자 전환 — 세션 데이터 초기화 완료")
    }

    // MARK: - 자정 경계 감시 (Zombie Mode Defense)

    private func setupMidnightObserver() {
        NotificationCenter.default.addObserver(
            forName: .NSCalendarDayChanged,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            // CULog("[StepManager] 자정 통과 감지! 백그라운드 자동 마감 및 새 세션 시작.")

            Task { @MainActor in
                // 자정 전까지 활성이었던 세션을 자정 시각으로 마감
                // liveUpdater 먼저 중단 — 자정 이후 콜백이 어제 세션을 오늘 키에 저장하는 것 방지
                self.liveUpdater.stopUpdates()

                // saveTodaySessions()는 현재 날짜(오늘=새날)로 저장하므로
                // 어제 날짜 키로 직접 저장해야 함
                let midnight = self.localCalendar.startOfDay(for: Date())
                let yesterdayKey = self.localCalendar.date(byAdding: .day, value: -1, to: midnight)!
                    .toString(format: "yyyy-MM-dd")

                if let lastIdx = self.todaySessions.indices.last,
                   self.todaySessions[lastIdx].end == nil {
                    // 어제 세션 마감: end = 23:59:59 (자정이 아닌 어제 마지막 시각)
                    let endOfYesterday = midnight.addingTimeInterval(-1)  // 23:59:59
                    self.todaySessions[lastIdx].end   = endOfYesterday
                    self.todaySessions[lastIdx].steps = self.lastLiveSteps
                    CULog("[StepManager] 자정 세션 마감 | steps=\(self.lastLiveSteps)")

                    // 어제 날짜 키로 직접 저장
                    var history = self.userDefaults.decode([String: [TrackingSession]].self,
                                    forKey: Constants.Key.stepHistoryKey) ?? [:]
                    history[yesterdayKey] = self.todaySessions
                    if let encoded = try? JSONEncoder().encode(history) {
                        self.userDefaults.set(encoded, forKey: Constants.Key.stepHistoryKey)
                    }
                }

                self.cleanupOldData()
                await self.finalizePastSessions()

                await MainActor.run {
                    self.loadTodaySessions()
                    self.updateTodayTotal(currentSteps: 0, currentDistance: 0.0)
                }

                // 자정 리셋 후 frozen 값 초기화 (날이 변경되면 0으로)
                self.frozenSteps    = 0
                self.frozenDistance = 0.0
                self.frozenCalories = 0.0
                self.userDefaults.set(0,   forKey: Constants.Key.frozenStepsKey)
                self.userDefaults.set(0.0, forKey: Constants.Key.frozenDistanceKey)
                self.userDefaults.set(0.0, forKey: Constants.Key.frozenCaloriesKey)
                self.userDefaults.removeObject(forKey: Constants.Key.stepEmergencyDateKey)

                // 자정 리셋 후 미션 데이터 갱신 → StepProgressView 즉시 반영
                await AppDataManager.shared.refreshMainData()

                if self.isTrackingEnabled {
                    await MainActor.run {
                        // [Bug F] 새 세션 start = 오늘 자정 00:00:00
                        // 기존 코드(now)는 알림 지연만큼 걸음이 누락됨
                        let midnight = self.localCalendar.startOfDay(for: Date())

                        self.lastLiveSteps = 0
                        self.userDefaults.set(0, forKey: Constants.Key.stepEmergencyKey)

                        // finalizePastSessions에서 이미 복구 세션이 생성됐을 수 있으므로
                        // 활성 세션이 없을 때만 새 세션 추가
                        if self.todaySessions.last?.end != nil || self.todaySessions.isEmpty {
                            let newSession = TrackingSession(start: midnight, end: nil, steps: nil)
                            self.todaySessions.append(newSession)
                            self.saveTodaySessions()
                        }

                        // startLiveUpdates는 자정 기준으로 시작 (오늘 걸음 전체 소급)
                        self.startLiveUpdates(from: midnight)
                        // CULog("[StepManager] 자정 이후 새 날짜의 연속 추적(New Session)을 시작합니다.")
                    }
                }

//                // CULog("[StepManager] 자정 데이터 분리 완료.")
            }
        }
    }

    // MARK: - 세션 제어 로직

    /// 권한 허용 후 트래킹이 시작되지 않은 경우 보완 호출
    /// isTrackingEnabled=true & authorized & 활성 세션 없을 때만 handleToggle 실행
    func resumeTrackingIfNeeded() {
        guard isTrackingEnabled,
              CMPedometer.authorizationStatus() == .authorized,
              !todaySessions.contains(where: { $0.end == nil }) else { return }
        handleToggle(isOn: true)
    }

    func handleToggle(isOn: Bool) {
        let now = Date()
        
        // CULog("[StepManager] handleToggle isOn=\(isOn) sessions=\(todaySessions.map { "start:\($0.start) end:\($0.end?.description ?? "nil") steps:\($0.steps?.description ?? "nil")" })")
        
        if isOn {
            // 방어: end=nil인 고아 세션 정리 — last만 체크하면 중간 고아 세션이 남을 수 있음
            let hasActiveSession = !todaySessions.isEmpty && todaySessions.last?.end == nil
            if hasActiveSession {
                // CULog("[StepManager] 활성 세션이 이미 존재합니다. 초기화를 건너뜁니다.")
                return
            }
            // end=nil이면서 steps=nil인 고아 세션 제거
            let before = todaySessions.count
            todaySessions.removeAll { $0.end == nil && $0.steps == nil }
            if todaySessions.count != before {
                CULog("[StepManager] 고아 세션 \(before - todaySessions.count)개 제거")
                saveTodaySessions()
            }

            let midnight = self.localCalendar.startOfDay(for: now)

            // 세션 시작 기준 결정:
            // - 날짜 넘김 후 첫 ON (오늘 세션이 아직 없음): 자정부터 ON으로 간주
            //   → ON 상태로 자정을 넘겼으므로 자정부터 걸은 걸음이 이 세션에 속함
            // - 일반 당일 ON: 지금 이 순간부터만 카운팅
            // 신규 사용자 전환 후 첫 ON: 자정 소급 없이 지금 이 순간부터 시작
            // 일반 당일 첫 ON(날짜 넘김): 자정부터 소급
            // 새 설치 또는 clearUserData 후 첫 ON — 히스토리가 전혀 없으면 자정 소급 안 함
            let hasAnyHistory = userDefaults.object(forKey: Constants.Key.stepHistoryKey) != nil
            let isFirstOnAfterRollover = todaySessions.isEmpty && !isNewUserSession && hasAnyHistory
            let sessionStart = isFirstOnAfterRollover ? midnight : now
            isNewUserSession = false  // 플래그 소모

            userDefaults.set(0, forKey: Constants.Key.stepEmergencyKey)
            userDefaults.removeObject(forKey: Constants.Key.stepEmergencyDateKey)
            self.lastLiveSteps = 0

            let newSession = TrackingSession(start: sessionStart, end: nil, steps: nil)
            todaySessions.append(newSession)
            saveTodaySessions()

            self.updateTodayTotal(currentSteps: 0, currentDistance: 0.0)

            // 핵심 순서: 소급 쿼리 먼저 → UI 반영 → startLiveUpdates 마지막
            // startLiveUpdates(startUpdates)와 fetchPedometerData(queryPedometerData)를
            // 같은 CMPedometer 인스턴스에서 동시에 실행하면 iOS 내부 충돌로
            // query 콜백이 nil/error를 반환하는 버그가 있어 인스턴스를 분리함.
            Task { @MainActor in
                // Step 1: sessionStart~지금 소급 쿼리 (ON 구간만)
                // sessionStart = 자정(날짜 넘김) 또는 now(당일 첫 ON)
                // CMPedometer는 이 구간의 걸음만 반환 → 이전 세션과 중복 없음
                let catchupData = await self.fetchPedometerData(from: sessionStart, to: Date())

                // Step 2: UI 반영
                if catchupData.steps > 0 {
                    self.lastLiveSteps = catchupData.steps
                    self.userDefaults.set(self.lastLiveSteps, forKey: Constants.Key.stepEmergencyKey)
                    if let lastIdx = self.todaySessions.indices.last {
                        self.todaySessions[lastIdx].steps = catchupData.steps
                        self.saveTodaySessions()
                    }
                    self.updateTodayTotal(currentSteps: self.lastLiveSteps, currentDistance: catchupData.distanceKm)
                    print("[StepManager] ON 소급 복구: \(catchupData.steps)보 (\(sessionStart) 기준)")
                }

                // Step 3: 소급 완료 후 라이브 업데이트 시작
                // startDate = sessionStart → 콜백 numberOfSteps가 이 세션 구간만 반환
                self.startLiveUpdates(from: sessionStart)
            }

        } else {
            if let lastIdx = todaySessions.indices.last, todaySessions[lastIdx].end == nil {
                todaySessions[lastIdx].end = now
                // steps=0이면 의미없는 세션 — 제거
                if lastLiveSteps > 0 {
                    todaySessions[lastIdx].steps = lastLiveSteps
                    saveTodaySessions()
                } else {
                    todaySessions.removeLast()
                    saveTodaySessions()
                    CULog("[StepManager] steps=0 세션 제거 (의미없는 세션)")
                }
            }
            liveUpdater.stopUpdates()
            // EmergencyKey는 삭제하지 않음 — OFF 후 재시작 시 resumeTracking에서 복구에 사용
            // (삭제 시 앱 재시작 후 소급 쿼리만으로 복구 → CMPedometer 오차 발생 가능)
        }
    }

    private func startLiveUpdates(from startDate: Date) {
        // 시뮬레이터는 CMPedometer 실시간 업데이트 미지원
        #if targetEnvironment(simulator)
        print("[StepManager] 시뮬레이터 — startLiveUpdates 스킵")
        return
        #endif
        guard CMPedometer.isStepCountingAvailable() else { return }

        liveUpdater.stopUpdates()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self = self else { return }

            self.liveUpdater.startUpdates(from: startDate) { data, error in
                guard let data = data, error == nil else { return }

                Task { @MainActor in
                    let newSteps = data.numberOfSteps.intValue

                    // 전진 법칙: 감소값은 수용하지 않음
                    if newSteps > self.lastLiveSteps {
                        self.lastLiveSteps = newSteps
                        self.userDefaults.set(self.lastLiveSteps, forKey: Constants.Key.stepEmergencyKey)
                        self.userDefaults.set(Date().toString(format: "yyyy-MM-dd"), forKey: Constants.Key.stepEmergencyDateKey)

                        if let lastIdx = self.todaySessions.indices.last {
                            self.todaySessions[lastIdx].steps = newSteps
                            self.saveTodaySessions()  // 앱 강제 종료 시에도 최신 steps 보존
                        }

                        let dist = (data.distance?.doubleValue ?? 0.0) / 1000.0
                        self.updateTodayTotal(currentSteps: newSteps, currentDistance: dist)
                    }
                }
            }
        }
    }

    // MARK: - 오늘 합계 계산

    // duration은 걸음 수 기반으로 계산.
    // ON 시간 합산 방식은 step=0일 때도 시간이 누적되는 문제가 있음.
    // 걸음 수 기반이면 step=0 → duration=0이 자연스럽게 보장됨.

    private func updateTodayTotal(currentSteps: Int, currentDistance: Double) {
//        let _sessionLog = todaySessions.map { s -> String in
//            let e = s.end.map { String(describing: $0) } ?? "nil"
//            let st = s.steps.map { String($0) } ?? "nil"
//            return "[end:\(e) steps:\(st)]"
//        }.joined(separator: ", ")
//        CULog("[StepManager] updateTodayTotal | currentSteps=\(currentSteps) sessions=[\(_sessionLog)]")
        //CULog("[StepManager] updateTodayTotal | sessions=\(todaySessions.map { \"start:\($0.start) end:\(String(describing: $0.end)) steps:\(String(describing: $0.steps))\" }) currentSteps=\(currentSteps)")
        var totalSteps = 0
        var totalDistanceKm: Double = 0.0

        for session in todaySessions {
            if session.end != nil {
                if let savedSteps = session.steps {
                    totalSteps += savedSteps
                    totalDistanceKm += estimateDistance(from: savedSteps)
                }
            } else {
                totalSteps += currentSteps
                totalDistanceKm += currentDistance
            }
        }

        self.todaySteps    = totalSteps
        self.todayDuration = self.estimateDuration(from: totalSteps)
        self.todayDistance = totalDistanceKm
        self.todayCalories = calculateCalories(from: totalSteps)

        // 걸음수 타겟 달성 시 자동 ticketIssue → StepProgressView 갱신
        if totalSteps > 0 {
            AppDataManager.shared.checkAndIssueTicketIfNeeded(steps: totalSteps)
        }

        // steps==nil인 종료 세션이 있으면 비동기로 채워서 재집계 (1회, 중복 방지)
        let hasNilStepSession = todaySessions.contains { $0.end != nil && $0.steps == nil }
        if hasNilStepSession {
            Task { @MainActor in
                await self.resolveNilStepsIfNeeded(currentSteps: currentSteps, currentDistance: currentDistance)
            }
        }
    }

    /// steps==nil인 종료 세션들을 병렬로 fetch해서 채운 뒤 updateTodayTotal을 재호출.
    /// fetchingSessionIndices로 동일 인덱스의 중복 fetch를 방지한다.
    private func resolveNilStepsIfNeeded(currentSteps: Int, currentDistance: Double) async {
        // fetch가 필요한 인덱스만 추출 (이미 진행 중인 것 제외)
        let targets: [(index: Int, start: Date, end: Date)] = todaySessions
            .enumerated()
            .compactMap { (index, session) in
                guard let end = session.end,
                      session.steps == nil,
                      !fetchingSessionIndices.contains(index) else { return nil }
                return (index, session.start, end)
            }

        guard !targets.isEmpty else { return }

        // fetch 중 마킹
        targets.forEach { fetchingSessionIndices.insert($0.index) }

        typealias FetchResult = (index: Int, steps: Int, distanceKm: Double)

        let results = await withTaskGroup(of: FetchResult.self) { group -> [FetchResult] in
            for target in targets {
                group.addTask {
                    let data = await self.fetchPedometerData(from: target.start, to: target.end)
                    return (target.index, data.steps, data.distanceKm)
                }
            }
            var collected: [FetchResult] = []
            for await result in group { collected.append(result) }
            return collected
        }

        // fetch 완료 마킹 해제 및 세션에 steps 기록
        var didUpdate = false
        for result in results {
            fetchingSessionIndices.remove(result.index)
            if todaySessions.indices.contains(result.index), result.steps > 0 {
                todaySessions[result.index].steps = result.steps
                didUpdate = true
            }
        }

        if didUpdate {
            saveTodaySessions()
            // nil이 모두 채워졌으므로 재귀 없이 동기 버전만 호출
            updateTodayTotal(currentSteps: currentSteps, currentDistance: currentDistance)
        }
    }

    // MARK: - CMPedometer 쿼리

    private func fetchPedometerData(from start: Date, to end: Date) async -> (steps: Int, distanceKm: Double) {
        // 시뮬레이터는 CMPedometer 하드웨어가 없어 과거 쿼리를 지원하지 않음 → 스킵
        #if targetEnvironment(simulator)
        return (0, 0.0)
        #else
        let clampedEnd = min(end, Date())

        if start >= clampedEnd { return (0, 0.0) }

        return await withCheckedContinuation { continuation in
            queryFetcher.queryPedometerData(from: start, to: clampedEnd) { data, error in
                if let error = error {
                    print("[StepManager] Query Error: \(error.localizedDescription)")
                }
                let steps = data?.numberOfSteps.intValue ?? 0
                let distanceMeters = data?.distance?.doubleValue ?? 0.0
                continuation.resume(returning: (steps, distanceMeters / 1000.0))
            }
        }
        #endif
    }

    // MARK: - 유틸리티 계산

    private func estimateDistance(from steps: Int) -> Double {
        Double(steps) * 0.76 / 1000.0
    }

    /// 걸음 수 기반 소요 시간 추정 (초)
    /// 평균 보행 속도 기준: 분당 100보 → 1걸음 = 0.6초
    private func estimateDuration(from steps: Int) -> TimeInterval {
        Double(steps) * 0.6
    }

    private func calculateCalories(from steps: Int) -> Double {
        Double(steps) * 0.04
    }

    // MARK: - 세션 저장 / 로드

    private func saveTodaySessions() {
        // 저장 전 중복 세션 제거: start가 같고 end=nil인 세션이 여러 개면 마지막만 유지
        var seen = Set<Date>()
        var deduplicated: [TrackingSession] = []
        for session in todaySessions.reversed() {
            if session.end == nil {
                if seen.contains(session.start) { continue }
                seen.insert(session.start)
            }
            deduplicated.append(session)
        }
        todaySessions = deduplicated.reversed()

        // 세션의 start 날짜 기준으로 저장 (현재 날짜가 아닌 세션이 속한 날짜)
        // 자정 직후 saveTodaySessions 호출 시 새 날짜로 저장되는 버그 방지
        guard let firstSession = todaySessions.first else { return }

        let dateKey = localCalendar.startOfDay(for: firstSession.start)
            .toString(format: "yyyy-MM-dd")

//        CULog("[StepManager] saveTodaySessions | dateKey=\(dateKey) count=\(todaySessions.count)")

        var history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]
        history[dateKey] = todaySessions
        userDefaults.encode(history, forKey: Constants.Key.stepHistoryKey)
    }

    private func loadTodaySessions() {
        let dateKey = Date().toString(format: "yyyy-MM-dd")
        
//        CULog("[StepManager] loadTodaySessions dateKey=\(dateKey)")

        guard let history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) else {
            self.todaySessions = []
            return
        }

        var sessions = history[dateKey] ?? []

        // 저장된 세션의 start가 오늘 범위를 벗어난 경우 교정.
        // 이전 코드에서 Calendar.current가 UTC로 동작해 KST 자정이
        // 잘못된 timestamp로 저장된 경우를 복구한다.
        // 로드 후 중복 세션 제거: start가 같고 end=nil인 세션이 여러 개면 마지막만 유지
        var seen = Set<Date>()
        var deduped: [TrackingSession] = []
        for session in sessions.reversed() {
            if session.end == nil {
                if seen.contains(session.start) { continue }
                seen.insert(session.start)
            }
            deduped.append(session)
        }
        self.todaySessions = deduped.reversed()
    }

    // MARK: - 서버 동기화 완료 처리

    func markAsSynced(for dateKey: String) {
        let history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]

        guard let sessions = history[dateKey],
              let lastSession = sessions.last,
              let end = lastSession.end else {
//            CULog("[StepManager] \(dateKey) 데이터가 미마감 상태이므로 마킹 취소.")
            return
        }

        let calendar = self.localCalendar
        // end가 23:59:59 이거나 자정(다음날 00:00:00) 이면 마감된 세션으로 인정
        let nextMidnight = calendar.startOfDay(for: calendar.date(byAdding: .day, value: 1, to: end)!)
        let isMidnight = calendar.isDate(end, equalTo: nextMidnight, toGranularity: .minute)
        let isEndOfDay = calendar.component(.hour, from: end) == 23
                      && calendar.component(.minute, from: end) == 59
        guard isEndOfDay || isMidnight else {
            CULog("[StepManager] \(dateKey) 마지막 세션이 자정까지 포함하지 않음. end=\(end)")
            return
        }

        var syncedDates = userDefaults.stringArray(forKey: Constants.Key.syncedDatesKey) ?? []
        if !syncedDates.contains(dateKey) {
            syncedDates.append(dateKey)
            userDefaults.set(syncedDates, forKey: Constants.Key.syncedDatesKey)
//            print("[StepManager] \(dateKey) 동기화 마커 기록 완료 (로컬 데이터 30일간 보존).")
        }
    }

    func requestMotionAuthorization(completion: @escaping (Bool) -> Void) {
        let now = Date()
        queryFetcher.queryPedometerData(from: now.addingTimeInterval(-1), to: now) { _, error in
            DispatchQueue.main.async {
                if error != nil {
                    // 에러 발생 = 권한 거부 또는 제한
                    completion(false)
                    return
                }
                // 쿼리 성공 후 실제 권한 상태 재확인
                // (허용 직후 에러 없이 왔어도 권한 상태로 최종 판단)
                let status = CMPedometer.authorizationStatus()
                completion(status == .authorized)
            }
        }
    }
}
