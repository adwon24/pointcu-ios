//
//  GreenPManager.swift
//  PointCU
//
//  Created by Juno Yoon on 5/8/26.
//
import UIKit
import GreenpOfferwall
 
@MainActor
final class GreenPManager: NSObject {
 
    static let shared = GreenPManager()
 
    private var greenP: GreenPSettings?
    private var completion: ((Bool, String) -> Void)?
 
    private override init() {
        super.init()
    }
 
    // MARK: - 오퍼월 실행
 
    /// GreenP 오퍼월 실행
    /// - Parameter appCode: 서버에서 내려온 adKey (GreenP App Code)
    /// - Parameter userId: 매체사 유저 식별값
    /// - Parameter from: present할 UIViewController
    private var greenPWindow: UIWindow?
    private var pendingSettings: GreenPSettings?
    private var pendingContainerVC: GreenPContainerViewController?



    private func releaseWindow() {
        completion?(true, "closed")
        completion = nil
        pendingContainerVC = nil
        greenP = nil

        greenPWindow?.isHidden = true
        greenPWindow?.windowLevel = .normal
        greenPWindow?.rootViewController = nil
        greenPWindow?.resignKey()

        if let appWindow = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive })?
            .windows.first(where: { !($0 === self.greenPWindow) }) {
            appWindow.makeKeyAndVisible()
        }

        greenPWindow = nil
    }
 
    func openOfferwall(
        appCode: String,
        userId: String,
        from viewController: UIViewController,
        completion: ((Bool, String) -> Void)? = nil
    ) {
        CULog("[GreenP] 오퍼월 실행 | appCode: \(appCode) userId: \(userId)")

        self.completion = completion

        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }) else {
            CULog("[GreenP] windowScene 을 찾을 수 없음")
            return
        }

        let window = UIWindow(windowScene: scene)
        window.windowLevel = .alert + 1

        // viewWillAppear 2회 감지로 오퍼월 dismiss 감지 (NStation 방식과 동일)
        let containerVC = GreenPContainerViewController { [weak self] in
            CULog("[GreenP] 오퍼월 dismiss 감지 → window 해제")
            self?.releaseWindow()
        }
        containerVC.view.backgroundColor = .clear
        window.rootViewController = containerVC
        window.makeKeyAndVisible()
        self.greenPWindow = window
        self.pendingContainerVC = containerVC

        // set() 호출 → "Device Regist Success!" 콜백 수신 후 show() 호출
        let settings = GreenPSettings(delegate: self)
        settings.set(appCode: appCode, userID: userId)
        self.pendingSettings = settings

        CULog("[GreenP] set 완료 — Device Regist 대기 중")
    }
}

// MARK: - GreenP 오퍼월 컨테이너 VC
// 오퍼월 dismiss 후 viewWillAppear 2회째 호출 시점에 window 해제

final class GreenPContainerViewController: UIViewController {
    private let onDismiss: () -> Void
    private var appearCount = 0
    /// 오퍼월이 실제로 표시된 후부터 dismiss 감지 시작
    var offerwallDidAppear = false

    init(onDismiss: @escaping () -> Void) {
        self.onDismiss = onDismiss
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // 오퍼월이 표시되기 전 ATT 팝업 등에 의한 viewWillAppear는 무시
        guard offerwallDidAppear else { return }
        appearCount += 1
        print("[GreenP] containerVC viewWillAppear #\(appearCount)")
        // 오퍼월 dismiss 후 복귀
        if appearCount >= 1 {
            onDismiss()
        }
    }
}

// MARK: - GreenPDelegate

extension GreenPManager: GreenPDelegate {
    func greenPSettingsDidEnd(with message: String, result: Bool) {
        print("[GreenP] delegate 호출 | result: \(result) message: \(message)")

        if message == "Device Regist Success!" {
            // 디바이스 등록 완료 → 오퍼월 화면 표시
            // window가 완전히 표시된 후 show() 호출하도록 다음 RunLoop로 지연
            guard let settings = pendingSettings,
                  let containerVC = pendingContainerVC else { return }
            self.greenP = settings
            self.pendingSettings = nil
            print("[GreenP] show 호출")
            DispatchQueue.main.async {
                settings.show(on: containerVC)
                // 오퍼월 표시 후부터 dismiss 감지 시작
                containerVC.offerwallDidAppear = true
            }
        } else {
            // 오퍼월 실제 종료
            print("[GreenP] 오퍼월 종료 | result: \(result) message: \(message)")
            releaseWindow()
        }
    }
}
