//
//  AppDataManager.swift
//  PointCU
//
//  Created by Juno Yoon on 4/17/26.
//

import AppTrackingTransparency
import Foundation
import Combine
import UIKit
import CryptoKit

@MainActor
class AppDataManager: ObservableObject {
    static let shared = AppDataManager()

    // MARK: - UI 바인딩 상태

    @Published var isIndicating: Bool = true
    @Published var attAuthorized: Bool = false  // ATT 권한 상태 (MainBenefitListView 필터링용)
    @Published private(set) var isInitialized: Bool = false  // 초기화 완료 여부

    // 인증
    @Published private(set) var userId: String? {
        didSet {
            if let id = userId {
                userDefaults.set(id, forKey: Constants.Key.userIdKey)
            }
        }
    }

    /// 저장된 userId (메모리 nil 시 UserDefaults에서 복원)
    var resolvedUserId: String? {
        userId ?? userDefaults.string(forKey: Constants.Key.userIdKey)
    }

    // 미션 (StepProgressView)
    @Published var missionData: MissionData?          // mission/detail 원본
    @Published var ticketIssueMission: MissionData?   // ticketIssue 응답 — UI 결정값 기준
    @Published var missionRefreshTrigger: Int = 0       // StepProgressView 스크롤 트리거
    // rewardMilestones: ticketIssueMission/@Published 변경 시 자동 재계산
    // @Published 배열 assign 없이 ticketIssueMission 변경만으로 StepProgressView 갱신
    var rewardMilestones: [RewardMilestone] {
        guard let detail = missionData,
              let ticketIssue = ticketIssueMission else { return [] }
        return buildMilestones(
            detail: detail,
            ticketIssue: ticketIssue,
            currentSteps: StepManager.shared.todaySteps
        )
    }

    // 메인 정보
    @Published var mainData: MainData?

    // UI 리스트 (배너/광고 영역)
    @Published var uiListData: UiListData?

    // 혜택 (룰렛 / 복권)
    @Published var rouletteBenefits: [BenefitItem] = []
    @Published var lotteryBenefits:  [BenefitItem] = []

    // 머니박스 (포인트뱅크)
    @Published var moneyBoxEnabled: Bool = false
    @Published var moneyBoxData: MoneyBoxResponse? = nil

    private let network      = NetworkManager.shared

    // 메인 앱에서 전달받은 사용자 정보
    private(set) var ageOrBirth: String = ""
    private(set) var gender: String     = "1"  // 기본값: 남성
    private let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard

    private init() {}


    // MARK: - SDK 진입점

    /// PointCUSDK.makeMainView(userId:) 에서 호출
    func initializeAppData(userId: String, birth: String?, age: Int?, gender: String?) async {
        guard !userId.isEmpty else {
            CULog("[AppDataManager] Error: userId is empty")
            return
        }

        self.userId = userId
        // birth/age → ageOrBirth 변환 (서버 파라미터용)
        if let b = birth, !b.isEmpty  { self.ageOrBirth = b }
        else if let a = age           { self.ageOrBirth = String(a) }
        if let g = gender, !g.isEmpty { self.gender     = g }
        userDefaults.set(userId, forKey: Constants.Key.userIdKey)
        self.isIndicating = true
        self.isInitialized = false

        do {
            // ── 1단계: 인증
            if network.currentToken == nil {
                try await authenticateIfNeeded(userId: userId, birth: birth, age: age, gender: gender)
            }
            CULog("[AppDataManager] 인증 완료 | token=\(network.currentToken != nil ? "있음" : "없음")")

            // ── 2단계 ~ 4단계: 모든 통신을 로컬 변수에 담고 @Published는 마지막에 한번에 assign
            let mission = try await fetchMission()
            CULog("[AppDataManager] mission/detail 완료 | missionId=\(mission.missionId)")

            // async let 대신 순차 await 사용 — async let dealloc 시 크래시 방지
            let mainResult = try? await fetchMainData()
            let uiList     = try? await fetchUiList()

            let detailIds = Set(uiList?.bannerList.map { $0.detailId } ?? [])
            let needsRoulette = detailIds.contains(UiOrderCode.rouletteArea.rawValue)
            let needsLottery  = detailIds.contains(UiOrderCode.lotteryArea.rawValue)

            let roulette = needsRoulette ? ((try? await fetchBenefits(type: "R")) ?? []) : []
            let lottery  = needsLottery  ? ((try? await fetchBenefits(type: "L")) ?? []) : []

            let steps = StepManager.shared.todaySteps
            var ticketIssueMission: MissionData? = nil
            CULog("[AppDataManager] ticketIssue 요청 | missionId=\(mission.missionId) steps=\(steps)")
            do {
                ticketIssueMission = try await fetchTicketIssue(missionId: mission.missionId, steps: steps)
                CULog("[AppDataManager] ticketIssue 성공 | ticketCount=\(ticketIssueMission?.ticketCount ?? -1)")
            } catch {
                CULog("[AppDataManager] ticketIssue 실패 → mission/detail 폴백: \(error.localizedDescription)")
            }

            let baseForMilestone = ticketIssueMission ?? mission
            let processedMission = processMissionData(mission: baseForMilestone)

            // 모든 통신 완료 후 @Published 프로퍼티 일괄 assign
            self.missionData        = mission
            self.mainData           = mainResult
            self.uiListData         = uiList
            self.rouletteBenefits   = roulette
            self.lotteryBenefits    = lottery
            self.ticketIssueMission = processedMission
            self.isIndicating       = false
            self.isInitialized      = true

            Task { await self.refreshMoneyBox() }
            self.checkAndIssueTicketIfNeeded(steps: steps)

        } catch NetworkError.unauthorized {
            CULog("[AppDataManager] 토큰 만료. 재인증 시도.")
            network.clearToken()
            self.isIndicating = false
            await initializeAppData(userId: userId, birth: birth, age: age, gender: gender)

        } catch {
            CULog("[AppDataManager] 초기화 실패: \(error.localizedDescription)")
            self.isIndicating = false
            self.isInitialized = true
            let attStatus = ATTrackingManager.trackingAuthorizationStatus
            self.attAuthorized = attStatus == .authorized
            CULog("[AppDataManager] ATT 상태: \(attStatus.rawValue) attAuthorized=\(self.attAuthorized)")
        }
    }

    // MARK: - 1. 인증 흐름

    private func authenticateIfNeeded(userId: String, birth: String?, age: Int?, gender: String?) async throws {
        let loginResponse: LoginResponse = try await network.post(
            endpoint: "/api/v2/user/auth/login",
            parameters: [
                "member_code": userId,
                "gaid":        network.idfv
            ],
            requiresAuth: false
        )

        network.currentToken = loginResponse.token
        CULog("[AppDataManager] 로그인 완료 | is_registered: \(loginResponse.isRegistered)")

        if !loginResponse.isRegistered {
            // ageOrBirth 파싱: 숫자면 나이, 날짜 형식이면 생년월일
            let (parsedAge, parsedBirth) = resolveAgeAndBirth(birth: birth, age: age)

            do {
                let signUpResponse: SignUpResponse = try await network.post(
                    endpoint: "/api/v2/user/auth/signup",
                    parameters: [
                        "member_code":  userId,
                        "package_code": Constants.Api.packageCode,
                        "gaid":         network.idfv,
                        "birth":        parsedBirth,
                        "age":          parsedAge,
                        "gender":       gender ?? ""
                    ],
                    requiresAuth: true
                )
                network.currentToken = signUpResponse.token
                CULog("[AppDataManager] 회원가입 완료 | auth_level: \(signUpResponse.authLevel) | age=\(parsedAge) birth=\(parsedBirth) gender=\(gender ?? "")")
            } catch {
                // signup 실패 시 임시 토큰 삭제
                CULog("[AppDataManager] 회원가입 실패 → 임시 토큰 삭제: \(error.localizedDescription)")
                network.clearToken()
                throw error
            }
        }
    }

    // MARK: - birth/age 파라미터 변환

    /// birth(String) 또는 age(Int) → 서버 파라미터 (age: String, birth: String) 변환
    /// - birth 있으면: birth(YYYYMMDD) + age 계산
    /// - age 있으면: age만, birth 생략
    private func resolveAgeAndBirth(birth: String?, age: Int?) -> (age: String, birth: String) {
        if let birth = birth, !birth.isEmpty {
            // 날짜 형식 정규화 (yyyy-MM-dd, yyyy.MM.dd → yyyyMMdd)
            let digits = birth.filter { $0.isNumber }
            guard digits.count == 8 else { return (age.map { String($0) } ?? "", "") }

            let birthStr = digits  // YYYYMMDD

            // 나이 계산
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyyMMdd"
            let calendar = Calendar.current
            if let birthDate = formatter.date(from: birthStr) {
                let calcAge = calendar.dateComponents([.year], from: birthDate, to: Date()).year ?? 0
                CULog("[AppDataManager] resolveAgeAndBirth | birth=\(birthStr) calcAge=\(calcAge)")
                return (String(calcAge), birthStr)
            }
            return ("", birthStr)
        } else if let age = age {
            CULog("[AppDataManager] resolveAgeAndBirth | age=\(age)")
            return (String(age), "")
        }
        return ("", "")
    }

    // MARK: - 2. 걸음 미션 현황 (GET /api/v2/member/mission/detail)

    private func fetchMission() async throws -> MissionData {
        try await network.get(endpoint: "/api/v2/member/mission/detail")
    }

    // MARK: - 2-1. 티켓 발행 현황 (POST /api/v2/member/mission/ticketIssue)

    private func fetchTicketIssue(missionId: Int, steps: Int) async throws -> MissionData {
        // getRaw: result:false여도 result_data가 있으면 디코딩 시도
        // 신규 유저 등 특수 케이스에서 result:false로 내려올 수 있음
        try await network.getRaw(
            endpoint: "/api/v2/member/mission/ticketIssue",
            method: "POST",
            parameters: [
                "mission_id": missionId,
                "step": steps,
                "step_count": steps
            ]
        )
    }

    // MARK: - 걸음수 타겟 달성 시 자동 ticketIssue

    // 마지막으로 ticketIssue 한 타겟 걸음수 — 중복 호출 방지
    private var isAutoIssuing: Bool = false

    /// StepManager.updateTodayTotal에서 호출
    /// 현재 걸음수가 미션 타겟에 도달하면 ticketIssue 자동 요청
    /// 완료 후 다음 단계도 달성했으면 연속 체크
    func checkAndIssueTicketIfNeeded(steps: Int) {
        guard let mission = ticketIssueMission else { return }
        guard !isAutoIssuing else { return }
        guard network.currentToken != nil else { return }

        // 티켓 한도 도달 시 스킵
        let ticketLimit = mission.ticketLimit
        let ticketCount = mission.ticketCount
        if ticketLimit > 0 && ticketCount >= ticketLimit { return }

        // isIssued == false 인 것 중 stepCountDuration이 가장 낮은 스케줄
        _ = mission.scheduleList.map { "\($0.stepCountDuration):\($0.isIssued)" }.joined(separator: ", ")
//        CULog("[AppDataManager] checkAndIssue | steps=\(steps) | schedules=\(issuedStates)")

        guard let nextSchedule = mission.scheduleList
            .filter({ !$0.isIssued && $0.stepCountDuration > 0 })
            .min(by: { $0.stepCountDuration < $1.stepCountDuration }) else {
//            CULog("[AppDataManager] checkAndIssue | nextSchedule 없음 — 스킵")
            return
        }

        let targetStep = nextSchedule.stepCountDuration
//        CULog("[AppDataManager] checkAndIssue | nextTarget=\(targetStep) steps=\(steps)")

        // 걸음수 >= 타겟일 때만 실행 (서버 멱등성 보장 — 중복 발급 없음)
        guard steps >= targetStep else { return }

        isAutoIssuing = true
        if Constants.NETWORK_LOG { CULog("[AppDataManager] 걸음수 타겟 달성 (\(steps) >= \(targetStep)) → ticketIssue 요청") }

        Task {
            do {
                let ticketIssueMission = try await self.fetchTicketIssue(
                    missionId: mission.missionId,
                    steps: steps
                )
                let processed = self.processMissionData(mission: ticketIssueMission)
                let issuedLog = processed.scheduleList.map { "\($0.stepCountDuration):\($0.isIssued)" }.joined(separator: ", ")
                if Constants.NETWORK_LOG { CULog("[AppDataManager] ticketIssue 완료 | ticketCount=\(processed.ticketCount) | schedules=\(issuedLog)") }
                self.ticketIssueMission = processed
                self.isAutoIssuing = false
                self.checkAndIssueTicketIfNeeded(steps: steps)
            } catch {
                self.isAutoIssuing = false
                if Constants.NETWORK_LOG { CULog("[AppDataManager] ticketIssue 실패: \(error.localizedDescription)") }
            }
        }
    }

    // MARK: - 6. 룰렛/복권 상세 (GET /api/v2/member/benefit/detail)

    func fetchBenefitDetail(benefitId: Int) async throws -> BenefitDetailResponse {
        return try await network.getRaw(
            endpoint: "/api/v2/member/benefit/detail",
            parameters: ["benefit_id": "\(benefitId)"]
        )
    }

    // MARK: - 6-1. 룰렛/복권 외부 호출용 상세 (GET /api/v2/member/benefit/detailByLocation)
    // 메인앱에서 직접 룰렛/복권 호출 시 benefitId 없이 benefit_type + location으로 조회

    func fetchBenefitDetailByLocation(benefitType: String) async throws -> BenefitDetailResponse {
        return try await network.getRaw(
            endpoint: "/api/v2/member/benefit/detailByLocation",
            parameters: [
                "benefit_type": benefitType,  // R: 룰렛, L: 복권
                "location":     "CG"          // CU 게임 고정값
            ]
        )
    }

    // MARK: - 6-1. 혜택 티켓 발급 (POST /api/v2/member/benefit/ticketIssue)

    func issueBenefitTicket(benefitId: Int) async throws -> BenefitTicketIssueResponse {
        try await network.getRaw(
            endpoint: "/api/v2/member/benefit/ticketIssue",
            method: "POST",
            parameters: ["benefit_id": benefitId]
        )
    }

    // MARK: - 7. 룰렛/복권 당첨 확인 (POST /api/v2/member/benefit/confirm)

    func confirmBenefit(benefitId: Int, benefitType: String) async throws -> BenefitConfirmResponse {
        let rewardClientId = generateRewardClientId()
        let cipherText     = generateCipherText(id: benefitId, rewardClientId: rewardClientId)

        return try await network.post(
            endpoint: "/api/v2/member/benefit/confirm",
            parameters: [
                "benefit_id":       benefitId,
                "benefit_type":     benefitType,
                "reward_client_id": rewardClientId,
                "cipher_text":      cipherText
            ]
        )
    }

    // MARK: - 통계

    func fetchStatistics() async throws -> StatisticResponse {
        var calendar = Calendar.current
        calendar.timeZone = TimeZone(identifier: "Asia/Seoul")!
        let today = Date()

        let yesterday = calendar.date(byAdding: .day, value: -1, to: today)!
        let startDate = calendar.date(byAdding: .day, value: -20, to: yesterday)!

        let fmt = DateFormatter()
        fmt.dateFormat = "yyyy-MM-dd"
        fmt.timeZone   = TimeZone(identifier: "Asia/Seoul")

        let baseURL  = sdkBaseURL
        let query    = "start_date=\(fmt.string(from: startDate))&end_date=\(fmt.string(from: yesterday))&type=day"
        guard let url = URL(string: baseURL + "/api/v2/member/statistic/list?" + query) else {
            throw NetworkError.invalidURL
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.addValue(Constants.Api.companyCode, forHTTPHeaderField: "company_code")
        req.addValue(Constants.Api.sdkCode,     forHTTPHeaderField: "sdk_code")
        if let token = network.currentToken {
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        let (data, _) = try await URLSession.shared.data(for: req)
        let body = String(data: data, encoding: .utf8) ?? ""
        if Constants.NETWORK_LOG { CULog("[Network] ◀ GET statistic | \(body)") }
        return try JSONDecoder().decode(StatisticResponse.self, from: data)
    }

    // MARK: - 사용자 데이터 초기화

    @MainActor
    func clearUserId() {
        userId              = nil
        missionData         = nil
        ticketIssueMission  = nil
        mainData            = nil
        uiListData          = nil
        rouletteBenefits    = []
        lotteryBenefits     = []
        moneyBoxEnabled     = false
        moneyBoxData        = nil
        isIndicating        = false
        isInitialized       = false
        isAutoIssuing       = false
        CULog("[AppDataManager] 사용자 데이터 초기화 완료")
    }

    // MARK: - 걸음 수 업데이트

    @discardableResult
    func updateStepList(_ stepList: [StepUpdateItem]) async throws -> Bool {
        guard !stepList.isEmpty else { return true }

        let encoder = JSONEncoder()
        guard let jsonData   = try? encoder.encode(stepList),
              let jsonString = String(data: jsonData, encoding: .utf8) else {
            throw NetworkError.decodingFailed
        }

        let baseURL = sdkBaseURL
        guard let url = URL(string: baseURL + "/api/v2/member/step/updateList") else {
            throw NetworkError.invalidURL
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.addValue(Constants.Api.companyCode, forHTTPHeaderField: "company_code")
        req.addValue(Constants.Api.sdkCode,     forHTTPHeaderField: "sdk_code")
        if let token = network.currentToken {
            req.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        let encoded = jsonString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? jsonString
        req.httpBody = "step_list=\(encoded)".data(using: .utf8)

        let (data, _) = try await URLSession.shared.data(for: req)
        let body = String(data: data, encoding: .utf8) ?? ""
        if Constants.NETWORK_LOG { CULog("[Network] ◀ POST updateStepList | \(body)") }

        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        return json?["result"] as? Bool ?? false
    }

    // MARK: - reward_client_id / cipher_text 생성

    private func generateRewardClientId() -> String {
        let nanoTime = Int64(Date().timeIntervalSince1970 * 1_000_000_000)
        return "\(nanoTime)"
    }

    private func generateCipherText(id: Int, rewardClientId: String) -> String {
        let userId = mainData?.user.id ?? 0
        let token  = network.currentToken ?? ""
        let raw    = "\(id)\(rewardClientId)\(userId)\(token)"
        let digest = SHA256.hash(data: Data(raw.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    /// MoneyBox 전용 — subId(moneybox_schedule_id) 포함
    private func generateCipherText(id: Int, subId: Int, rewardClientId: String) -> String {
        let userId = mainData?.user.id ?? 0
        let token  = network.currentToken ?? ""
        let raw    = "\(id)\(subId)\(rewardClientId)\(userId)\(token)"
        let digest = SHA256.hash(data: Data(raw.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    // MARK: - 8. MoneyBox API

    private func fetchMoneyBox() async throws -> MoneyBoxResponse {
        try await network.get(endpoint: "/api/v2/member/moneybox/detail")
    }

    @discardableResult
    func confirmMoneyBox(moneyboxId: Int, moneyboxScheduleId: Int) async throws -> MoneyBoxConfirmResponse {
        let rewardClientId = generateRewardClientId()
        // MoneyBox cipher: id + subId(scheduleId) + rewardClientId + userId + token
        let cipherText     = generateCipherText(id: moneyboxId, subId: moneyboxScheduleId, rewardClientId: rewardClientId)

        let response: MoneyBoxConfirmResponse = try await network.post(
            endpoint: "/api/v2/member/moneybox/confirm",
            parameters: [
                "moneybox_id":          moneyboxId,
                "moneybox_schedule_id": moneyboxScheduleId,
                "reward_client_id":     rewardClientId,
                "cipher_text":          cipherText
            ]
        )
        CULog("[AppDataManager] MoneyBox confirm | win_point=\(response.winPoint)")
        return response
    }

    func refreshMoneyBox() async {
        if let moneyBox = try? await fetchMoneyBox() {
            self.moneyBoxData    = moneyBox
            self.moneyBoxEnabled = true
        } else {
            self.moneyBoxData    = nil
            self.moneyBoxEnabled = false
        }
    }

    // MARK: - 2-2. 티켓 확인/수령 (POST /api/v2/member/mission/ticketConfirm)

    @discardableResult
    func confirmTicket(missionId: Int) async throws -> Int {
        let rewardClientId = generateRewardClientId()
        let cipherText     = generateCipherText(id: missionId, rewardClientId: rewardClientId)
        let response: TicketConfirmResponse = try await network.post(
            endpoint: "/api/v2/member/mission/ticketConfirm",
            parameters: [
                "mission_id":       missionId,
                "reward_client_id": rewardClientId,
                "cipher_text":      cipherText
            ]
        )

        if var updated = self.ticketIssueMission {
            updated.ticketCount    = response.ticketCount
            updated.ticketUseCount = response.ticketUseCount
            updated.stepCount      = response.stepCount

            let processed = processMissionData(mission: updated)
            await MainActor.run {
                self.ticketIssueMission = processed  // @Published → StepProgressView 즉시 갱신
            }
        }

        CULog("[AppDataManager] ticketConfirm 완료 | win_point=\(response.winPoint) | ticketCount=\(response.ticketCount) | ticketUseCount=\(response.ticketUseCount)")
        return response.winPoint
    }

    // MARK: - 3. 메인 정보 (POST /api/v2/member/home/main)

    private func fetchMainData() async throws -> MainData {
        let device    = UIDevice.current
        let today     = Date().toString(format: "yyyy-MM-dd")
        let osVersion = device.systemVersion
        let modelNo   = deviceModelName()

        let isSimulator = modelNo == "arm64" || modelNo.isEmpty
        let todaySteps = StepManager.shared.todaySteps

        var params: [String: Any] = [
            "step":        todaySteps,
            "duration":    Int(StepManager.shared.todayDuration),
            "target_date": today,
            "os_version":  osVersion,
            "carrier":     "",
            "gaid":        network.idfv
        ]
        if !isSimulator {
            params["mobile_model_no"] = modelNo
        }

        return try await network.post(endpoint: "/api/v2/member/home/main", parameters: params)
    }

    // MARK: - 시스템 점검 / 공지 팝업

    func fetchInspection() async -> InspectionData? {
        // ⚠️ 테스트용 임시 데이터 — 실제 배포 전 제거
        // return InspectionData(inspectionId: 99, description: "서비스 점검 중입니다.\n잠시 후 다시 이용해 주세요.")

        // result:false(점검 없음)와 실제 오류를 구분하기 위해 getRaw 사용
        // result:false + result_data 없음 → 점검 없음 → nil 반환
        // result:true + result_data 있음 → 점검 중 → InspectionData 반환
        return try? await network.getRaw(
            endpoint: "/api/v2/member/home/inspection",
            parameters: ["os_type": "I"]
        )
    }

    func fetchNoticePopup() async throws -> NoticePopupItem? {
        // 테스트용 임시 데이터 — 실제 배포 전 제거
        // [형태1] popup_list / position_yn 기반
        // return NoticePopupItem(
        //     popupId: 99, title: "공지사항 테스트",
        //     content: "공지사항 테스트입니다.\n내용을 확인해 주세요.",
        //     positionYn: "Y", regDate: "2026-05-27",
        //     linkType: nil, linkData: nil, noticeTitle: nil, noticeContent: nil,
        //     noticeRegDate: nil, offerwallDetailId: nil, serviceDetailId: nil, url: nil
        // )
        // [형태2] data_list / link_type 기반
        // return NoticePopupItem(
        //     popupId: 99, title: "공지사항 테스트",
        //     content: nil, positionYn: nil, regDate: nil,
        //     linkType: "N", linkData: "", noticeTitle: "서비스 공지",
        //     noticeContent: "공지사항 테스트입니다.\n내용을 확인해 주세요.",
        //     noticeRegDate: "2026-05-27", offerwallDetailId: "", serviceDetailId: "", url: ""
        // )
        let data: NoticePopupListData = try await network.get(
            endpoint: "/api/v2/member/popup/noticePopupList"
        )
        // position_yn=Y 우선, 없으면 첫 번째
        return data.popupList.first(where: { $0.positionYn == "Y" })
            ?? data.popupList.first
    }

    // MARK: - 4. UI 리스트 (GET /api/v2/member/ui/list)

    private func fetchUiList() async throws -> UiListData {
        try await network.get(endpoint: "/api/v2/member/ui/list", parameters: ["location": "H"])
    }

    // MARK: - 5. 혜택 리스트 (GET /api/v2/member/benefit/list)

    private func fetchBenefits(type: String) async throws -> [BenefitItem] {
        let data: BenefitListData = try await network.get(
            endpoint: "/api/v2/member/benefit/list",
            parameters: ["benefit_type": type]
        )
        return data.dataList
    }

    // MARK: - 미션 데이터 가공 (isIssued / isComplete 주입)

    func processMissionData(mission: MissionData) -> MissionData {
        var schedules = mission.scheduleList.sorted { $0.stepCountDuration < $1.stepCountDuration }

        if !schedules.isEmpty && schedules.count >= mission.ticketUseCount {
            for i in 0..<min(schedules.count, mission.ticketCount) {
                schedules[i].isIssued = true
            }
            for i in 0..<min(schedules.count, mission.ticketUseCount) {
                schedules[i].isComplete = true
            }
        }

        return MissionData(
            missionId:           mission.missionId,
            targetStep:          mission.targetStep,
            stepCount:           mission.stepCount,
            ticketCount:         mission.ticketCount,
            ticketUseCount:      mission.ticketUseCount,
            ticketLimit:         mission.ticketLimit,
            customDisplayTextYn: mission.customDisplayTextYn,
            missionType:         mission.missionType,
            scheduleList:        schedules
        )
    }

    // MARK: - RewardMilestone 변환 (MissionData → 내부 UI 모델)

    private func buildMilestones(detail: MissionData, ticketIssue: MissionData, currentSteps: Int = 0) -> [RewardMilestone] {
        var milestones: [RewardMilestone] = []
        let useCustomText = detail.customDisplayTextYn == "Y"
        // uniqueKeysWithValues 대신 reduce 사용 — 중복 키 시 크래시 방지
        let detailScheduleMap: [Int: MissionSchedule] = detail.scheduleList.reduce(into: [:]) {
            $0[$1.missionScheduleId] = $1
        }
        let schedules = ticketIssue.scheduleList.sorted { $0.stepCountDuration < $1.stepCountDuration }

        for (_, schedule) in schedules.enumerated() {
            let step = schedule.stepCountDuration

            let detailSchedule = detailScheduleMap[schedule.missionScheduleId]
            let displayText: String
            if useCustomText, let text = detailSchedule?.customDisplayText, !text.isEmpty {
                displayText = text
            } else if step == 0 {
                displayText = "기본보상"
            } else if step >= 10000 {
                displayText = "\(step / 10000)만걸음"
            } else if step >= 1000 {
                displayText = "\(step / 1000)천걸음"
            } else {
                displayText = "\(step)걸음"
            }

            let rewardType: RewardMilestone.RewardType =
                schedule.advertisementYn == "N" ? .point : .ticket

            let status: RewardMilestone.RewardStatus
            if schedule.isComplete {
                status = .completed
            } else if schedule.isIssued {
                status = .available
            } else {
                status = .locked
            }

            milestones.append(RewardMilestone(
                id:          schedule.missionScheduleId,
                step:        step,
                displayText: displayText,
                rewardType:  rewardType,
                status:      status
            ))
        }

//        CULog("[AppDataManager] 마일스톤 생성: \(milestones.count)개, 현재걸음: \(currentSteps)")
        return milestones
    }

    // MARK: - 포그라운드 복귀 시 메인 정보 갱신

    /// startGameRoulette/Lottery 단독 호출 시 데이터 없으면 fetch
    func refreshBenefits() async {
        guard let uiList = uiListData else { return }
        let detailIds  = Set(uiList.bannerList.map { $0.detailId })
        let needsR = detailIds.contains(UiOrderCode.rouletteArea.rawValue)
        let needsL = detailIds.contains(UiOrderCode.lotteryArea.rawValue)
        if needsR { rouletteBenefits = (try? await fetchBenefits(type: "R")) ?? [] }
        if needsL { lotteryBenefits  = (try? await fetchBenefits(type: "L")) ?? [] }
    }

    // MARK: - 점검 체크 → 데이터 갱신 → 공지팝업 (화면 진입/갱신 시 공통 흐름)

    /// 점검 체크 → refreshMainData → 공지팝업 순서로 처리
    /// MainView의 모든 갱신 시점에서 이 함수를 호출
    @MainActor
    func checkAndRefresh() async {
        // ATT 상태 갱신
        attAuthorized = ATTrackingManager.trackingAuthorizationStatus == .authorized
        // 1. 시스템 점검 체크 (가장 먼저)
        if await checkInspection() { return }  // 점검 중이면 이후 진행 안 함
        // 2. 데이터 갱신
        await refreshMainData()
        // 3. 공지 팝업
        await checkNoticePopup()
    }

    /// 시스템 점검 체크 — 점검 중이면 팝업 후 SDK 종료, true 반환
    @MainActor
    func checkInspection() async -> Bool {
        guard let data = await fetchInspection() else { return false }
        OverlayManager.shared.showInspection(
            message: data.description,
            confirmAction: {
                SDKRootContainer.dismissSDKIfNeeded()
            }
        )
        return true
    }

    /// 공지 팝업 체크 — 오늘 하루 보지 않기 처리 포함
    @MainActor
    func checkNoticePopup() async {
        // 오늘 날짜가 지난 "오늘 하루 보지 않기" 데이터 정리
        let todayStr = Date().toString(format: "yyyy-MM-dd")
        let defaults = UserDefaults.standard
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix("PointCU_NoticePopup_") {
            if let savedDate = defaults.string(forKey: key), savedDate != todayStr {
                defaults.removeObject(forKey: key)
            }
        }

        guard let popup = try? await fetchNoticePopup() else { return }

        // 오늘 하루 보지 않기 체크
        let key = "PointCU_NoticePopup_\(popup.popupId)"
        if defaults.string(forKey: key) == todayStr { return }

        // NoticePopupItem.displayTitle/displayContent 활용 (두 가지 형태 모두 처리)
        let displayTitle   = popup.title
        let displayContent = popup.content
 
        OverlayManager.shared.showNotification(
            title: displayTitle,
            message: displayContent,
            confirmAction: { hideToday in
                if hideToday {
                    defaults.set(todayStr, forKey: key)
                }
            }
        )
    }

    func refreshMainData() async {
        guard network.currentToken != nil else { return }
        do {
            let mission = try await fetchMission()
            self.missionData = mission

            if let main = try? await fetchMainData() {
                self.mainData = main
            }

            Task { await self.refreshMoneyBox() }

            let steps = StepManager.shared.todaySteps
            var ticketIssueMission: MissionData? = nil
            
            do {
                ticketIssueMission = try await fetchTicketIssue(
                    missionId: mission.missionId,
                    steps: steps
                )
                // CULog("[AppDataManager] ticketIssue 갱신 성공 | ticketCount=\(ticketIssueMission?.ticketCount ?? -1)")
            } catch {
                 CULog("[AppDataManager] ticketIssue 갱신 실패 → mission/detail 폴백: \(error.localizedDescription)")
            }

            let baseForMilestone = ticketIssueMission ?? mission
            let processed        = processMissionData(mission: baseForMilestone)
            self.ticketIssueMission = processed
            self.missionRefreshTrigger += 1  // StepProgressView 스크롤 트리거

            // 갱신 후 걸음수 타겟 달성 여부 체크
            self.checkAndIssueTicketIfNeeded(steps: steps)

            // uiList 및 룰렛/복권 benefit 갱신 (시간대 변경 시 새 benefit_id 반영)
            if let uiList = try? await fetchUiList() {
                self.uiListData = uiList
            }
            await self.refreshBenefits()

        } catch {
            CULog("[AppDataManager] 갱신 실패: \(error.localizedDescription)")
        }
    }

    // MARK: - 유틸리티

    private func deviceModelName() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        return machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
    }
}
