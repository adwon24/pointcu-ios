//
//  StepSyncManager.swift
//  PointCU
//
//  Created by Juno Yoon on 4/19/26.
//

import Foundation
import Combine
import UIKit

@MainActor
class StepSyncManager {
    static let shared = StepSyncManager()

    private var isStarted = false
    private let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard

    private var isSyncing: Bool = false
    private var cancellables = Set<AnyCancellable>()

    private init() {}

    func start() async {
        guard !isStarted else { return }
        isStarted = true
        setupSignals()
    }

    private func setupSignals() {
        // 1. StepManager 준비 완료 시 1회: backfill → 동기화 순서로 실행
        StepManager.shared.$isReadyForSync
            .filter { $0 == true }
            .first()
            .sink { [weak self] _ in
                Task {
                    // init StepManager backfill 과 별개로,
                    // StepSyncManager 관점의 최신 상태 확보를 위해 한 번 더 실행.
                    // isBackfilling guard가 중복 실행을 막아준다.
                    await StepManager.shared.backfillMissingDays()
                    await self?.syncAllPendingSessions()
                }
            }
            .store(in: &cancellables)

        // 2. 포그라운드 복귀 시: backfill → 동기화
        // 앱을 며칠간 안 열었다가 켰을 때 그 기간의 누락 데이터를 보완한 뒤 전송
        NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)
            .sink { [weak self] _ in
                guard StepManager.shared.isReadyForSync else { return }
                Task {
                    // 포그라운드 복귀마다 누락 일자 점검
                    await StepManager.shared.backfillMissingDays()
                    await self?.syncAllPendingSessions()
                }
            }
            .store(in: &cancellables)

        // 3. 백그라운드 진입 직전: 마지막 동기화 보장
        // backfill은 생략 (백그라운드 시간이 제한적이므로 전송에만 집중)
        NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)
            .sink { [weak self] _ in
                guard StepManager.shared.isReadyForSync else { return }

                var backgroundTaskID: UIBackgroundTaskIdentifier = .invalid
                backgroundTaskID = UIApplication.shared.beginBackgroundTask(withName: "StepSyncOnBackground") {
                    UIApplication.shared.endBackgroundTask(backgroundTaskID)
                    backgroundTaskID = .invalid
                }

                Task {
                    await self?.syncAllPendingSessions()
                    UIApplication.shared.endBackgroundTask(backgroundTaskID)
                    backgroundTaskID = .invalid
                }
            }
            .store(in: &cancellables)
    }

    /// clearUserData() 호출 시 동기화 상태 초기화
    func reset() {
        isSyncing = false
        isStarted = false
        cancellables.removeAll()
    }

    func syncAllPendingSessions() async {
        guard !isSyncing else { return }
        // guard AuthManager.shared.currentToken != nil else { return }

        isSyncing = true

        let history = userDefaults.decode([String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey) ?? [:]
        var dailyTotals: [String: Int] = [:]
        let todayKey = Date().toString(format: "yyyy-MM-dd")

        // 이미 동기화 완료된 날짜 제외
        let syncedDatesSet = Set(userDefaults.stringArray(forKey: Constants.Key.syncedDatesKey) ?? [])

        // 과거 데이터 취합 — 걸음수 0이어도 측정 데이터가 있으면 포함
        for (dateKey, sessions) in history {
            if dateKey == todayKey { continue }
            if syncedDatesSet.contains(dateKey) { continue }  // 이미 전송 완료
            let dayTotalSteps = sessions.compactMap { $0.steps }.reduce(0, +)
            dailyTotals[dateKey] = dayTotalSteps
        }

        // 오늘 데이터 취합 (실시간 수치 사용) — 측정 중이면 0이어도 포함
        if StepManager.shared.isReadyForSync {
            dailyTotals[todayKey] = StepManager.shared.todaySteps
        }

        if !dailyTotals.isEmpty {
            await uploadToServer(dailyTotals)
        }
        isSyncing = false
    }

    private func uploadToServer(_ data: [String: Int]) async {
        let stepList = data.map { StepUpdateItem(stepDate: $0.key, stepCount: $0.value) }
            .sorted { $0.stepDate > $1.stepDate }  // 최신순 정렬

//        CULog("[StepSyncManager] 서버 전송 시도: \(stepList.count)건 | \(data)")

        do {
            let success = try await AppDataManager.shared.updateStepList(stepList)
            if success {
//                CULog("[StepSyncManager] 서버 전송 성공")
                for dateKey in data.keys {
                    StepManager.shared.markAsSynced(for: dateKey)
                }
            }
//            else {
//                CULog("[StepSyncManager] 서버 전송 실패 (result: false). 다음 동기화 턴에 재시도합니다.")
//            }
        } catch {
//            CULog("[StepSyncManager] 서버 전송 오류: \(error.localizedDescription). 다음 동기화 턴에 재시도합니다.")
        }
    }
}
