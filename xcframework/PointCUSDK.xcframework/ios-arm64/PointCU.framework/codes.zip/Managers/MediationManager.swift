//
//  MediationManager.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/29/26.
//

import Foundation

/// 광고 미디에이션 정보를 관리합니다.
/// - member 미디에이션: SDK 초기화 시 fetch, 토큰 필요, 1시간 캐시
/// - user 미디에이션: CU 자체 광고 호출 시마다 fetch, 토큰 불필요, 캐시 없음
@MainActor
class MediationManager {
    static let shared = MediationManager()

    private let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard
    private let network = NetworkManager.shared

    // MARK: - 캐시 키 (member 전용)

    private let memberDataKey      = "mediation_member_data"
    private let memberLastFetchKey = "mediation_member_last_fetch"
    private let cacheTTL: TimeInterval = 3600  // 1시간

    private init() {
        // 구 버전 캐시 키 정리
        userDefaults.removeObject(forKey: "mediation_data")
        userDefaults.removeObject(forKey: "mediation_last_fetch")
    }

    /// SDK 초기화 완료 여부
    private(set) var isReady: Bool = false

    // MARK: - member 캐시 접근

    private var memberCachedData: MediationListData? {
        userDefaults.decode(MediationListData.self, forKey: memberDataKey)
    }

    /// 특정 광고 위치 코드의 광고 리스트 반환 (member 캐시 기준)
    func ads(for locationCode: String) -> [MediationAd] {
        memberCachedData?.mediationList
            .first { $0.advertisementLocation == locationCode }
            .map { $0.advertisementList.filter { !$0.adKey.isEmpty } }
            ?? []
    }

    func adKey(location: String, priority: String) -> String? {
        ads(for: location).first { $0.priorityCode == priority }?.adKey
    }

    // MARK: - 만료 여부

    var isMemberExpired: Bool {
        guard let last = userDefaults.object(forKey: memberLastFetchKey) as? Date else { return true }
        return Date().timeIntervalSince(last) >= cacheTTL
    }

    // MARK: - SDK 초기화 시 호출 (member 전용)

    func fetchIfNeeded(force: Bool = false) async {
        guard force || isMemberExpired else {
            CULog("[MediationManager] member 캐시 유효 — 스킵")
            isReady = true
            return
        }
        await fetchMember()
        isReady = true
    }

    private func fetchMember() async {
        guard let result: MediationListData = try? await network.get(
                endpoint: "/api/v2/member/advertisement/mediation/list"
        ) else {
            CULog("[MediationManager] member 미디에이션 조회 실패")
            return
        }
        userDefaults.encode(result, forKey: memberDataKey)
        userDefaults.set(Date(), forKey: memberLastFetchKey)
        CULog("[MediationManager] member 미디에이션 갱신 완료 | 위치 수: \(result.mediationList.count)")
    }

    // MARK: - CU 자체 광고 전용 (user, 캐시 없음)

    /// CU 자체 광고 호출 시마다 /user/advertisement/mediation/list 를 fetch 후 반환
    /// 토큰 불필요, 캐시 없음 — 항상 최신 데이터 사용
    func fetchUserMediationList() async -> MediationListData? {
        guard let result: MediationListData = try? await network.get(
            endpoint: "/api/v2/user/advertisement/mediation/list",
            requiresAuth: false
        ) else {
            CULog("[MediationManager] user 미디에이션 조회 실패")
            return nil
        }
        CULog("[MediationManager] user 미디에이션 수신 완료 | 위치 수: \(result.mediationList.count)")
        return result
    }

    /// user 미디에이션에서 특정 위치의 광고 리스트 추출
    func userAds(from data: MediationListData, for locationCode: String) -> [MediationAd] {
        data.mediationList
            .first { $0.advertisementLocation == locationCode }
            .map { $0.advertisementList.filter { !$0.adKey.isEmpty } }
            ?? []
    }

    // MARK: - 광고 순환 인덱스 관리 (member 광고용)

    private func adIndexKey(for placement: AdsPlacementType) -> String {
        "mediation_ad_index_\(placement.rawValue)"
    }

    func currentIndex(for placement: AdsPlacementType) -> Int {
        userDefaults.integer(forKey: adIndexKey(for: placement))
    }

    func advanceIndex(for placement: AdsPlacementType) {
        let list = ads(for: placement.rawValue)
        guard !list.isEmpty else { return }
        let key = adIndexKey(for: placement)
        userDefaults.set((userDefaults.integer(forKey: key) + 1) % list.count, forKey: key)
    }

    func nextAd(for placement: AdsPlacementType) -> MediationAd? {
        let adList = ads(for: placement.rawValue)
        guard !adList.isEmpty else { return nil }
        let key = adIndexKey(for: placement)
        let currentIndex = userDefaults.integer(forKey: key) % adList.count
        return adList[currentIndex]
    }

    func currentAd(for placement: AdsPlacementType) -> MediationAd? {
        let adList = ads(for: placement.rawValue)
        guard !adList.isEmpty else { return nil }
        let index = userDefaults.integer(forKey: adIndexKey(for: placement))
        return adList[index % adList.count]
    }

    // MARK: - 유틸

    private var lastFetchDateString: String {
        guard let date = userDefaults.object(forKey: memberLastFetchKey) as? Date else { return "없음" }
        let fmt = DateFormatter()
        fmt.dateFormat = "HH:mm:ss"
        fmt.timeZone = TimeZone.current
        return fmt.string(from: date)
    }
}
