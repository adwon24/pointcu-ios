//
//  AdPopcornAdDelegate.swift
//  PointCU
//
//  Created by Juno Yoon on 5/22/26.
//

import UIKit
import AdPopcornSSP

final class AdPopcornAdDelegate: NSObject {
    static let shared = AdPopcornAdDelegate()
    var onComplete: (() -> Void)?
    var onFail: (() -> Void)?
    var interstitialVideoAd: AdPopcornSSPInterstitialVideoAd?
    var rewardAd: AdPopcornSSPRewardVideoAd?
    private override init() {}
}

extension AdPopcornAdDelegate: APSSPInterstitialVideoAdDelegate {
    func apsspInterstitialVideoAdLoadSuccess(_ ad: AdPopcornSSPInterstitialVideoAd!) {
        guard let topVC = UIApplication.shared.topViewController() else { return }
        OverlayManager.shared.hideCenterMessage()
        OverlayManager.shared.hideIndicator()
        ad.present(from: topVC)
    }
    func apsspInterstitialVideoAdLoadFail(_ ad: AdPopcornSSPInterstitialVideoAd!, error: AdPopcornSSPError!) {
        CULog("[AdPopcorn] 전면 로드 실패: \(error?.localizedDescription ?? "")")
        onFail?(); onFail = nil; onComplete = nil; interstitialVideoAd = nil
    }
    func apsspInterstitialVideoAdShowSuccess(_ ad: AdPopcornSSPInterstitialVideoAd!) {}
    func apsspInterstitialVideoAdShowFail(_ ad: AdPopcornSSPInterstitialVideoAd!) {
        onFail?(); onFail = nil; onComplete = nil; interstitialVideoAd = nil
    }
    func apsspInterstitialVideoAdClosed(_ ad: AdPopcornSSPInterstitialVideoAd!) {
        onComplete?(); onComplete = nil; onFail = nil; interstitialVideoAd = nil
    }
}

extension AdPopcornAdDelegate: APSSPRewardVideoAdDelegate {
    func apsspRewardVideoAdLoadSuccess(_ ad: AdPopcornSSPRewardVideoAd!) {
        guard let topVC = UIApplication.shared.topViewController() else { return }
        OverlayManager.shared.hideCenterMessage()
        OverlayManager.shared.hideIndicator()
        ad.present(from: topVC)
    }
    func apsspRewardVideoAdLoadFail(_ ad: AdPopcornSSPRewardVideoAd!, error: AdPopcornSSPError!) {
        CULog("[AdPopcorn] 리워드 로드 실패: \(error?.localizedDescription ?? "")")
        onFail?(); onFail = nil; onComplete = nil; rewardAd = nil
    }
    func apsspRewardVideoAdShowSuccess(_ ad: AdPopcornSSPRewardVideoAd!) {}
    func apsspRewardVideoAdShowFail(_ ad: AdPopcornSSPRewardVideoAd!) {
        onFail?(); onFail = nil; onComplete = nil; rewardAd = nil
    }
    func apsspRewardVideoAdClosed(_ ad: AdPopcornSSPRewardVideoAd!) {
        onComplete?(); onComplete = nil; onFail = nil; rewardAd = nil
    }
    func apsspRewardVideoAdPlayCompleted(_ ad: AdPopcornSSPRewardVideoAd!, adNetworkNo: Int, completed: Bool) {}
}
