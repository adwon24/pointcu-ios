//
//  OverlayManager.swift
//  PointCU
//
//  Created by Juno Yoon on 4/18/26.
//

import SwiftUI
import Combine

enum PopupButtonType {
    case single(confirmTitle: String = Constants.Text.textConfirm, confirmAction: () -> Void)
    case double(cancelTitle: String = Constants.Text.textCancel, confirmTitle: String = Constants.Text.textConfirm, cancelAction: () -> Void, confirmAction: () -> Void)
    case extraSingle(confirmTitle: String = Constants.Text.textConfirm, confirmAction: () -> Void)
    case extraDouble(cancelTitle: String = Constants.Text.textCancel, confirmTitle: String = Constants.Text.textConfirm, cancelAction: () -> Void, confirmAction: () -> Void)
    case inspection(confirmTitle: String = Constants.Text.textConfirm, confirmAction: () -> Void)
    case notification(confirmTitle: String = Constants.Text.textConfirm, confirmAction: (Bool) -> Void)
    case reward(imageName: String, confirmTitle: String = Constants.Text.textConfirm, confirmAction: () -> Void)
    case permission(cancelTitle: String = Constants.Text.textCancel, confirmTitle: String = Constants.Text.textConfirm, cancelAction: () -> Void, confirmAction: () -> Void)
}

class OverlayManager: ObservableObject {
    static let shared = OverlayManager()
    
    @Published var isShowing: Bool = false
    @Published var isIndicating: Bool = false
    @Published var toastMessage: String?    = nil
    @Published var centerMessage: String?    = nil  // 화면 중앙 메시지 (광고 로딩 중 등)
    @Published var title: String? = nil
    @Published var message: String = ""
    @Published var buttonType: PopupButtonType = .single(confirmAction: {})
    
    private init() {}
    
    private func present(title: String?, message: String, buttonType: PopupButtonType) {
        DispatchQueue.main.async {
            self.title = title
            self.message = message
            self.buttonType = buttonType
            withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                self.isShowing = true
            }
        }
    }
    
    // MARK: - Toast
 
    /// 화면 센터에 토스트 메시지 표시 (duration 후 자동 사라짐)
    /// 화면 중앙 메시지 표시 (인디케이터와 별개 — 광고 로딩 대기 등)
    func showCenterMessage(_ message: String) {
        DispatchQueue.main.async { self.centerMessage = message }
    }

    func hideCenterMessage() {
        DispatchQueue.main.async { self.centerMessage = nil }
    }

    func showToast(_ message: String, duration: TimeInterval = 2.0) {
        toastMessage = message
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
            self?.toastMessage = nil
        }
    }
    
    // MARK: - 로딩
 
    func showIndicator() {
        DispatchQueue.main.async {
            withAnimation(.easeInOut(duration: 0.2)) {
                self.isIndicating = true
            }
        }
    }
 
    func hideIndicator() {
        if Thread.isMainThread {
            withAnimation(.easeInOut(duration: 0.2)) {
                self.isIndicating = false
            }
        } else {
            DispatchQueue.main.async {
                withAnimation(.easeInOut(duration: 0.2)) {
                    self.isIndicating = false
                }
            }
        }
    }

    // 싱글 버튼
    func showSingle(title: String? = nil,
              message: String, confirmTitle: String = Constants.Text.textConfirm,
              confirmAction: @escaping () -> Void = {}) {
        present(title: title, message: message, buttonType: .single(confirmTitle: confirmTitle, confirmAction: confirmAction))
    }

    // 듀얼 버튼
    func showDual(title: String? = nil,
              message: String,
              cancelTitle: String = Constants.Text.textCancel,
              confirmTitle: String = Constants.Text.textConfirm,
              cancelAction: @escaping () -> Void = {},
              confirmAction: @escaping () -> Void) {
        present(title: title,
                message: message,
                buttonType: .double(cancelTitle: cancelTitle, confirmTitle: confirmTitle, cancelAction: cancelAction, confirmAction: confirmAction))
    }
    
    // 엑스트라 싱글 버튼
    func extraShowSingle(title: String? = nil,
                   message: String,
                   confirmTitle: String = Constants.Text.textConfirm,
                   confirmAction: @escaping () -> Void = {}) {
        present(title: title, message: message, buttonType: .extraSingle(confirmTitle: confirmTitle, confirmAction: confirmAction))
    }
    
    // 엑스트라 듀얼 버튼
    func extraShowDual(title: String? = nil,
              message: String,
              cancelTitle: String = Constants.Text.textCancel,
              confirmTitle: String = Constants.Text.textConfirm,
              cancelAction: @escaping () -> Void = {},
              confirmAction: @escaping () -> Void) {
        present(title: title,
                message: message,
                buttonType: .extraDouble(cancelTitle: cancelTitle, confirmTitle: confirmTitle, cancelAction: cancelAction, confirmAction: confirmAction))
    }
    
    // 리워드 팝업
    func showReward(imageName: String, message: String, confirmTitle: String = Constants.Text.textConfirm, confirmAction: @escaping () -> Void = {}) {
        present(title: nil, message: message, buttonType: .reward(imageName: imageName, confirmTitle: confirmTitle, confirmAction: confirmAction))
    }
    
    func showInspection(title: String? = nil,
                        message: String,
                        confirmTitle: String = Constants.Text.textConfirm,
                        confirmAction: @escaping () -> Void = {}) {
        present(title: title, message: message, buttonType: .inspection(confirmTitle: confirmTitle, confirmAction: confirmAction))
    }
    
    func showNotification(title: String? = nil,
                        message: String,
                        confirmTitle: String = Constants.Text.textConfirm,
                        confirmAction: @escaping (Bool) -> Void) {
        present(title: title, message: message, buttonType: .notification(confirmTitle: confirmTitle, confirmAction: confirmAction))
    }
    
    func showPermission(cancelTitle: String = Constants.Text.textCancel,
                        confirmTitle: String = Constants.Text.textConfirm,
                        cancelAction: @escaping () -> Void,
                        confirmAction: @escaping () -> Void) {
        present(
            title: Constants.Text.permissionGuideTitle,
            message: "",
            buttonType: .permission(
                cancelTitle: cancelTitle,
                confirmTitle: confirmTitle,
                cancelAction: cancelAction,
                confirmAction: confirmAction
            )
        )
    }
    
    func hide() {
        DispatchQueue.main.async {
            withAnimation(.easeInOut(duration: 0.2)) {
                self.isShowing = false
            }
        }
    }
}
