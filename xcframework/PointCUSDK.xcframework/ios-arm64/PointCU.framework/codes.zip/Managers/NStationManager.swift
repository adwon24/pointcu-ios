//
//  NStationManager.swift
//  PointCU
//

import UIKit
import WebKit
import NStationOfferwall

@MainActor
final class NStationManager {

    static let shared = NStationManager()
    private init() {}

    // window를 보관해서 ARC 해제 방지
    private var activeWindow: UIWindow?

    // MARK: - UIWindow 헬퍼

    private func makeContainerWindow() -> (UIWindow, UIViewController)? {
        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }) else { return nil }

        let window = UIWindow(windowScene: scene)
        window.windowLevel = .alert + 1
        let containerVC = UIViewController()
        containerVC.view.backgroundColor = .clear
        window.rootViewController = containerVC
        window.makeKeyAndVisible()
        self.activeWindow = window  // retain
        return (window, containerVC)
    }

    private func releaseWindow() {
        activeWindow?.isHidden = true
        activeWindow?.resignKey()
        activeWindow = nil
    }

    // MARK: - 오퍼월 SDK

    func openOfferwall(adKey: String, userId: String, from viewController: UIViewController) {
        guard let (mkey, mckey) = Self.parseAdKey(adKey) else {
            CULog("[NStation] adKey 파싱 실패: \(adKey)")
            return
        }

        let composedUserId = "\(mckey),\(userId)"
        CULog("[NStation] 오퍼월 실행 | mkey=\(mkey) mckey=\(mckey) userId=\(composedUserId)")

        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }) else { return }

        let window = UIWindow(windowScene: scene)
        window.windowLevel = .alert + 1

        // NStation dismiss 시 viewDidAppear 호출 → window 해제
        let containerVC = NStationContainerViewController {
            CULog("[NStation] 오퍼월 닫힘 → window 해제")
            window.isHidden = true
            window.resignKey()
            self.activeWindow = nil
        }
        window.rootViewController = containerVC
        window.makeKeyAndVisible()
        self.activeWindow = window

        NStation.shared.initialize(mkey: mkey, mckey: mckey, userId: composedUserId)
        NStation.shared.presentNStation(from: containerVC)
    }

    // MARK: - 게임 (가위바위보 / 동전뒤집기)

    func openRPSGame(adKey: String, userId: String, from viewController: UIViewController) {
        openGame(tplcd: "RPS_CD1", adKey: adKey, userId: userId)
    }

    func openCoinGame(adKey: String, userId: String, from viewController: UIViewController) {
        openGame(tplcd: "COIN_CD1", adKey: adKey, userId: userId)
    }

    private func openGame(tplcd: String, adKey: String, userId: String) {
        guard let (mkey, mckey) = Self.parseAdKey(adKey) else {
            print("[NStation] adKey 파싱 실패: \(adKey)")
            return
        }

        print("[NStation] 게임 실행 | tplcd=\(tplcd) mkey=\(mkey) mckey=\(mckey)")

        Task {
            do {
                let lurl = try await Self.fetchGameLurl(
                    tplcd: tplcd,
                    mkey: mkey,
                    mckey: mckey,
                    userId: userId
                )
                print("[NStation] 게임 lurl: \(lurl)")

                await MainActor.run {
                    guard let (_, containerVC) = self.makeContainerWindow() else { return }
                    let webVC = NStationWebGameViewController(urlString: lurl) {
                        self.releaseWindow()
                    }
                    webVC.modalPresentationStyle = .fullScreen
                    containerVC.present(webVC, animated: true)
                }
            } catch {
                print("[NStation] 게임 lurl 조회 실패: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - 컨텐츠 페이지 API

    private static func fetchGameLurl(
        tplcd: String,
        mkey: Int,
        mckey: Int,
        userId: String
    ) async throws -> String {
        let idfv = NetworkManager.shared.idfv
        let baseURL = "https://api.nstation.co.kr/v2/contents/landing"
        let urlString = "\(baseURL)?tplcd=\(tplcd)&mkey=\(mkey)&mckey=\(mckey)&userid=\(userId)&adid=\(idfv)"

        guard let url = URL(string: urlString) else { throw URLError(.badURL) }

        let (data, _) = try await URLSession.shared.data(from: url)

        struct GameResponse: Codable {
            let result: Int
            let lurl: String?
            let errmsg: String?
        }

        let decoded = try JSONDecoder().decode(GameResponse.self, from: data)

        guard decoded.result == 200, let lurl = decoded.lurl else {
            throw NSError(
                domain: "NStation",
                code: decoded.result,
                userInfo: [NSLocalizedDescriptionKey: decoded.errmsg ?? "알 수 없는 오류"]
            )
        }
        return lurl
    }

    // MARK: - 유틸

    private static func parseAdKey(_ adKey: String) -> (mkey: Int, mckey: Int)? {
        let parts = adKey.split(separator: ",")
        guard parts.count >= 2,
              let mkey  = Int(parts[0].trimmingCharacters(in: .whitespaces)),
              let mckey = Int(parts[1].trimmingCharacters(in: .whitespaces)) else {
            return nil
        }
        return (mkey, mckey)
    }
}

// MARK: - NStation 게임 WebView ViewController

final class NStationWebGameViewController: UIViewController, WKNavigationDelegate {

    private let urlString: String
    private let onClose: (() -> Void)?
    private var webView: WKWebView!

    init(urlString: String, onClose: (() -> Void)? = nil) {
        self.urlString = urlString
        self.onClose = onClose
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupWebView()
        setupCloseButton()
        loadURL()
    }

    private func setupWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func setupCloseButton() {
        let closeButton = UIButton(type: .system)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .black
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        view.addSubview(closeButton)

        NSLayoutConstraint.activate([
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            closeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            closeButton.widthAnchor.constraint(equalToConstant: 44),
            closeButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    private func loadURL() {
        guard let url = URL(string: urlString) else { return }
        webView.load(URLRequest(url: url))
    }

    @objc private func closeTapped() {
        dismiss(animated: true) { [weak self] in
            self?.onClose?()
        }
    }
}

// MARK: - NStation 오퍼월용 컨테이너 VC
// NStation dismiss 후 이 VC의 viewDidAppear가 호출되는 시점에 window 해제

final class NStationContainerViewController: UIViewController {
    private let onAppear: () -> Void
    private var appearCount = 0

    init(onAppear: @escaping () -> Void) {
        self.onAppear = onAppear
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        appearCount += 1
        print("[NStation] containerVC viewWillAppear #\(appearCount)")
        // 2번째 호출 = NStation dismiss 후 복귀
        if appearCount >= 2 {
            onAppear()
        }
    }
}
