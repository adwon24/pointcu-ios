//
//  NetworkManager.swift
//  PointCUSDK
//
//  Created by Juno Yoon on 4/5/26.
//

import Foundation
import UIKit

// MARK: - 에러 정의

enum NetworkError: Error, LocalizedError {
    case invalidURL
    case requestFailed(statusCode: Int)
    case decodingFailed
    case serverError(code: String, message: String)
    case unauthorized   // 401 → 토큰 만료, 재로그인 필요

    var errorDescription: String? {
        switch self {
        case .invalidURL:                        return "잘못된 URL입니다."
        case .requestFailed(let code):           return "요청 실패 (HTTP \(code))"
        case .decodingFailed:                    return "응답 파싱에 실패했습니다."
        case .serverError(_, let msg):           return msg
        case .unauthorized:                      return "인증이 만료되었습니다."
        }
    }
}

// MARK: - NetworkManager

class NetworkManager {
    static let shared = NetworkManager()

    private let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard
    private var baseURL: String { sdkBaseURL }

    // SDK 전용 URLSession (타임아웃 15초)
    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest  = 15.0
        config.timeoutIntervalForResource = 30.0
        return URLSession(configuration: config)
    }()

    private init() {}

    // MARK: - 토큰 관리

    var currentToken: String? {
        get {
            guard let token = userDefaults.string(forKey: Constants.Key.tokenKey),
                  !token.isEmpty,
                  token != "Bearer" else {
                return nil
            }
            return token
        }
        set {
            if let value = newValue, !value.isEmpty, value != "Bearer" {
                userDefaults.set(value, forKey: Constants.Key.tokenKey)
            } else {
                userDefaults.removeObject(forKey: Constants.Key.tokenKey)
            }
        }
    }

    func clearToken() {
        currentToken = nil
    }

    // MARK: - 공통 Request

    /// GET 요청 (query string 파라미터)
    func get<T: Codable>(
        endpoint: String,
        parameters: [String: String]? = nil,
        requiresAuth: Bool = true
    ) async throws -> T {
        var urlString = baseURL + endpoint
        if let params = parameters, !params.isEmpty {
            let query = params.map { "\($0.key)=\($0.value)" }.joined(separator: "&")
            urlString += "?" + query
        }
        return try await request(urlString: urlString, method: "GET", body: nil, requiresAuth: requiresAuth)
    }

    /// POST 요청 (form-urlencoded body)
    func post<T: Codable>(
        endpoint: String,
        parameters: [String: Any]? = nil,
        requiresAuth: Bool = true
    ) async throws -> T {
        let urlString = baseURL + endpoint
        let body = parameters.map { percentEncodedString(from: $0) }
        return try await request(urlString: urlString, method: "POST", body: body, requiresAuth: requiresAuth)
    }

    // MARK: - 내부 공통 처리

    private func request<T: Codable>(
        urlString: String,
        method: String,
        body: String?,
        requiresAuth: Bool
    ) async throws -> T {

        guard let url = URL(string: urlString) else {
            throw NetworkError.invalidURL
        }

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method
        urlRequest.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(Constants.Api.companyCode, forHTTPHeaderField: "company_code")
        urlRequest.addValue(Constants.Api.sdkCode,     forHTTPHeaderField: "sdk_code")

        if requiresAuth, let token = currentToken {
            urlRequest.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        if let body = body, method == "POST" {
            urlRequest.httpBody = body.data(using: .utf8)
        }

        // ── 요청 로그 ──────────────────────────────────────────
        let tokenPreview: String = {
            if !requiresAuth { return "none" }
            guard let token = currentToken else { return "token nil" }
            return "Bearer \(token.prefix(20))..."
        }()
        if Constants.NETWORK_LOG { CULog("""
        [NetworkManager] ▶ \(method) \(urlString)
        [NetworkManager]   auth   : \(tokenPreview)
        [NetworkManager]   body   : \(body ?? "(none)")
        """) }
        // ────────────────────────────────────────────────────────

        let (data, response) = try await session.data(for: urlRequest)

        guard let http = response as? HTTPURLResponse else {
            throw NetworkError.requestFailed(statusCode: -1)
        }

        // ── 응답 로그 ──────────────────────────────────────────
        let responseBody = String(data: data, encoding: .utf8) ?? "(decode failed)"
        if Constants.NETWORK_LOG { CULog("""
        [NetworkManager] ◀ \(method) \(urlString)
        [NetworkManager]   status : \(http.statusCode)
        [NetworkManager]   body   : \(responseBody)
        """) }
        // ────────────────────────────────────────────────────────

        if http.statusCode == 401 {
            throw NetworkError.unauthorized
        }

        guard (200...299).contains(http.statusCode) else {
            throw NetworkError.requestFailed(statusCode: http.statusCode)
        }

        do {
            let decoded = try JSONDecoder().decode(ApiResponse<T>.self, from: data)
            let code = decoded.resultCode ?? "unknown"
            let msg  = decoded.resultMsg  ?? "no message"

            if decoded.result == false {
                if Constants.NETWORK_LOG { CULog("[NetworkManager] result:false | code=\(code) msg=\(msg)") }
                throw NetworkError.serverError(code: code, message: msg)
            }
            if code == "0000", let resultData = decoded.resultData {
                return resultData
            } else {
                throw NetworkError.serverError(code: code, message: msg)
            }
        } catch let error as NetworkError {
            throw error
        } catch let decodingError as DecodingError {
            switch decodingError {
            case .keyNotFound(let key, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] keyNotFound: \(key.stringValue) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            case .typeMismatch(let type, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] typeMismatch: \(type) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            case .valueNotFound(let type, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] valueNotFound: \(type) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            default:
                if Constants.NETWORK_LOG { CULog("[NetworkManager] DecodingError: \(decodingError) | \(urlString)") }
            }
            throw NetworkError.decodingFailed
        } catch {
            if Constants.NETWORK_LOG { CULog("[NetworkManager] 기타 오류 | \(urlString) | \(error)") }
            throw NetworkError.decodingFailed
        }
    }

    /// result 값 무관하게 result_data를 디코딩 (result:false지만 data가 있는 케이스)
    func getRaw<T: Codable>(
        endpoint: String,
        method: String = "GET",
        parameters: [String: Any]? = nil
    ) async throws -> T {
        let urlString = baseURL + endpoint
        guard let url = URL(string: urlString) else { throw NetworkError.invalidURL }

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method
        urlRequest.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue(Constants.Api.companyCode, forHTTPHeaderField: "company_code")
        urlRequest.addValue(Constants.Api.sdkCode,     forHTTPHeaderField: "sdk_code")
        if let token = currentToken {
            urlRequest.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        var requestBodyLog = "(none)"
        if method == "POST", let params = parameters, !params.isEmpty {
            let bodyString = percentEncodedString(from: params)
            urlRequest.httpBody = bodyString.data(using: .utf8)
            requestBodyLog = bodyString
        } else if method == "GET", let params = parameters, !params.isEmpty {
            let queryString = params.map { k, v in "\(k)=\(v)" }.joined(separator: "&")
            if let queryURL = URL(string: urlString + "?" + queryString) {
                urlRequest.url = queryURL
            }
            requestBodyLog = queryString
        }
        if Constants.NETWORK_LOG { CULog("[NetworkManager] ▶ \(method) (raw) \(urlString)") }
        if Constants.NETWORK_LOG { CULog("[NetworkManager]   body   : \(requestBodyLog)") }

        let (data, response) = try await session.data(for: urlRequest)

        let responseBody = String(data: data, encoding: .utf8) ?? "(decode failed)"
        let statusCode   = (response as? HTTPURLResponse)?.statusCode ?? -1
        if Constants.NETWORK_LOG { CULog("[NetworkManager] ◀ \(method) (raw) \(urlString)") }
        if Constants.NETWORK_LOG { CULog("[NetworkManager]   status : \(statusCode)") }
        if Constants.NETWORK_LOG { CULog("[NetworkManager]   body   : \(responseBody)") }

        do {
            let decoded = try JSONDecoder().decode(ApiResponse<T>.self, from: data)
            if let resultData = decoded.resultData {
                return resultData
            }
            if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw result_data 없음 | \(urlString)") }
            throw NetworkError.decodingFailed
        } catch let error as NetworkError {
            throw error
        } catch let decodingError as DecodingError {
            switch decodingError {
            case .keyNotFound(let key, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw keyNotFound: \(key.stringValue) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            case .typeMismatch(let type, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw typeMismatch: \(type) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            case .valueNotFound(let type, let ctx):
                if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw valueNotFound: \(type) | \(ctx.codingPath.map { $0.stringValue }) | \(urlString)") }
            default:
                if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw DecodingError: \(decodingError) | \(urlString)") }
            }
            throw NetworkError.decodingFailed
        } catch {
            if Constants.NETWORK_LOG { CULog("[NetworkManager] getRaw 기타 오류: \(error) | \(urlString)") }
            throw NetworkError.decodingFailed
        }
    }

    // MARK: - Form URL Encoding

    private func percentEncodedString(from parameters: [String: Any]) -> String {
        parameters.map { key, value in
            let k = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let v = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return "\(k)=\(v)"
        }
        .joined(separator: "&")
    }
}

// MARK: - URLQueryValueAllowed

extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: ":#[]@!$&'()*+,;=")
        return allowed
    }()
}

// MARK: - 광고 ID

extension NetworkManager {
    /// IDFA 우선, 없으면 IDFV (Utils.adIdentifier() 위임)
    var idfv: String {
        adIdentifier()  // IDFA 우선, 없으면 IDFV
    }
}
