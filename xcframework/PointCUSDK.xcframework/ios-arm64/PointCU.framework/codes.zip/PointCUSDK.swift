//
//  PointCUSDK.swift
//  PointCU
//
//  Created by Juno Yoon on 4/8/26.
//

import SwiftUI
import UIKit
import AppTrackingTransparency
import CoreMotion

internal struct SDKRootContainer: View {
    // @State 대신 static 변수 사용 — 뷰 재생성 시 초기화 방지
    static var isPermissionChecked: Bool = false
    
    var body: some View {
        NavigationView {
            MainView()
        }
        .navigationViewStyle(.stack)
        .useGlobalPopup()
        .useGlobalIndicator()
        .onAppear {
            guard !SDKRootContainer.isPermissionChecked else { return }
            SDKRootContainer.isPermissionChecked = true
            checkAndRequestPermission()
        }
    }
    
    private func checkAndRequestPermission() {
        let status = CMPedometer.authorizationStatus()
        switch status {
        case .authorized:
            // 모션 이미 허용 — ATT 요청 후 SDK 시작
            SDKRootContainer.requestATTThenStartSDK()

        case .notDetermined:
            // 최초 — 모션 권한 안내 팝업 → 모션 허용 후 ATT 요청
            // 팝업이 뜨는 상황이므로 다음 진입 시 다시 체크하도록 플래그 리셋
            SDKRootContainer.isPermissionChecked = false
            showPermissionGuidePopup()

        case .denied, .restricted:
            // 거부 — 설정 안내 팝업
            // 팝업이 뜨는 상황이므로 다음 진입 시 다시 체크하도록 플래그 리셋
            SDKRootContainer.isPermissionChecked = false
            // 모션 권한이 거부된 경우 트래킹 강제 OFF
            if StepManager.shared.isTrackingEnabled {
                StepManager.shared.isTrackingEnabled = false
            }
            showPermissionGuidePopup()

        @unknown default:
            SDKRootContainer.requestATTThenStartSDK()
        }
    }


    
    /// 권한 허용 안내 팝업 (최초 진입 + 거부 후 재진입 + 토글 ON 시 공통)
    /// static으로 외부(MainFooterView 등)에서도 재사용 가능
    /// 모션 권한 획득 후 ATT(광고 ID) 권한 요청 → 완료 후 SDK 시작
    static func requestATTThenStartSDK() {
        ATTrackingManager.requestTrackingAuthorization { status in
            // 허용/거부 무관하게 SDK 시작 (IDFA 없으면 IDFV 사용)
            Task { @MainActor in
                // ATT 결과 즉시 반영 — initializeAppData 완료 전에도 리스트 필터링 적용
                AppDataManager.shared.attAuthorized = (status == .authorized)
                PointCUSDK.startSDKIfReady()
                // isReadyForSync 될 때까지 대기 (= isInitialized=true 보장)
                var waited = 0
                while !StepManager.shared.isReadyForSync && waited < 50 {
                    try? await Task.sleep(nanoseconds: 100_000_000)
                    waited += 1
                }
                // isTrackingEnabled=true인데 활성 세션이 없으면 트래킹 시작
                // (권한 허용이 init Task보다 늦게 처리된 경우 보완)
                StepManager.shared.resumeTrackingIfNeeded()
            }
        }
    }

    static func showPermissionGuidePopupIfNeeded() {
        OverlayManager.shared.showPermission(
            cancelAction: {
                // 취소 — 트래킹 OFF, ATT 요청 후 SDK 시작
                SDKRootContainer.requestATTThenStartSDK()
            },
            confirmAction: {
                let status = CMPedometer.authorizationStatus()
                switch status {
                case .authorized:
                    // 모션 이미 허용 — ATT 요청 후 SDK 시작 + 추적 활성화 (requestATTThenStartSDK 내부 처리)
                    SDKRootContainer.requestATTThenStartSDK()

                case .notDetermined:
                    // 시스템 권한 팝업 요청
                    StepManager.shared.requestMotionAuthorization { granted in
                        if granted {
                            // 권한 허용 → 트래킹 활성화
                            DispatchQueue.main.async {
                                StepManager.shared.isTrackingEnabled = true
                            }
                        }
                        // 허용/거부 무관하게 SDK 시작 — ATT는 광고 ID용이며 데이터 처리와 무관
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            SDKRootContainer.requestATTThenStartSDK()
                        }
                    }

                case .denied, .restricted:
                    // 설정 이동 안내 — hide() 완료 후 팝업 표시
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        showSettingsGuidePopupIfNeeded()
                    }

                @unknown default:
                    SDKRootContainer.requestATTThenStartSDK()
                }
            }
        )
    }
    
    private static func showSettingsGuidePopupIfNeeded() {
        OverlayManager.shared.showDual(
            title: Constants.Text.permissionGuideTitle,
            message: Constants.Text.permissionDeniedGuide,
            cancelAction: {
                // 거부 상태로 SDK 계속 사용 (트래킹만 OFF)
                SDKRootContainer.requestATTThenStartSDK()
            },
            confirmAction: {
                StepManager.shared.openAppSettings()
            }
        )
    }
    
    /// instance 메서드 → static 위임
    private func showPermissionGuidePopup() {
        SDKRootContainer.showPermissionGuidePopupIfNeeded()
    }
 
    private func showSettingsGuidePopup() {
        SDKRootContainer.showSettingsGuidePopupIfNeeded()
    }
 
    private func dismissSDK() {
        SDKRootContainer.dismissSDKIfNeeded()
    }
 
    static func dismissSDKIfNeeded() {
        // 다음 SDK 진입 시 권한 체크 재실행을 위해 플래그 초기화
        SDKRootContainer.isPermissionChecked = false
        DispatchQueue.main.async {
            // OverlayManager 팝업/인디케이터 먼저 정리
            OverlayManager.shared.hideIndicator()
            OverlayManager.shared.hide()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                guard let scene = UIApplication.shared.connectedScenes
                    .compactMap({ $0 as? UIWindowScene })
                    .first(where: { $0.activationState == .foregroundActive }),
                      let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
                else { return }
                root.dismiss(animated: true)
            }
        }
    }
}

// MARK: - 게임 이벤트 콜백

/// SDK 메인 화면 종료 이벤트
public protocol PointCUFinishDelegate: AnyObject {
    /// 재고 조회 버튼 클릭 시 호출
    func onMoveInventory()
}

/// 게임 이벤트 반환
public protocol PointCUGameDelegate: AnyObject {
    /// 게임 화면 구성 또는 광고 노출 오류 시 호출
    func onGameLoadFail(error: PointCUError)
    /// 게임 이벤트 처리 후 포인트 확인 시 호출
    func onGameComplete(winPoint: Int)
    /// 모든 게임 화면 종료 시 호출
    func onGameClose()
}

/// 광고 이벤트 반환
public protocol PointCUAdDelegate: AnyObject {
    /// 광고 노출 시 호출
    func onAdShow(type: Point4uAd?)
    /// 광고 로딩 실패 시 호출
    func onAdFail(type: Point4uAd?, error: PointCUError)
    /// 광고 종료 시 호출
    func onAdClose(type: Point4uAd?)
    /// 광고 리워드 적립 시 호출
    func onAdEarned(type: Point4uAd?)
    /// 광고 클릭 시 호출
    func onAdClick(type: Point4uAd?)
}

// MARK: - 성별

// MARK: - 에러 코드

public enum PointCUErrorCode: Int {
    case invalidBirthFormat    = 1002  // birth 형식 오류 (yyyy-MM-dd 또는 yyyyMMdd만 허용)
    case missingRequiredField  = 1003  // 필수 항목 누락 (userId, birth/age, gender)
    case notInitialized        = 1004  // SDK 초기화 전 함수 호출
    case notRegistered         = 1005  // 미등록 사용자
    case noAdAvailable         = 2001  // 광고 없음
    case unknown               = 9999  // 알 수 없는 오류
}

public struct PointCUError: Error {
    public let code: PointCUErrorCode
    public let message: String

    public init(code: PointCUErrorCode, message: String) {
        self.code    = code
        self.message = message
    }
}

public enum PointCUGender: String {
    case male    = "1"   // 남성
    case female  = "0"   // 여성
    case unknown = ""    // 미지정
}

// MARK: - 광고 타입 (메인 앱 직접 광고 호출용)

public enum Point4uAd: String {
    case eat        = "D0000283"  // 오늘 뭐먹지
    case inventory  = "D0000284"  // 재고 조회
    case newProduct = "D0000285"  // 신상품
    case preOrder   = "D0000286"  // 예약 구매
}

public class PointCUSDK {

    // MARK: - 파라미터 임시 저장 (권한 처리 완료 전)
    private static var pendingUserId:       String? = nil
    private static weak var finishDelegate: PointCUFinishDelegate? = nil
    private static var pendingBirth:  String? = nil   // yyyy-MM-dd 또는 yyyyMMdd
    private static var pendingAge:    Int?    = nil   // 나이 (birth 없을 때)
    private static var pendingGender: String? = nil

    // MARK: - 권한 처리 완료 후 통신 시작

    @MainActor
    static func startSDKIfReady() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { startSDKIfReady() }
            return
        }
        guard let userId = pendingUserId, !userId.isEmpty else {
            CULog("[PointCUSDK] startSDKIfReady: userId 없음")
            return
        }
        // 이미 초기화 완료된 상태면 재실행 방지
        if StepManager.shared.isReadyForSync && NetworkManager.shared.currentToken != nil {
            CULog("[PointCUSDK] startSDKIfReady: 이미 초기화 완료 — 데이터 갱신만 실행")
            Task {
                // ATT 상태 즉시 갱신 — 설정에서 ON/OFF 후 재진입 시 리스트 반영
                await MainActor.run {
                    AppDataManager.shared.attAuthorized = ATTrackingManager.trackingAuthorizationStatus == .authorized
                }
                await AppDataManager.shared.checkAndRefresh()
            }
            return
        }

        // savedUserId와 다른 userId로 진입 시 토큰 클리어
        // savedUserId가 nil(clearUserData 후)인 경우도 토큰 클리어
        let savedUserId = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName)?.string(forKey: Constants.Key.userIdKey)
        if savedUserId == nil || savedUserId != userId {
            CULog("[PointCUSDK] userId 변경 또는 신규 진입 → 토큰 클리어")
            NetworkManager.shared.clearToken()
        }

        Task {
            // 시스템 점검 체크 — 점검 중이면 이후 진행 안 함
            if await AppDataManager.shared.checkInspection() { return }

            await AppDataManager.shared.initializeAppData(
                userId:  userId,
                birth:   pendingBirth,
                age:     pendingAge,
                gender:  pendingGender  // nil이면 서버에 빈값 전송
            )
            await StepSyncManager.shared.start()
            await MediationManager.shared.fetchIfNeeded(force: true)
            await MainActor.run {
                ensureNAMInitialized()
            }
            // 초기화 완료 후 공지 팝업 체크
            await AppDataManager.shared.checkNoticePopup()
        }
    }
    
    // MARK: - SwiftUI 진입점

    /// - Parameters:
    ///   - userId: 사용자 구분 ID (앱 재설치 후에도 동일 ID 유지)
    ///   - ageOrBirth: 연령 또는 생년월일 (yyyy-MM-dd). 연령대 입력 가능 (18세 → "10")
    ///   - gender: 성별 (.male / .female)
    /// SDK 메인 화면을 SwiftUI View로 반환
    /// - Parameters:
    ///   - userId: 사용자 ID (필수)
    ///   - birth: 생년월일 yyyy-MM-dd 또는 yyyyMMdd (birth 또는 age 중 하나 필수)
    ///   - age: 나이 (birth 없을 때)
    ///   - gender: 성별
    ///   - finishDelegate: 재고조회 버튼 클릭 시 이벤트 (optional)
    @MainActor
    public static func makeMainView(
        userId:         String,
        birth:          String? = nil,
        age:            Int?    = nil,
        gender:         PointCUGender,
        finishDelegate: PointCUFinishDelegate? = nil
    ) -> some View {
        FontRegistrar.setup()
        SDKRootContainer.isPermissionChecked = false  // 새 진입 시 권한 체크 재실행
        pendingUserId = userId
        pendingBirth          = birth
        pendingAge            = age
        pendingGender         = gender.rawValue
        Self.finishDelegate   = finishDelegate
        return SDKRootContainer()
            .environmentObject(AppDataManager.shared)
            .environmentObject(StepManager.shared)
    }

    // MARK: - UIKit 진입점

    /// SDK 메인 화면을 UIViewController로 반환
    /// - Parameters:
    ///   - userId: 사용자 ID (필수)
    ///   - birth: 생년월일 yyyy-MM-dd 또는 yyyyMMdd (birth 또는 age 중 하나 필수)
    ///   - age: 나이 (birth 없을 때)
    ///   - gender: 성별
    ///   - finishDelegate: 재고조회 버튼 클릭 시 이벤트 (optional)

    @MainActor
    public static func makeMainViewController(
        userId:         String,
        birth:          String? = nil,
        age:            Int?    = nil,
        gender:         PointCUGender,
        finishDelegate: PointCUFinishDelegate? = nil
    ) -> UIViewController {
        FontRegistrar.setup()
        SDKRootContainer.isPermissionChecked = false  // 새 진입 시 권한 체크 재실행
        pendingUserId     = userId
        pendingBirth          = birth
        pendingAge            = age
        pendingGender         = gender.rawValue
        Self.finishDelegate   = finishDelegate

        let rootView = SDKRootContainer()
            .environmentObject(AppDataManager.shared)
            .environmentObject(StepManager.shared)
        let hostingController = UIHostingController(rootView: rootView)
        hostingController.modalPresentationStyle = .fullScreen
        return hostingController
    }

    // MARK: - 세션 복원 (앱 재시작 후 게임 단독 호출 시)

    /// 토큰 + userId가 저장되어 있으면 initializeAppData 실행
    /// 없으면 refreshBenefits만 시도 (이미 초기화된 경우)
    /// 토큰(로그인) 여부 반환 — 회원가입 완료 여부 확인용
    public static func isRegistered() -> Bool {
        NetworkManager.shared.currentToken != nil
    }



    /// 재고조회 이동 — SDK 화면 dismiss 후 finishDelegate.onMoveInventory() 호출
    public static func notifyMoveInventory() {
        guard let delegate = finishDelegate else { return }
        // SDK 메인 화면 dismiss 후 재고조회 이동
        if let topVC = UIApplication.shared.topViewController() {
            topVC.dismiss(animated: true) {
                delegate.onMoveInventory()
            }
        } else {
            delegate.onMoveInventory()
        }
    }


    static func restoreSessionIfNeeded() async {  // internal — SDK 내부 및 데모앱에서 사용
        let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard
        let savedUserId  = userDefaults.string(forKey: Constants.Key.userIdKey)
        let savedToken   = NetworkManager.shared.currentToken

        if let userId = savedUserId, !userId.isEmpty, savedToken != nil {
            // 토큰 + userId 있음 → 전체 초기화
            CULog("[PointCUSDK] 세션 복원 — initializeAppData 실행")
            await AppDataManager.shared.initializeAppData(
                userId: userId,
                birth:  nil,   // 세션 복원 시 — AppDataManager 내부 저장값 유지
                age:    nil,
                gender: nil
            )
        } else if savedToken != nil {
            // 토큰만 있음 → 혜택 데이터만 fetch
            CULog("[PointCUSDK] 세션 복원 — refreshBenefits 실행")
            await AppDataManager.shared.refreshBenefits()
        } else {
            CULog("[PointCUSDK] 세션 복원 불가 — 토큰 없음")
        }

        // NAM SDK 미초기화 시 초기화
        ensureNAMInitialized()

        // 미디에이션 데이터 fetch (NAM 광고 로드에 필요)
        await MediationManager.shared.fetchIfNeeded(force: true)
    }
    
    /// 개발 서버 환경 설정 (TEST_MODE=true 일 때만 적용)
    /// - Parameter useAws: true = AWS 서버, false = STG 서버 (기본값)
    public static func setDevServer(useAws: Bool) {
        Constants.devServerType = useAws ? .aws : .stg
    }

    /// 서버 환경을 직접 지정 (.stg / .aws / .prod)
    public static func setServerType(_ type: PointCUServerType) {
        Constants.devServerType = type
    }

    /// 서버 전환 시 세션 초기화 — 다음 SDK 진입 시 새 서버로 재인증
    // public static func clearSession() {
    //     AppDataManager.shared.clearUserData()
    // }

    /// 오늘의 걸음 수를 반환합니다. SDK 미실행 상태에서 호출하는 함수입니다.
    /// - Parameters:
    ///   - completion: 걸음 수 콜백 (메인 스레드로 반환)
    ///     - -1: 권한 없음
    ///     - 0 이상: 오늘 걸음 수
    /// - 사용 예시:
    ///   ```swift
    ///   PointCUSDK.getStepCount { steps in
    ///       print("오늘 걸음수: \(steps)")
    ///   }
    ///   ```
    public static func getStepCount(completion: @escaping (Int) -> Void) {
        Task {
            let result = await getStepCount()
            DispatchQueue.main.async { completion(result) }
        }
    }

    /// 오늘의 걸음 수를 반환합니다. SDK 미실행 상태에서 호출하는 함수입니다.
    /// - Returns:
    ///   - 권한 없음: -1
    ///   - OFF 상태: 오늘 완료된 세션들의 총합
    ///   - ON 상태: 완료 세션 합 + 마지막 ON 시간부터 현재까지 소급 쿼리 합산
    public static func getStepCount() async -> Int {
        // 권한 체크
        guard CMPedometer.authorizationStatus() == .authorized else { return -1 }

        let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard
        let isTrackingEnabled = userDefaults.bool(forKey: Constants.Key.trackingStateKey)

        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone.current
        let todayKey = Date().toString(format: "yyyy-MM-dd")

        let history = userDefaults.decode(
            [String: [TrackingSession]].self, forKey: Constants.Key.stepHistoryKey
        ) ?? [:]
        let todaySessions = history[todayKey] ?? []

        // 완료된 세션 합산
        let completedSteps = todaySessions
            .filter { $0.end != nil }
            .compactMap { $0.steps }
            .reduce(0, +)

        // OFF 상태 — 완료 세션 합 반환
        guard isTrackingEnabled else { return completedSteps }

        // ON 상태 — 활성 세션 start부터 현재까지 소급 쿼리
        guard let activeSession = todaySessions.first(where: { $0.end == nil }) else {
            return completedSteps
        }

        let pedometer = CMPedometer()
        let liveSteps: Int = await withCheckedContinuation { continuation in
            pedometer.queryPedometerData(from: activeSession.start, to: Date()) { data, _ in
                continuation.resume(returning: data?.numberOfSteps.intValue ?? 0)
            }
        }

        return completedSteps + liveSteps
    }

    // MARK: - 룰렛 게임 단독 실행

    /// 룰렛 게임 화면을 직접 띄웁니다.
    /// - Returns: 실행 성공 여부 (미디에이션 데이터 없으면 false)
    @MainActor @discardableResult
    public static func startGameRoulette(delegate: PointCUGameDelegate? = nil) -> Bool {
        guard let topVC = UIApplication.shared.topViewController() else { return false }
        // 데이터 없으면 초기화 후 재시도
        if AppDataManager.shared.rouletteBenefits.isEmpty {
            Task {
                await restoreSessionIfNeeded()
                await MainActor.run { _ = startGameRoulette(delegate: delegate) }
            }
            return false
        }

        guard let benefit = AppDataManager.shared.rouletteBenefits.first else {
            delegate?.onGameLoadFail(error: PointCUError(code: .noAdAvailable, message: "룰렛 데이터 없음"))
            return false
        }
        let view = RouletteGameView(benefit: benefit, isExternalCall: true)
        let wrappedView = view
            .useGlobalPopup()
            .useGlobalIndicator()
        let vc = UIHostingController(rootView: wrappedView)
        vc.modalPresentationStyle = .fullScreen
        topVC.present(vc, animated: true)
        return true
    }

    // MARK: - 복권 게임 단독 실행

    /// 복권 게임 화면을 직접 띄웁니다.
    /// - Returns: 실행 성공 여부
    @MainActor @discardableResult
    public static func startGameLottery(delegate: PointCUGameDelegate? = nil) -> Bool {
        guard let topVC = UIApplication.shared.topViewController() else { return false }
        // 데이터 없으면 초기화 후 재시도
        if AppDataManager.shared.lotteryBenefits.isEmpty {
            Task {
                await restoreSessionIfNeeded()
                await MainActor.run { _ = startGameLottery(delegate: delegate) }
            }
            return false
        }

        guard let benefit = AppDataManager.shared.lotteryBenefits.first else {
            delegate?.onGameLoadFail(error: PointCUError(code: .noAdAvailable, message: "복권 데이터 없음"))
            return false
        }
        let view = LotteryGameView(benefit: benefit, isExternalCall: true)
            .useGlobalPopup()
            .useGlobalIndicator()
        let vc = UIHostingController(rootView: view)
        vc.modalPresentationStyle = .fullScreen
        topVC.present(vc, animated: true)
        return true
    }

    // MARK: - 사용자 로컬 데이터 삭제

    /// SDK 내부에서 보관 중인 사용자 데이터(토큰, userId, 걸음 기록 등)를 삭제합니다.
    /// 메인앱의 데이터에는 영향을 주지 않습니다.
    /// 메인앱에서 로그아웃 또는 계정 전환 시 호출합니다.
    @MainActor
    public static func clearUserData() {
        let userDefaults = UserDefaults(suiteName: Constants.Key.userDefualtSuiteName) ?? UserDefaults.standard
        // 인증 토큰 / userId 삭제
        userDefaults.removeObject(forKey: Constants.Key.tokenKey)
        userDefaults.removeObject(forKey: Constants.Key.userIdKey)
        // NetworkManager 토큰 메모리/스토리지 모두 클리어
        NetworkManager.shared.clearToken()
        // AppDataManager 초기화
        AppDataManager.shared.clearUserId()
        // StepManager 추적 중단 및 세션 데이터 초기화
        StepManager.shared.resetForUserChange()
        // StepSyncManager 동기화 상태 초기화
        StepSyncManager.shared.reset()
        // pending 파라미터 초기화 (다음 진입 시 새로 세팅됨)
        pendingUserId = nil
        pendingBirth  = nil
        pendingAge    = nil
        pendingGender = nil
        CULog("[PointCUSDK] 사용자 데이터 삭제 완료")
    }

    // MARK: - 광고 직접 노출 (메인 앱에서 호출)

    /// 메인 앱 화면 위에 광고를 직접 노출합니다.
    /// - Parameters:
    ///   - placement: 광고 지면 코드 (AdsPlacementType)
    ///   - userId: 매체사 유저 식별값
    ///   - onComplete: 광고 완료 콜백
    ///   - onFail: 광고 실패/닫기 콜백
    @MainActor
    public static func startAdvertise(
        placement: AdsPlacementType,
        userId: String,
        onComplete: (() -> Void)? = nil,
        onFail: (() -> Void)? = nil,
        onClose: (() -> Void)? = nil
    ) {
        guard let ad = MediationManager.shared.nextAd(for: placement) else {
            print("[PointCUSDK] startAdvertise: 광고 없음 | placement=\(placement.rawValue)")
            onFail?()
            return
        }

        print("[PointCUSDK] startAdvertise | placement=\(placement.rawValue) type=\(ad.priorityCode)")

        // adKey: "adpopcorn_key,mobiwith_key" 형태로 내려올 수 있음
        let keyParts     = ad.adKey.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
        let adPopcornKey = keyParts.count >= 1 ? keyParts[0] : ad.adKey
        let mobiWithKey  = keyParts.count >= 2 ? keyParts[1] : ad.adKey

        // 팝업형만 지원
        switch AdsType.parse(ad.priorityCode) {
        case .mobiWithPopup:
            guard let topVC = UIApplication.shared.topViewController() else { onFail?(); return }
            let vc = MobiWithAdViewController(
                zoneId:     mobiWithKey,
                onComplete: { onComplete?() },
                onFail:     { onFail?() },
                onClose:    onClose.map { cb in { cb() } }
            )
            topVC.present(vc, animated: true)

        case .adPopcornBannerPopup:
            // 애드팝콘 Web SDK 기반 배너 팝업 (패스백 시 MobiWith zoneId 사용)
            guard let topVC = UIApplication.shared.topViewController() else { onFail?(); return }
            let vc = AdPopcornWebAdViewController(
                placementId: adPopcornKey,
                zoneId:      mobiWithKey,
                onComplete:  { onComplete?() },
                onFail:      { onFail?() },
                onClose:     nil
            )
            topVC.present(vc, animated: true)

        default:
            CULog("[PointCUSDK] startAdvertise: 미지원 타입 \(ad.priorityCode)")
            onFail?()
        }
    }

    // MARK: - CU 자체 광고 노출 (Point4uAd 타입)

    /// CU 자체 광고를 직접 노출합니다. (오늘뭐먹지, 재고조회, 신상품, 예약구매)
    @MainActor
    /// CU 자체 광고 노출
    /// - Parameters:
    ///   - type: 광고 타입 (.eat / .inventory / .newProduct / .preOrder)
    ///   - delegate: 광고 이벤트 콜백 (optional)
    ///   - onComplete: 광고 완료 콜백 (delegate 미사용 시)
    ///   - onFail: 광고 실패 콜백 (delegate 미사용 시)
    public static func startPoint4uAdvertise(
        type:       Point4uAd,
        delegate:   PointCUAdDelegate? = nil,
        onComplete: (() -> Void)?      = nil,
        onFail:     (() -> Void)?      = nil
    ) {
        let placement = AdsPlacementType(rawValue: type.rawValue) ?? .unknown

        // 모든 CU 자체 광고 — 매번 /user/advertisement/mediation/list fetch (토큰 불필요)
        Task {
            guard let userMediationData = await MediationManager.shared.fetchUserMediationList() else {
                await MainActor.run {
                    delegate?.onAdFail(type: type, error: PointCUError(code: .noAdAvailable, message: "user 미디에이션 조회 실패"))
                    onFail?()
                }
                return
            }
            let adList = MediationManager.shared.userAds(from: userMediationData, for: placement.rawValue)
            CULog("[PointCUSDK] startPoint4uAdvertise | type=\(type.rawValue) placement=\(placement.rawValue) adList=\(adList.count)")
            guard !adList.isEmpty else {
                await MainActor.run {
                    delegate?.onAdFail(type: type, error: PointCUError(code: .noAdAvailable, message: "미디에이션 데이터 없음"))
                    onFail?()
                }
                return
            }
            await MainActor.run {
                startPoint4uAdvertiseWithList(
                    type: type, adList: adList, placement: placement,
                    delegate: delegate, onComplete: onComplete, onFail: onFail
                )
            }
        }
    }

    /// CU 자체 광고 타입별 순환 인덱스 — 매번 fetch해도 순서 유지
    private static var point4uAdIndexMap: [String: Int] = [:]

    @MainActor
    private static func startPoint4uAdvertiseWithList(
        type:       Point4uAd,
        adList:     [MediationAd],
        placement:  AdsPlacementType,
        delegate:   PointCUAdDelegate?,
        onComplete: (() -> Void)?,
        onFail:     (() -> Void)?
    ) {

        guard let topVC = UIApplication.shared.topViewController() else { onFail?(); return }

        // triedCount를 클로저로 캡처 — 팝업 유지한 채 provider 순환
        var triedCount = 0

        let popup = CommonAdPopupViewController(
            showHeader:      type == .eat,
            showToastOnFail: false,
            onComplete: {
                delegate?.onAdEarned(type: type)
                delegate?.onAdClose(type: type)
                onComplete?()
            },
            onFail: { }  // setOnFail로 교체
        )
        popup.onShown   = {                                       // 광고 노출 시
            delegate?.onAdShow(type: type)
            // 성공 시에만 advance — 다음 호출에서 다음 provider부터 시작
            let cur = point4uAdIndexMap[type.rawValue] ?? 0
            point4uAdIndexMap[type.rawValue] = (cur + 1) % adList.count
        }
        popup.onDismiss = { delegate?.onAdClose(type: type) }  // X버튼/5초미만 닫힘 시
        popup.onClicked = { delegate?.onAdClick(type: type) }

        func loadNext() {
            guard triedCount < adList.count else {
                CULog("[PointCUSDK] 모든 광고 실패 → 팝업 닫기")
                popup.dismissWithFail()
                delegate?.onAdFail(type: type, error: PointCUError(code: .noAdAvailable, message: "모든 광고 로드 실패"))
                onFail?()
                return
            }

            // user 미디에이션은 순환 인덱스 기준으로 시도
            let startIndex = point4uAdIndexMap[type.rawValue] ?? 0
            let adIndex = (startIndex + triedCount) % adList.count
            let ad = adList[adIndex]
            
            let keyParts     = ad.adKey.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
            let adPopcornKey = keyParts.count >= 1 ? keyParts[0] : ad.adKey
            let mobiWithKey  = keyParts.count >= 2 ? keyParts[1] : ""
            let current      = triedCount
            triedCount += 1

            CULog("[PointCUSDK] provider 로드 | \(current+1)/\(adList.count) type=\(ad.priorityCode)")

            let provider: any AdContentProvider
            switch AdsType.parse(ad.priorityCode) {
            case .mobiWithPopup:
                let mb = MobiWithProvider(zoneId: adPopcornKey)
                mb.showToastOnShortVisit = false
                provider = mb

            case .adPopcornRewardBanner:
                let ws = AdPopcornWebSDKProvider(placementId: adPopcornKey, zoneId: mobiWithKey)
                ws.showToastOnShortVisit = false
                provider = ws

            case .adPopcornBannerPopup:
                provider = AdPopcornSSPBannerProvider(placementId: adPopcornKey, viewController: popup)

            default:
                CULog("[PointCUSDK] 미지원 타입 \(ad.priorityCode) → 다음")
                loadNext()
                return
            }

            popup.loadProvider(provider)
        }

        // 실패 시 loadNext 연결
        popup.setOnFail { loadNext() }

        topVC.present(popup, animated: true) {
            loadNext()
        }
    }


    // MARK: - 공통 초기화

    private static var isNAMInitialized: Bool = false

    /// AppDelegate에서 NAM SDK 초기화 완료 후 호출
    /// 이후 ensureNAMInitialized() 중복 초기화 방지
//    public static func setNAMInitialized() {
//        isNAMInitialized = true
//        CULog("[PointCUSDK] NAM SDK 외부 초기화 완료 등록")
//    }

    private static func ensureNAMInitialized() {
        // NAM SDK는 반드시 메인 스레드에서 초기화
        guard Thread.isMainThread else {
            DispatchQueue.main.async { ensureNAMInitialized() }
            return
        }
        guard let namClass = NSClassFromString("GFPAdManager") as? NSObject.Type else {
            CULog("[PointCUSDK] NAM SDK 없음 — 스킵")
            return
        }

        // isSdkInitialized 체크 — 중복 초기화 방지
        let isInitSel = NSSelectorFromString("isSdkInitialized")
        if namClass.responds(to: isInitSel) {
            let result = namClass.perform(isInitSel)
            // perform 반환값이 nil이 아니면 이미 초기화됨 (BOOL YES = 1)
            if result != nil {
                CULog("[PointCUSDK] NAM SDK 이미 초기화됨 — 스킵")
                isNAMInitialized = true
                return
            }
        }

        // 내부 플래그로도 중복 방지
        guard !isNAMInitialized else {
            CULog("[PointCUSDK] NAM SDK 이미 초기화됨(flag) — 스킵")
            return
        }

        let setupSel = NSSelectorFromString("setupWithPublisherCd:target:completionHandler:")
        guard namClass.responds(to: setupSel) else { return }
        CULog("[PointCUSDK] NAM SDK 초기화 시작 (publisherCd=\(Constants.NAM.publisherCd))")
        namClass.perform(setupSel, with: Constants.NAM.publisherCd, with: nil)
        isNAMInitialized = true
    }


}
